﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmStaffMainPage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnLogout = New System.Windows.Forms.Button()
        Me.label = New System.Windows.Forms.Label()
        Me.lblManagePromotion = New System.Windows.Forms.Label()
        Me.lblManageOrder = New System.Windows.Forms.Label()
        Me.lblManageStaff = New System.Windows.Forms.Label()
        Me.lblProfile = New System.Windows.Forms.Label()
        Me.lblManageMenu = New System.Windows.Forms.Label()
        Me.lblManageCustomerMembership = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lblCurrentStaffName = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnLogout
        '
        Me.btnLogout.BackColor = System.Drawing.Color.IndianRed
        Me.btnLogout.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnLogout.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnLogout.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogout.ForeColor = System.Drawing.Color.White
        Me.btnLogout.Location = New System.Drawing.Point(118, 63)
        Me.btnLogout.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnLogout.Name = "btnLogout"
        Me.btnLogout.Size = New System.Drawing.Size(136, 57)
        Me.btnLogout.TabIndex = 21
        Me.btnLogout.Text = "&Logout"
        Me.btnLogout.UseVisualStyleBackColor = False
        '
        'label
        '
        Me.label.BackColor = System.Drawing.Color.Transparent
        Me.label.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold)
        Me.label.Location = New System.Drawing.Point(375, 180)
        Me.label.Name = "label"
        Me.label.Size = New System.Drawing.Size(520, 79)
        Me.label.TabIndex = 23
        Me.label.Text = "Restaurant Admin Gateway"
        Me.label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblManagePromotion
        '
        Me.lblManagePromotion.BackColor = System.Drawing.Color.MediumTurquoise
        Me.lblManagePromotion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblManagePromotion.Cursor = System.Windows.Forms.Cursors.Hand
        Me.lblManagePromotion.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblManagePromotion.Location = New System.Drawing.Point(442, 423)
        Me.lblManagePromotion.Name = "lblManagePromotion"
        Me.lblManagePromotion.Size = New System.Drawing.Size(361, 303)
        Me.lblManagePromotion.TabIndex = 25
        Me.lblManagePromotion.Text = "Manage Promotion"
        Me.lblManagePromotion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblManageOrder
        '
        Me.lblManageOrder.BackColor = System.Drawing.Color.MediumTurquoise
        Me.lblManageOrder.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblManageOrder.Cursor = System.Windows.Forms.Cursors.Hand
        Me.lblManageOrder.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblManageOrder.Location = New System.Drawing.Point(81, 423)
        Me.lblManageOrder.Name = "lblManageOrder"
        Me.lblManageOrder.Size = New System.Drawing.Size(361, 303)
        Me.lblManageOrder.TabIndex = 26
        Me.lblManageOrder.Text = "Manage Order"
        Me.lblManageOrder.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblManageStaff
        '
        Me.lblManageStaff.BackColor = System.Drawing.Color.MediumTurquoise
        Me.lblManageStaff.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblManageStaff.Cursor = System.Windows.Forms.Cursors.Hand
        Me.lblManageStaff.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblManageStaff.Location = New System.Drawing.Point(803, 423)
        Me.lblManageStaff.Name = "lblManageStaff"
        Me.lblManageStaff.Size = New System.Drawing.Size(361, 303)
        Me.lblManageStaff.TabIndex = 27
        Me.lblManageStaff.Text = "Manage Staff"
        Me.lblManageStaff.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblProfile
        '
        Me.lblProfile.BackColor = System.Drawing.Color.MediumTurquoise
        Me.lblProfile.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblProfile.Cursor = System.Windows.Forms.Cursors.Hand
        Me.lblProfile.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProfile.Location = New System.Drawing.Point(803, 727)
        Me.lblProfile.Name = "lblProfile"
        Me.lblProfile.Size = New System.Drawing.Size(361, 303)
        Me.lblProfile.TabIndex = 30
        Me.lblProfile.Text = "Profile"
        Me.lblProfile.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblManageMenu
        '
        Me.lblManageMenu.BackColor = System.Drawing.Color.MediumTurquoise
        Me.lblManageMenu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblManageMenu.Cursor = System.Windows.Forms.Cursors.Hand
        Me.lblManageMenu.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblManageMenu.Location = New System.Drawing.Point(81, 727)
        Me.lblManageMenu.Name = "lblManageMenu"
        Me.lblManageMenu.Size = New System.Drawing.Size(361, 303)
        Me.lblManageMenu.TabIndex = 29
        Me.lblManageMenu.Text = "Manage Menu"
        Me.lblManageMenu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblManageCustomerMembership
        '
        Me.lblManageCustomerMembership.BackColor = System.Drawing.Color.MediumTurquoise
        Me.lblManageCustomerMembership.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblManageCustomerMembership.Cursor = System.Windows.Forms.Cursors.Hand
        Me.lblManageCustomerMembership.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblManageCustomerMembership.Location = New System.Drawing.Point(442, 727)
        Me.lblManageCustomerMembership.Name = "lblManageCustomerMembership"
        Me.lblManageCustomerMembership.Size = New System.Drawing.Size(361, 303)
        Me.lblManageCustomerMembership.TabIndex = 28
        Me.lblManageCustomerMembership.Text = "Manage Customer Membership"
        Me.lblManageCustomerMembership.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Assignment.My.Resources.Resources.Island_Cafe_Logo
        Me.PictureBox1.Location = New System.Drawing.Point(562, -2)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(165, 180)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 22
        Me.PictureBox1.TabStop = False
        '
        'lblCurrentStaffName
        '
        Me.lblCurrentStaffName.BackColor = System.Drawing.Color.Transparent
        Me.lblCurrentStaffName.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.2!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCurrentStaffName.Location = New System.Drawing.Point(375, 241)
        Me.lblCurrentStaffName.Name = "lblCurrentStaffName"
        Me.lblCurrentStaffName.Size = New System.Drawing.Size(520, 79)
        Me.lblCurrentStaffName.TabIndex = 23
        Me.lblCurrentStaffName.Text = "Restaurant Admin Page"
        Me.lblCurrentStaffName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frmStaffMainPage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImage = Global.Assignment.My.Resources.Resources.lemon_tea
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.btnLogout
        Me.ClientSize = New System.Drawing.Size(1227, 1244)
        Me.Controls.Add(Me.lblProfile)
        Me.Controls.Add(Me.lblManageMenu)
        Me.Controls.Add(Me.lblManageCustomerMembership)
        Me.Controls.Add(Me.lblManageStaff)
        Me.Controls.Add(Me.lblManageOrder)
        Me.Controls.Add(Me.lblManagePromotion)
        Me.Controls.Add(Me.lblCurrentStaffName)
        Me.Controls.Add(Me.label)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.btnLogout)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MaximizeBox = False
        Me.Name = "frmStaffMainPage"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Staff Main Page"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnLogout As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents label As Label
    Friend WithEvents lblManagePromotion As Label
    Friend WithEvents lblManageOrder As Label
    Friend WithEvents lblManageStaff As Label
    Friend WithEvents lblProfile As Label
    Friend WithEvents lblManageMenu As Label
    Friend WithEvents lblManageCustomerMembership As Label
    Friend WithEvents lblCurrentStaffName As Label
End Class
