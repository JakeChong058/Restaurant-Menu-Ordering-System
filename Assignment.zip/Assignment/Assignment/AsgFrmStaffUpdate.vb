﻿Imports System.Data.SqlClient
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class AsgFrmStaffUpdate
    Friend strMenuId As String
    Private da As SqlDataAdapter
    Private ds As DataSet = New DataSet()

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Dim MSSqlCommand As New SqlCommand
        Dim strSql As String
        If cboReason.SelectedIndex = -1 Then
            MessageBox.Show("Please select the reason of making this menu item not available", "Reason Required", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        ElseIf cboReason.SelectedItem = "Very few people order" Then
            If StartConnection() = True Then
                strSql = "Update Menu set Reason = @Reason, Availability = @Availability Where Menu_Id = @Menu_Id"
                MSSqlCommand = New SqlCommand(strSql, connection)
                MSSqlCommand.Parameters.AddWithValue("@Reason", "Very few people order")
                MSSqlCommand.Parameters.AddWithValue("@Availability", "Not Available")
                MSSqlCommand.Parameters.AddWithValue("@Menu_Id", strMenuId)
                MSSqlCommand.ExecuteNonQuery()
                EndConnection()
            End If
            If StartConnection() = True Then
                strSql = "Select * From Menu Where Menu_Id = '" & strMenuId & "'"
                da = New SqlDataAdapter(strSql, connection)
                ds.Clear()
                Try
                    da.Fill(ds, "Menu")
                Catch ex As Exception
                End Try

                If ds.Tables("Menu").Rows.Count > 0 Then
                    MessageBox.Show(ds.Tables("Menu").Rows(0).Item("Menu_Id") & " is set to Not Available now.", "Menu Availability Changed", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
                EndConnection()
            End If
            AsgFrmStaffOrder.AsgFrmStaffOrder_Load(Nothing, Nothing)
            Me.Close()
        ElseIf cboReason.SelectedItem = "Costs are too expensive" Then
            If StartConnection() = True Then
                strSql = "Update Menu set Reason = @Reason, Availability = @Availability Where Menu_Id = @Menu_Id"
                MSSqlCommand = New SqlCommand(strSql, connection)
                MSSqlCommand.Parameters.AddWithValue("@Reason", "Costs are too expensive")
                MSSqlCommand.Parameters.AddWithValue("@Availability", "Not Available")
                MSSqlCommand.Parameters.AddWithValue("@Menu_Id", strMenuId)
                MSSqlCommand.ExecuteNonQuery()
                EndConnection()

            End If
            If StartConnection() = True Then
                strSql = "Select * From Menu Where Menu_Id = '" & strMenuId & "'"
                da = New SqlDataAdapter(strSql, connection)
                ds.Clear()
                Try
                    da.Fill(ds, "Menu")
                Catch ex As Exception
                End Try

                If ds.Tables("Menu").Rows.Count > 0 Then
                    MessageBox.Show(ds.Tables("Menu").Rows(0).Item("Menu_Id") & " is set to Not Available now.", "Menu Availability Changed", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
                EndConnection()
            End If
            AsgFrmStaffOrder.AsgFrmStaffOrder_Load(Nothing, Nothing)
            Me.Close()
        Else
            If StartConnection() = True Then
                strSql = "Update Menu set Reason = @Reason, Availability = @Availability Where Menu_Id = @Menu_Id"
                MSSqlCommand = New SqlCommand(strSql, connection)
                MSSqlCommand.Parameters.AddWithValue("@Reason", "Can't get the material")
                MSSqlCommand.Parameters.AddWithValue("@Availability", "Not Available")
                MSSqlCommand.Parameters.AddWithValue("@Menu_Id", strMenuId)
                MSSqlCommand.ExecuteNonQuery()
                EndConnection()
            End If
            If StartConnection() = True Then
                strSql = "Select * From Menu Where Menu_Id = '" & strMenuId & "'"
                da = New SqlDataAdapter(strSql, connection)
                ds.Clear()
                Try
                    da.Fill(ds, "Menu")
                Catch ex As Exception
                End Try

                If ds.Tables("Menu").Rows.Count > 0 Then
                    MessageBox.Show(ds.Tables("Menu").Rows(0).Item("Menu_Id") & " is set to Not Available now.", "Menu Availability Changed", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If

            End If
            AsgFrmStaffOrder.AsgFrmStaffOrder_Load(Nothing, Nothing)
            Me.Close()
            EndConnection()
        End If
    End Sub

    Private Sub AsgFrmStaffUpdate_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        AsgFrmStaffOrder.Show()

    End Sub

    Private Sub AsgFrmStaffUpdate_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblID.Text = strMenuId
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub
End Class