﻿Imports System.Data.SqlClient

Public Class FrmEditMembership
    Private da As SqlDataAdapter
    Private ds As DataSet = New DataSet()
    Private Sub FrmEditMembership_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim strSql As String
        lblCust.Text = "Register Member for Customer [" & FrmMember.intCustNo & "]"
        'connection = New SqlConnection(connectionString)
        If StartConnection() = True Then
            strSql = "Select M.Member_Id, M.Member_Name, M.Member_Name, M.Member_IC, M.Cust_No, M.Member_Email, M.Gender From Member M, Customer C Where M.Cust_No = C.Cust_No AND C.Cust_No = " & FrmMember.intCustNo
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            Try
                da.Fill(ds, "Customer")
            Catch ex As Exception

            End Try
            If ds.Tables("Customer").Rows.Count > 0 Then
                txtName.Text = ds.Tables("Customer").Rows(0).Item("Member_Name")
                mskIc.Text = ds.Tables("Customer").Rows(0).Item("Member_IC")
                txtEmail.Text = ds.Tables("Customer").Rows(0).Item("Member_Email")
                If ds.Tables("Customer").Rows(0).Item("Gender") = "F" Then
                    radFemale.Checked = True
                Else
                    radMale.Checked = True
                End If
            End If
            EndConnection()
        End If
    End Sub

    Private Sub btnRegister_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim strQuery As String
        Dim MSSqlCommand As New SqlCommand

        If Me.ValidateChildren() = False Then
            Return
        End If

        Dim Gender As String = String.Empty
        If radMale.Checked Then
            Gender = "M"
        ElseIf radFemale.Checked Then
            Gender = "F"
        Else
            MessageBox.Show("Please select member's gender", "No Gender Selected", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If
        Dim validator As New EmailVerification()
        Dim email As String = txtEmail.Text.Trim()
        Dim validEmail As Boolean = validator.IsEmailValid(email)
        Dim userIC As String = mskIc.Text
        Dim day, month, year As Integer

        If userIC.Length = 12 Then
            Dim dayStr As String = userIC.Substring(0, 2)
            Dim monthStr As String = userIC.Substring(2, 2)
            Dim yearStr As String = userIC.Substring(4, 2)

            If validEmail Then
                If Integer.TryParse(dayStr, day) AndAlso Integer.TryParse(monthStr, month) AndAlso Integer.TryParse(yearStr, year) Then

                    If year <= 22 Then
                        year += 2000
                    Else
                        year += 1900
                    End If
                    If StartConnection() = True Then
                        strQuery = "Update Member Set Member_Name = @Member_Name, Member_IC = @Member_IC, Member_Email = @Member_Email, Gender = @Gender Where Cust_No = @Cust_No"
                        MSSqlCommand = New SqlCommand(strQuery, connection)
                        MSSqlCommand.Parameters.AddWithValue("@Member_Name", txtName.Text.Trim())
                        MSSqlCommand.Parameters.AddWithValue("@Member_IC", mskIc.Text)
                        MSSqlCommand.Parameters.AddWithValue("@Member_Email", txtEmail.Text.Trim())
                        MSSqlCommand.Parameters.AddWithValue("@Gender", Gender)
                        MSSqlCommand.Parameters.AddWithValue("@Cust_No", FrmMember.intCustNo)
                        MSSqlCommand.ExecuteNonQuery()
                        MessageBox.Show("Membership of customer [" & FrmMember.intCustNo.ToString() & "] has been updated successfully.", "Member Updated", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        EndConnection()
                        Me.Close()
                        'FrmMember.Show()
                    End If
                Else
                    MessageBox.Show("Invalid date of birth.", "Invalid Date", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            Else
                MessageBox.Show("The email Is Not valid.", "Invalid Format", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Else
            MessageBox.Show("IC Number must be exactly 12 characters long.", "Invalid Length", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub mskIc_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles mskIc.Validating
        Dim strIC As String = If(mskIc.MaskCompleted, mskIc.Text, "")

        If strIC = "" Then
            err.SetError(mskIc, "Please provide member's IC Number")
            e.Cancel = True
        Else
            err.SetError(mskIc, Nothing)
        End If
    End Sub

    Private Sub txtName_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtName.Validating
        If txtName.Text.Trim() = "" Then
            err.SetError(txtName, "Please provide member's name")
            e.Cancel = True
        Else
            err.SetError(txtName, Nothing)
        End If
    End Sub

    Private Sub txtEmail_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtEmail.Validating
        If txtEmail.Text.Trim() = "" Then
            err.SetError(txtEmail, "Please provide member's email")
            e.Cancel = True
        Else
            err.SetError(txtEmail, Nothing)
        End If
    End Sub

    Private Sub FrmEditMembership_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        FrmMemberDetails.FrmMemberDetails_Load(Nothing, Nothing)
        FrmMemberDetails.Show()
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtName.Clear()
        txtEmail.Clear()
        mskIc.Clear()
        radFemale.Checked = False
        radMale.Checked = False
        err.Clear()
    End Sub
End Class