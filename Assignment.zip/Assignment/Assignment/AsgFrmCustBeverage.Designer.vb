﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AsgFrmCustBeverage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.mnuAll = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuPromotion = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFood = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFoodWestern = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFoodChicken = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFoodSalad = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDesserts = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDessertPudding = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDessertIceCream = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuDessertCake = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuBeverages = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuBeveragesCoffee = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuBeveragesTea = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuBeveragesIced = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblBeveragesOrder = New System.Windows.Forms.Label()
        Me.btnLogout = New System.Windows.Forms.Button()
        Me.btnCart = New System.Windows.Forms.Button()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.btnViewOrder = New System.Windows.Forms.Button()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.AutoSize = False
        Me.MenuStrip1.BackColor = System.Drawing.Color.LightCyan
        Me.MenuStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.MenuStrip1.GripMargin = New System.Windows.Forms.Padding(2, 2, 0, 2)
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuAll, Me.mnuPromotion, Me.mnuFood, Me.mnuDesserts, Me.mnuBeverages})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 179)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1226, 46)
        Me.MenuStrip1.TabIndex = 15
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'mnuAll
        '
        Me.mnuAll.AutoSize = False
        Me.mnuAll.Name = "mnuAll"
        Me.mnuAll.Size = New System.Drawing.Size(150, 42)
        Me.mnuAll.Text = "ALL "
        '
        'mnuPromotion
        '
        Me.mnuPromotion.AutoSize = False
        Me.mnuPromotion.Name = "mnuPromotion"
        Me.mnuPromotion.Size = New System.Drawing.Size(170, 42)
        Me.mnuPromotion.Text = "PROMOTION"
        '
        'mnuFood
        '
        Me.mnuFood.AutoSize = False
        Me.mnuFood.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFoodWestern, Me.mnuFoodChicken, Me.mnuFoodSalad})
        Me.mnuFood.Name = "mnuFood"
        Me.mnuFood.Size = New System.Drawing.Size(150, 42)
        Me.mnuFood.Text = "FOOD"
        '
        'mnuFoodWestern
        '
        Me.mnuFoodWestern.BackColor = System.Drawing.Color.LightCyan
        Me.mnuFoodWestern.Name = "mnuFoodWestern"
        Me.mnuFoodWestern.Size = New System.Drawing.Size(239, 34)
        Me.mnuFoodWestern.Text = "Western"
        '
        'mnuFoodChicken
        '
        Me.mnuFoodChicken.BackColor = System.Drawing.Color.LightCyan
        Me.mnuFoodChicken.Name = "mnuFoodChicken"
        Me.mnuFoodChicken.Size = New System.Drawing.Size(239, 34)
        Me.mnuFoodChicken.Text = "Chicken"
        '
        'mnuFoodSalad
        '
        Me.mnuFoodSalad.BackColor = System.Drawing.Color.LightCyan
        Me.mnuFoodSalad.Name = "mnuFoodSalad"
        Me.mnuFoodSalad.Size = New System.Drawing.Size(239, 34)
        Me.mnuFoodSalad.Text = "Salad and Soup"
        '
        'mnuDesserts
        '
        Me.mnuDesserts.AutoSize = False
        Me.mnuDesserts.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuDessertPudding, Me.mnuDessertIceCream, Me.mnuDessertCake})
        Me.mnuDesserts.Name = "mnuDesserts"
        Me.mnuDesserts.Size = New System.Drawing.Size(168, 42)
        Me.mnuDesserts.Text = "DESSERTS"
        '
        'mnuDessertPudding
        '
        Me.mnuDessertPudding.BackColor = System.Drawing.Color.LightCyan
        Me.mnuDessertPudding.Name = "mnuDessertPudding"
        Me.mnuDessertPudding.Size = New System.Drawing.Size(192, 34)
        Me.mnuDessertPudding.Text = "Pudding"
        '
        'mnuDessertIceCream
        '
        Me.mnuDessertIceCream.BackColor = System.Drawing.Color.LightCyan
        Me.mnuDessertIceCream.Name = "mnuDessertIceCream"
        Me.mnuDessertIceCream.Size = New System.Drawing.Size(192, 34)
        Me.mnuDessertIceCream.Text = "Ice Cream"
        '
        'mnuDessertCake
        '
        Me.mnuDessertCake.BackColor = System.Drawing.Color.LightCyan
        Me.mnuDessertCake.Name = "mnuDessertCake"
        Me.mnuDessertCake.Size = New System.Drawing.Size(192, 34)
        Me.mnuDessertCake.Text = "Cake"
        '
        'mnuBeverages
        '
        Me.mnuBeverages.AutoSize = False
        Me.mnuBeverages.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuBeveragesCoffee, Me.mnuBeveragesTea, Me.mnuBeveragesIced})
        Me.mnuBeverages.Name = "mnuBeverages"
        Me.mnuBeverages.Size = New System.Drawing.Size(170, 40)
        Me.mnuBeverages.Text = "BEVERAGES"
        '
        'mnuBeveragesCoffee
        '
        Me.mnuBeveragesCoffee.BackColor = System.Drawing.Color.LightCyan
        Me.mnuBeveragesCoffee.Name = "mnuBeveragesCoffee"
        Me.mnuBeveragesCoffee.Size = New System.Drawing.Size(166, 34)
        Me.mnuBeveragesCoffee.Text = "Coffee"
        '
        'mnuBeveragesTea
        '
        Me.mnuBeveragesTea.BackColor = System.Drawing.Color.LightCyan
        Me.mnuBeveragesTea.Name = "mnuBeveragesTea"
        Me.mnuBeveragesTea.Size = New System.Drawing.Size(166, 34)
        Me.mnuBeveragesTea.Text = "Tea"
        '
        'mnuBeveragesIced
        '
        Me.mnuBeveragesIced.BackColor = System.Drawing.Color.LightCyan
        Me.mnuBeveragesIced.Name = "mnuBeveragesIced"
        Me.mnuBeveragesIced.Size = New System.Drawing.Size(166, 34)
        Me.mnuBeveragesIced.Text = "Iced"
        '
        'lblBeveragesOrder
        '
        Me.lblBeveragesOrder.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBeveragesOrder.Location = New System.Drawing.Point(542, 225)
        Me.lblBeveragesOrder.Name = "lblBeveragesOrder"
        Me.lblBeveragesOrder.Size = New System.Drawing.Size(200, 29)
        Me.lblBeveragesOrder.TabIndex = 16
        Me.lblBeveragesOrder.Text = "BEVERAGES"
        Me.lblBeveragesOrder.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'btnLogout
        '
        Me.btnLogout.BackColor = System.Drawing.Color.IndianRed
        Me.btnLogout.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogout.ForeColor = System.Drawing.Color.White
        Me.btnLogout.Location = New System.Drawing.Point(34, 61)
        Me.btnLogout.Name = "btnLogout"
        Me.btnLogout.Size = New System.Drawing.Size(115, 47)
        Me.btnLogout.TabIndex = 20
        Me.btnLogout.Text = "Logout"
        Me.btnLogout.UseVisualStyleBackColor = False
        '
        'btnCart
        '
        Me.btnCart.BackColor = System.Drawing.Color.MediumTurquoise
        Me.btnCart.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCart.Location = New System.Drawing.Point(182, 62)
        Me.btnCart.Name = "btnCart"
        Me.btnCart.Size = New System.Drawing.Size(141, 47)
        Me.btnCart.TabIndex = 21
        Me.btnCart.Text = "View Cart"
        Me.btnCart.UseVisualStyleBackColor = False
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 8
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 280.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 280.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 280.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 280.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 22.0!))
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(24, 285)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 430.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 430.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1202, 849)
        Me.TableLayoutPanel1.TabIndex = 22
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(0, -3)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(83, 31)
        Me.Button6.TabIndex = 23
        Me.Button6.Text = "Button1"
        Me.Button6.UseVisualStyleBackColor = True
        Me.Button6.Visible = False
        '
        'btnViewOrder
        '
        Me.btnViewOrder.BackColor = System.Drawing.Color.MediumTurquoise
        Me.btnViewOrder.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnViewOrder.Location = New System.Drawing.Point(359, 61)
        Me.btnViewOrder.Name = "btnViewOrder"
        Me.btnViewOrder.Size = New System.Drawing.Size(187, 47)
        Me.btnViewOrder.TabIndex = 24
        Me.btnViewOrder.Text = "View Order"
        Me.btnViewOrder.UseVisualStyleBackColor = False
        '
        'txtSearch
        '
        Me.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearch.Location = New System.Drawing.Point(803, 64)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(388, 39)
        Me.txtSearch.TabIndex = 25
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(798, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(222, 27)
        Me.Label1.TabIndex = 49
        Me.Label1.Text = "Search Menu Items: "
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Assignment.My.Resources.Resources.Island_Cafe_Logo
        Me.PictureBox1.Location = New System.Drawing.Point(562, -3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(165, 180)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 6
        Me.PictureBox1.TabStop = False
        '
        'AsgFrmCustBeverage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1227, 1410)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtSearch)
        Me.Controls.Add(Me.btnViewOrder)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Controls.Add(Me.btnCart)
        Me.Controls.Add(Me.btnLogout)
        Me.Controls.Add(Me.lblBeveragesOrder)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "AsgFrmCustBeverage"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Beverage Order"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents mnuAll As ToolStripMenuItem
    Friend WithEvents mnuPromotion As ToolStripMenuItem
    Friend WithEvents mnuFood As ToolStripMenuItem
    Friend WithEvents mnuFoodWestern As ToolStripMenuItem
    Friend WithEvents mnuFoodChicken As ToolStripMenuItem
    Friend WithEvents mnuFoodSalad As ToolStripMenuItem
    Friend WithEvents mnuDesserts As ToolStripMenuItem
    Friend WithEvents mnuDessertPudding As ToolStripMenuItem
    Friend WithEvents mnuDessertIceCream As ToolStripMenuItem
    Friend WithEvents mnuDessertCake As ToolStripMenuItem
    Friend WithEvents mnuBeverages As ToolStripMenuItem
    Friend WithEvents mnuBeveragesCoffee As ToolStripMenuItem
    Friend WithEvents mnuBeveragesTea As ToolStripMenuItem
    Friend WithEvents mnuBeveragesIced As ToolStripMenuItem
    Friend WithEvents lblBeveragesOrder As Label
    Friend WithEvents btnLogout As Button
    Friend WithEvents btnCart As Button
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents Button6 As Button
    Friend WithEvents btnViewOrder As Button
    Friend WithEvents txtSearch As TextBox
    Friend WithEvents Label1 As Label
End Class
