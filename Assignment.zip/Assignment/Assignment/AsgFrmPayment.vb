﻿Imports System.Data.SqlClient
Imports System.Globalization

Public Class AsgFrmPayment
    Private intCustNo = FrmLoginPage.intCustNo
    'Friend strParts() As String
    Private da As SqlDataAdapter
    Private ds As DataSet = New DataSet()
    Private cartItem() As CartItem
    Private menus() As CustMenuItems
    Private intQuantity As Integer = 0
    Private decSubtotal As Decimal = 0D
    Private Const decSST As Decimal = 0.06D
    Private Const decSERVICE_CHARGE As Decimal = 0.1D
    Private decGrandTotal As Decimal = 0D
    'The default order number
    Friend intOrderNo As Integer = 1001
    Private decPrice() As Decimal
    Private intQuantityEach() As Integer
    Private Sub radCash_CheckedChanged(sender As Object, e As EventArgs) Handles radCash.CheckedChanged, radCreditCard.CheckedChanged
        If radCash.Checked Then
            txtName.Enabled = False
            mskCreditCardNo.Enabled = False
            mskCVV.Enabled = False
            dtpExpDate.Enabled = False
            errValidation.Clear()
        Else
            txtName.Enabled = True
            mskCreditCardNo.Enabled = True
            mskCVV.Enabled = True
            dtpExpDate.Enabled = True
        End If

    End Sub

    'Private Sub AsgFrmPayment_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    '    'Dim decPrice As Decimal = 0D
    '    lstItemView.Items.Add(AsgFrmCustOrder.lblSeafoodPasta.Text & vbTab & AsgFrmCustOrder.Label1.Text)
    '    Const decSST As Decimal = 0.05
    '    Dim decSubtotal As Decimal = 0D
    '    Dim decGrandTotal As Decimal = 0D
    '    decSubtotal = 17D
    '    decGrandTotal = (decSubtotal * decSST) + decSubtotal
    '    lblQty.Text = 1
    '    lblSST.Text = "5%"
    '    lblSubtotal.Text = decSubtotal.ToString("C")
    '    lblGrand.Text = decGrandTotal.ToString("C")
    'End Sub

    Private Sub btnBackCart_Click(sender As Object, e As EventArgs) Handles btnBackCart.Click
        AsgFrmCustCart.Show()
        Me.Close()
        'AsgFrmPayment_Closed(Nothing, Nothing)
    End Sub

    Private Sub AsgFrmPayment_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        AsgFrmCustCart.Show()
    End Sub

    Friend Sub AsgFrmPayment_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim strSql As String
        'Console.WriteLine(dateCurrent)
        'Try
        '    Dim dateCurrent As DateTime = Date.Now
        '    If dateCurrent.ToString("dd/M/yyyy") > dtpExpDate.Value Then
        '        Console.WriteLine("Expired")
        '    Else
        '        Console.WriteLine("Haven't expired")
        '    End If
        'Catch ex As Exception

        'End Try
        If StartConnection() = True Then
            strSql = "Select M.Menu_Id, M.Description, M.Price, M.Category, M.IsPromotion, M.SubCategory, M.Image, M.Status, M.Availability From Menu M, CartItem I, Customer C WHERE I.Cust_Id = C.Cust_No AND I.Menu_Id = M.Menu_Id AND I.Cust_Id = " & intCustNo
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            da.Fill(ds, "Menu")
            ReDim menus(ds.Tables("Menu").Rows.Count - 1)
            If ds.Tables("Menu").Rows.Count > 0 Then
                For intCount = 0 To menus.Length - 1 Step 1
                    menus(intCount) = New CustMenuItems(ds.Tables("Menu").Rows(intCount).Item(0),
                    ds.Tables("Menu").Rows(intCount).Item(1), ds.Tables("Menu").Rows(intCount).Item(2),
                    ds.Tables("Menu").Rows(intCount).Item(3), ds.Tables("Menu").Rows(intCount).Item(4),
                    ds.Tables("Menu").Rows(intCount).Item(5), ds.Tables("Menu").Rows(intCount).Item(6),
                    ds.Tables("Menu").Rows(intCount).Item(7), ds.Tables("Menu").Rows(intCount).Item(8))
                Next intCount
            End If
            EndConnection()
        End If
        If StartConnection() = True Then
            strSql = "Select I.Quantity, I.Price From Menu M, CartItem I, Customer C WHERE I.Cust_Id = C.Cust_No AND I.Menu_Id = M.Menu_Id AND I.Cust_Id = " & intCustNo '& " AND I.Menu_Id = '" & menuItem(intNumber).GetStrMenuId() & "'"
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            Try
                da.Fill(ds, "CartItem")
            Catch ex As Exception
                'do something
            End Try
            If ds.Tables("CartItem").Rows.Count > 0 Then
                DataGridView1.DataSource = ds.Tables("CartItem")
                'ReDim descriptionLabel(ds.Tables("CartItem").Rows.Count - 1)
                'ReDim priceLabel(ds.Tables("CartItem").Rows.Count - 1)
                'lblEmpty.Visible = False
                'TableLayoutPanel1.Visible = True
                'btnClearCart.Enabled = True
                'btnProceed.Enabled = True
                ReDim cartItem(ds.Tables("CartItem").Rows.Count - 1)
                ReDim decPrice(ds.Tables("CartItem").Rows.Count - 1)
                ReDim intQuantityEach(ds.Tables("CartItem").Rows.Count - 1)
                'ds.Tables("CartItem").Columns.Add("Item", Type.GetType("System.String"))
                'TableLayoutPanel1.RowCount = ds.Tables("CartItem").Rows.Count + 1
                'TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 41))
                'TableLayoutPanel1.Height = 33 * TableLayoutPanel1.RowCount
                'TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 48))
                For intIndex = 0 To cartItem.Length - 1 Step 1
                    intQuantity += ds.Tables("CartItem").Rows(intIndex).Item("Quantity")
                    decSubtotal += ds.Tables("CartItem").Rows(intIndex).Item("Price")
                    decPrice(intIndex) = ds.Tables("CartItem").Rows(intIndex).Item("Price")
                    intQuantityEach(intIndex) = ds.Tables("CartItem").Rows(intIndex).Item("Quantity")
                    decGrandTotal = decSubtotal + (decSubtotal * decSST) + (decSubtotal * decSERVICE_CHARGE)
                    'cartItem(intIndex) = New CartItem(ds.Tables("CartItem").Rows(intIndex).Item(0), menus(intIndex))
                    DataGridView1.Item(0, intIndex).Value = menus(intIndex).GetStrDescription()
                    'DataGridView1.Item(2, intIndex).Value = DataGridView1.Item(2, intIndex).Value.ToString("C")
                    '    'TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 48))
                    '    'TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 0))
                    '    cartItem(intIndex) = New CartItem(ds.Tables("CartItem").Rows(intIndex).Item(0), menus(intIndex))
                    '    cartItem(intIndex).GetNMQuantity().Value = ds.Tables("CartItem").Rows(intIndex).Item("Quantity")
                    '    cartItem(intIndex).SetDecPrice(ds.Tables("CartItem").Rows(intIndex).Item("Price"))
                    '    descriptionLabel(intIndex) = New Label()
                    '    descriptionLabel(intIndex).Text = cartItem(intIndex).GetMenuItem().GetStrDescription()
                    '    descriptionLabel(intIndex).Dock = DockStyle.Fill
                    '    descriptionLabel(intIndex).TextAlign = ContentAlignment.MiddleCenter
                    '    descriptionLabel(intIndex).Font = New Font("Microsoft Sans Serif", 12)
                    '    'descriptionLabel(intIndex).Height = 44
                    '    priceLabel(intIndex) = New Label()
                    '    priceLabel(intIndex).Text = cartItem(intIndex).GetDecPrice().ToString("C")
                    '    priceLabel(intIndex).Dock = DockStyle.Fill
                    '    priceLabel(intIndex).TextAlign = ContentAlignment.MiddleCenter
                    '    priceLabel(intIndex).Font = New Font("Microsoft Sans Serif", 12)
                    '    'priceLabel(intIndex).Height = 44
                    '    AddHandler cartItem(intIndex).GetBtnRemove().Click, AddressOf btnRemoveItem_Click
                    '    AddHandler cartItem(intIndex).GetNMQuantity().ValueChanged, AddressOf NumericUpDown1_ValueChanged
                    '    TableLayoutPanel1.Controls.Add(cartItem(intIndex).GetBtnRemove())
                    '    TableLayoutPanel1.Controls.Add(descriptionLabel(intIndex))
                    '    TableLayoutPanel1.Controls.Add(cartItem(intIndex).GetNMQuantity())
                    '    TableLayoutPanel1.Controls.Add(priceLabel(intIndex))
                Next intIndex
                DataGridView1.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(0).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(0).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(1).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(1).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(2).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(2).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(1).SortMode = DataGridViewColumnSortMode.NotSortable
                DataGridView1.Columns(2).SortMode = DataGridViewColumnSortMode.NotSortable
                'DataGridView1.C = DataGridViewContentAlignment.MiddleCenter
                'TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 45))
                lblQty.Text = intQuantity.ToString()
                lblSubtotal.Text = decSubtotal.ToString("C")
                lblSST.Text = "6%"
                lblService.Text = "10%"
                lblGrand.Text = decGrandTotal.ToString("C")
            End If
            EndConnection()
        End If
    End Sub

    Private Sub btnPlaceOrder_Click(sender As Object, e As EventArgs) Handles btnPlaceOrder.Click
        If radCreditCard.Checked Then
            If Me.ValidateChildren() = False Then
                MessageBox.Show("Cannot place order. This might be due to: " & vbNewLine & "1. You haven't complete your credit card information." & vbNewLine & "2. Your credit card is expired.", "Cannot Place Order", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return ' There are input error --> Stop insertion
            End If
        End If

        Dim dlgSelection As DialogResult
        dlgSelection = MessageBox.Show("Once an order is placed, the order cannot be cancelled and changed. Confirm place order?", "Order Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If dlgSelection = DialogResult.Yes Then
            Dim MSSqlCommand As New SqlCommand
            Dim strSql As String
            If StartConnection() = True Then
                strSql = "Select * From Food_Order"
                da = New SqlDataAdapter(strSql, connection)
                ds.Clear()
                Try
                    da.Fill(ds, "Food_Order")
                Catch ex As Exception
                    'do something
                End Try
                If ds.Tables("Food_Order").Rows.Count > 0 Then
                    intOrderNo = ds.Tables("Food_Order").Rows(ds.Tables("Food_Order").Rows.Count - 1).Item("Order_No") + 1
                End If
                EndConnection()
            End If
            If StartConnection() = True Then
                If radCash.Checked Then
                    strSql = "Insert Into Food_Order(Order_No, Order_Date, Cust_No, Total_Items, Food_Amount, Payment_Amount, Subtotal, Payment_Method, Change, Status, CardName, CardNumber, CVV, CardExpDate, Date, Staff_Id)Values(@Order_No, @Order_Date, @Cust_No, @Total_Items, @Food_Amount, @Payment_Amount, @Subtotal, @Payment_Method, @Change, @Status, @CardName, @CardNumber, @CVV, @CardExpDate, @Date, @Staff_Id)"
                    MSSqlCommand = New SqlCommand(strSql, connection)
                    MSSqlCommand.Parameters.AddWithValue("@Order_No", intOrderNo)
                    MSSqlCommand.Parameters.AddWithValue("@Order_Date", Date.Now)
                    MSSqlCommand.Parameters.AddWithValue("@Cust_No", intCustNo)
                    MSSqlCommand.Parameters.AddWithValue("@Total_Items", intQuantity)
                    MSSqlCommand.Parameters.AddWithValue("@Food_Amount", decGrandTotal)
                    MSSqlCommand.Parameters.AddWithValue("@Payment_Amount", 0.00)
                    MSSqlCommand.Parameters.AddWithValue("@Subtotal", decSubtotal)
                    MSSqlCommand.Parameters.AddWithValue("@Payment_Method", "Pay by Cash")
                    MSSqlCommand.Parameters.AddWithValue("@Change", 0.00)
                    MSSqlCommand.Parameters.AddWithValue("@Status", "Waiting for Accept")
                    MSSqlCommand.Parameters.AddWithValue("@CardName", "")
                    MSSqlCommand.Parameters.AddWithValue("@CardNumber", "")
                    MSSqlCommand.Parameters.AddWithValue("@CVV", "")
                    MSSqlCommand.Parameters.AddWithValue("@CardExpDate", "")
                    MSSqlCommand.Parameters.AddWithValue("@Date", Date.Now)
                    MSSqlCommand.Parameters.AddWithValue("@Staff_Id", 1001)
                    MSSqlCommand.ExecuteNonQuery()
                    'MessageBox.Show("Order has been placed successfully!", "Order Placed", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    EndConnection()
                    If StartConnection() = True Then
                        For intCount = 0 To menus.Length - 1 Step 1
                            strSql = "Insert Into Order_List(Order_No, Menu_Id, Quantity, Price)Values(@Order_No, @Menu_Id, @Quantity, @Price)"
                            MSSqlCommand = New SqlCommand(strSql, connection)
                            MSSqlCommand.Parameters.AddWithValue("@Order_No", intOrderNo)
                            MSSqlCommand.Parameters.AddWithValue("@Menu_Id", menus(intCount).GetStrMenuId())
                            MSSqlCommand.Parameters.AddWithValue("@Quantity", intQuantityEach(intCount))
                            MSSqlCommand.Parameters.AddWithValue("@Price", decPrice(intCount))
                            MSSqlCommand.ExecuteNonQuery()
                            'menus(intCount) = New CustMenuItems(ds.Tables("Menu").Rows(intCount).Item(0),
                            'ds.Tables("Menu").Rows(intCount).Item(1), ds.Tables("Menu").Rows(intCount).Item(2),
                            'ds.Tables("Menu").Rows(intCount).Item(3), ds.Tables("Menu").Rows(intCount).Item(4),
                            'ds.Tables("Menu").Rows(intCount).Item(5), ds.Tables("Menu").Rows(intCount).Item(6))
                        Next intCount
                        EndConnection()
                    End If
                Else
                    strSql = "Insert Into Food_Order(Order_No, Order_Date, Cust_No, Total_Items, Food_Amount, Payment_Amount, Subtotal, Payment_Method, Change, Status, CardName, CardNumber, CVV, CardExpDate, Date, Staff_Id)Values(@Order_No, @Order_Date, @Cust_No, @Total_Items, @Food_Amount, @Payment_Amount, @Subtotal, @Payment_Method, @Change, @Status, @CardName, @CardNumber, @CVV, @CardExpDate, @Date, @Staff_Id)"
                    MSSqlCommand = New SqlCommand(strSql, connection)
                    MSSqlCommand.Parameters.AddWithValue("@Order_No", intOrderNo)
                    MSSqlCommand.Parameters.AddWithValue("@Order_Date", Date.Now)
                    MSSqlCommand.Parameters.AddWithValue("@Cust_No", intCustNo)
                    MSSqlCommand.Parameters.AddWithValue("@Total_Items", intQuantity)
                    MSSqlCommand.Parameters.AddWithValue("@Food_Amount", decGrandTotal)
                    MSSqlCommand.Parameters.AddWithValue("@Payment_Amount", decGrandTotal)
                    MSSqlCommand.Parameters.AddWithValue("@Subtotal", decSubtotal)
                    MSSqlCommand.Parameters.AddWithValue("@Payment_Method", "Pay by Credit Card")
                    MSSqlCommand.Parameters.AddWithValue("@Change", 0.00)
                    MSSqlCommand.Parameters.AddWithValue("@Status", "Received")
                    MSSqlCommand.Parameters.AddWithValue("@CardName", txtName.Text.Trim())
                    MSSqlCommand.Parameters.AddWithValue("@CardNumber", mskCreditCardNo.Text.Trim())
                    MSSqlCommand.Parameters.AddWithValue("@CVV", mskCVV.Text.Trim())
                    MSSqlCommand.Parameters.AddWithValue("@CardExpDate", dtpExpDate.Value)
                    MSSqlCommand.Parameters.AddWithValue("@Date", Date.Now)
                    MSSqlCommand.Parameters.AddWithValue("@Staff_Id", 1001)
                    MSSqlCommand.ExecuteNonQuery()
                    'MessageBox.Show("Order has been placed successfully!", "Order Placed", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    EndConnection()
                    If StartConnection() = True Then
                        For intCount = 0 To menus.Length - 1 Step 1
                            strSql = "Insert Into Order_List(Order_No, Menu_Id, Quantity, Price)Values(@Order_No, @Menu_Id, @Quantity, @Price)"
                            MSSqlCommand = New SqlCommand(strSql, connection)
                            MSSqlCommand.Parameters.AddWithValue("@Order_No", intOrderNo)
                            MSSqlCommand.Parameters.AddWithValue("@Menu_Id", menus(intCount).GetStrMenuId())
                            MSSqlCommand.Parameters.AddWithValue("@Quantity", intQuantityEach(intCount))
                            MSSqlCommand.Parameters.AddWithValue("@Price", decPrice(intCount))
                            MSSqlCommand.ExecuteNonQuery()
                            'menus(intCount) = New CustMenuItems(ds.Tables("Menu").Rows(intCount).Item(0),
                            'ds.Tables("Menu").Rows(intCount).Item(1), ds.Tables("Menu").Rows(intCount).Item(2),
                            'ds.Tables("Menu").Rows(intCount).Item(3), ds.Tables("Menu").Rows(intCount).Item(4),
                            'ds.Tables("Menu").Rows(intCount).Item(5), ds.Tables("Menu").Rows(intCount).Item(6))
                        Next intCount
                        EndConnection()
                    End If
                End If

                'MessageBox.Show(MenuItem(intNumber).GetStrDescription() & " is added to your cart.", "Items Added To Cart", MessageBoxButtons.OK, MessageBoxIcon.Information)
                'AsgFrmCustCart.AsgFrmCustCart_Load(Nothing, Nothing)
            End If
            If StartConnection() = True Then
                strSql = "Delete from CartItem Where Cust_Id=@Cust_Id"
                MSSqlCommand = New SqlCommand(strSql, connection)
                MSSqlCommand.Parameters.AddWithValue("@Cust_Id", intCustNo)
                'MSSqlCommand.Parameters.AddWithValue("@Menu_Id", cartItem(intNumber).GetMenuItem().GetStrMenuId())
                MSSqlCommand.ExecuteNonQuery()
                'MessageBox.Show("Record updated.", "Update Record"
                EndConnection()
            End If
            AsgFrmCustCurrentOrder.IsFromPayment()
            AsgFrmCustCurrentOrder.Show()
            Me.Hide()
        End If
    End Sub

    Private Sub mskCreditCardNo_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles mskCreditCardNo.Validating
        Dim strCreditNumber As String = If(mskCreditCardNo.MaskCompleted, mskCreditCardNo.Text, "")

        If strCreditNumber = "" Then
            errValidation.SetError(mskCreditCardNo, "Please provide complete credit card number")
            e.Cancel = True ' Indicate the validating event DOES NOT pass (i.e. there is input error)
        Else
            errValidation.SetError(mskCreditCardNo, Nothing) ' Remove the error from the error provider
        End If
    End Sub

    Private Sub txtName_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtName.Validating
        'Dim strCreditNumber As String = If(mskCreditCardNo.MaskCompleted, mskCreditCardNo.Text, "")

        If txtName.Text = "" Then
            errValidation.SetError(txtName, "Please provide name on card")
            e.Cancel = True ' Indicate the validating event DOES NOT pass (i.e. there is input error)
        Else
            errValidation.SetError(txtName, Nothing) ' Remove the error from the error provider
        End If
    End Sub

    Private Sub mskCVV_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles mskCVV.Validating
        Dim strCVV As String = If(mskCVV.MaskCompleted, mskCVV.Text, "")

        If strCVV = "" Then
            errValidation.SetError(mskCVV, "Please key in complete CVV")
            e.Cancel = True ' Indicate the validating event DOES NOT pass (i.e. there is input error)
        Else
            errValidation.SetError(mskCVV, Nothing) ' Remove the error from the error provider
        End If
    End Sub

    Private Sub dtpExpDate_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles dtpExpDate.Validating
        'Dim strCVV As String = If(mskCVV.MaskCompleted, mskCVV.Text, "")
        Dim dateCurrent As DateTime = Date.Now
        If dateCurrent.ToString("dd/M/yyyy") > dtpExpDate.Value Then
            errValidation.SetError(dtpExpDate, "Credit Card is expired")
            e.Cancel = True ' Indicate the validating event DOES NOT pass (i.e. there is input error)
        Else
            errValidation.SetError(dtpExpDate, Nothing) ' Remove the error from the error provider
        End If

        'If strCVV = "" Then
        '    errValidation.SetError(mskCVV, "Please key in complete CVV")
        '    e.Cancel = True ' Indicate the validating event DOES NOT pass (i.e. there is input error)
        'Else
        '    errValidation.SetError(mskCVV, Nothing) ' Remove the error from the error provider
        'End If

        'If date1 > date2 Then
        '    MsgBox("Expired")
        'Else
        '    MsgBox("Not Expired")
        'End If
    End Sub
End Class