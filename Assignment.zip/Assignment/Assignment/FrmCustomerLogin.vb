﻿Imports System.Data.SqlClient
Imports System.Text

Public Class FrmLoginPage
    Friend intCustNo As Integer = 0
    Private da As SqlDataAdapter
    Private ds As DataSet = New DataSet()
    'Public Property MainForm As Form
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim err As New StringBuilder()
        Dim ctr As Control = Nothing
        Dim strQuery As String
        Dim strPhoneNumber As String = If(mskPhoneNumber.MaskCompleted, mskPhoneNumber.Text, "")

        If strPhoneNumber = "" Then
            err.AppendLine("Please provide your phone number.")
            ctr = If(ctr, mskPhoneNumber)
        End If

        If err.Length > 0 Then
            MessageBox.Show(err.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ctr.Focus()
            err.Clear()
            Return
        End If

        'Dim connectionString As String = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Daniel Yong\Documents\A Y2 Sem 1\Visual Programming\Practical\Assignment\Assignment\Restaurent.mdf;Integrated Security=True"
        'Using connection As New SqlConnection(connectionString)
        'connection.Open()
        If StartConnection() = True Then
            strQuery = "SELECT Cust_No, Password FROM Customer WHERE Phone_Num = '" & mskPhoneNumber.Text & "'"
            da = New SqlDataAdapter(strQuery, connection)
            ds.Clear()
            Try
                da.Fill(ds, "Customer")
            Catch ex As Exception
            End Try

            If ds.Tables("Customer").Rows.Count > 0 Then
                If ds.Tables("Customer").Rows(0).Item("Password") <> txtPassword.Text.Trim() Then
                    lblError.Text = "Access Denied! Due to invalid phone number or password provided."
                    lblError.Visible = True
                    EndConnection()
                    Return
                Else
                    lblError.Visible = False
                    Me.Hide()
                    EndConnection()
                    txtPassword.Text = ""
                    mskPhoneNumber.Clear()
                    intCustNo = ds.Tables("Customer").Rows(0).Item("Cust_No")
                    AsgFrmCustOrder.Show()
                End If
            Else
                lblError.Text = "Access Denied! Due to invalid phone number or password provided."
                lblError.Visible = True
                EndConnection()
            End If
        End If

    End Sub


    Private Sub loginPage_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblError.Visible = False
    End Sub

    Private Sub loginPage_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        MessageBox.Show("Thanks for using our system! Goodbye!", "SYSTEM CLOSE", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub
    Private Sub btnAccountCreation_Click(sender As Object, e As EventArgs) Handles btnAccountCreation.Click
        Me.Hide()
        FrmCustomerRegistration.Show()
    End Sub
End Class
