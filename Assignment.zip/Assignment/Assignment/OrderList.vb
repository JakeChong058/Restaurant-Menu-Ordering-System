﻿Public Class OrderList
    Private Property intOrderNo As Integer
    'Private Property intRecords As Integer
    'Private Property strMenuId As String
    Private Property btnView As Button
    Private Property menu As CustMenuItems

    Friend Sub New(intOrderNo As Integer, menu As CustMenuItems)
        Me.intOrderNo = intOrderNo
        'Me.decPrice = decPrice
        'Me.intRecords = intRecords
        Me.menu = menu
        btnView = New Button()
        btnView.Text = "&View"
        btnView.Font = New Font("Microsoft Sans Serif", 9, FontStyle.Bold)
        'btnAdd.Dock = DockStyle.Fill
        btnView.BackColor = Color.MediumTurquoise
    End Sub

    Friend Function GetIntOrderNo() As Integer
        Return intOrderNo
    End Function

    Friend Function GetBtnView() As Button
        Return btnView
    End Function

    Friend Function GetMenuItem() As CustMenuItems
        Return menu
    End Function
End Class
