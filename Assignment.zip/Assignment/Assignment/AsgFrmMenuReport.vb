﻿Imports System.Data.SqlClient
Imports System.Text
Imports System.Windows.Forms.AxHost

Public Class AsgFrmMenuReport
    Private da As SqlDataAdapter
    Private ds As DataSet = New DataSet()
    Private strGenerateDate As String
    Private topMenu() As StaffMenuItems
    Private menus() As StaffMenuItems
    Friend intNoOfOrders As Integer

    Private Sub AsgFrmMenuReport_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        AsgFrmStaffOrder.Hide()
        Dim strSql As String
        Dim intTopCount As Integer = 0
        Dim MSSqlCommand As New SqlCommand

        strGenerateDate = Date.Now
        lblNoOfOrders.Text = "WITH NUMBER OF ORDERS >= " & intNoOfOrders
        If StartConnection() = True Then
            strSql = "Select * From Menu"
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            Try
                da.Fill(ds, "Menu")
            Catch ex As Exception

            End Try
            ReDim menus(ds.Tables("Menu").Rows.Count - 1)
            If ds.Tables("Menu").Rows.Count > 0 Then
                For intIndex = 0 To menus.Length - 1 Step 1
                    menus(intIndex) = New StaffMenuItems(ds.Tables("Menu").Rows(intIndex).Item(0), ds.Tables("Menu").Rows(intIndex).Item(1),
                                      ds.Tables("Menu").Rows(intIndex).Item(2), ds.Tables("Menu").Rows(intIndex).Item(3),
                                      ds.Tables("Menu").Rows(intIndex).Item(4), ds.Tables("Menu").Rows(intIndex).Item(5),
                                      ds.Tables("Menu").Rows(intIndex).Item(6), ds.Tables("Menu").Rows(intIndex).Item(7),
                                      ds.Tables("Menu").Rows(intIndex).Item(8))
                Next intIndex

            End If
            EndConnection()
        End If

        For intIndex = 0 To menus.Length - 1 Step 1
            If StartConnection() = True Then
                strSql = "Select M.Description, O.Menu_Id, O.Price, O.Quantity From Menu M, Order_List O Where M.Menu_Id = O.Menu_Id AND M.Menu_Id = '" & menus(intIndex).GetStrMenuId() & "'"
                da = New SqlDataAdapter(strSql, connection)
                ds.Clear()
                Try
                    da.Fill(ds, "Menu")
                Catch ex As Exception
                End Try
                menus(intIndex).SetIntOrderCount(ds.Tables("Menu").Rows.Count)
                EndConnection()
            End If
            If StartConnection() = True Then
                strSql = "Update Menu set Order_Count = @Order_Count Where Menu_Id = @Menu_Id"
                MSSqlCommand = New SqlCommand(strSql, connection)
                MSSqlCommand.Parameters.AddWithValue("@Order_Count", menus(intIndex).GetIntOrderCount())
                MSSqlCommand.Parameters.AddWithValue("@Menu_Id", menus(intIndex).GetStrMenuId())
                MSSqlCommand.ExecuteNonQuery()
                EndConnection()
            End If

        Next intIndex

        For intIndex = 0 To menus.Length - 1 Step 1
            If menus(intIndex).GetIntOrderCount() >= intNoOfOrders Then
                intTopCount += 1
            End If
        Next intIndex
        ReDim topMenu(intTopCount - 1)
        For intIndex = 0 To topMenu.Length - 1 Step 1
            If menus(intIndex).GetIntOrderCount() >= intNoOfOrders Then
                topMenu(intIndex) = menus(intIndex)
            End If
        Next intIndex

        If StartConnection() = True Then
            strSql = "Select  Description, Menu_Id, Price, Order_Count From Menu Where Order_Count >= " & intNoOfOrders
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            Try
                da.Fill(ds, "Menus")
            Catch
            End Try
            If ds.Tables("Menus").Rows.Count > 0 Then
                DataGridView2.DataSource = ds.Tables("Menus")
                DataGridView2.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView2.Columns(0).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView2.Columns(0).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView2.Columns(1).HeaderText = "Menu ID"
                DataGridView2.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView2.Columns(1).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView2.Columns(1).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView2.Columns(2).HeaderText = "Price"
                DataGridView2.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView2.Columns(2).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView2.Columns(2).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView2.Columns(3).HeaderText = "No of Orders"
                DataGridView2.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView2.Columns(3).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView2.Columns(3).DefaultCellStyle.SelectionForeColor = Color.Black
            End If
            EndConnection()
        End If
        lblRecordCount.Text = ds.Tables("Menus").Rows.Count.ToString() & " record(s) "

    End Sub

    Private Sub mnuFileClose_Click(sender As Object, e As EventArgs) Handles mnuFileClose.Click
        Me.Close()
    End Sub

    Private Sub AsgFrmOrderReport_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        AsgFrmGenerateMenuReport.Show()
    End Sub

    Private Sub mnuAbout_Click(sender As Object, e As EventArgs) Handles mnuAbout.Click
        MessageBox.Show("Report generated at " & strGenerateDate, "About", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub mnuFilePrint_Click(sender As Object, e As EventArgs) Handles mnuFilePrint.Click
        dlgPreviewMenu.Document = doc
        dlgPreviewMenu.ShowDialog(Me)
    End Sub
    Private Sub doc_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles doc.PrintPage
        Dim fntHeader As New Font("Calibri", 24, FontStyle.Bold)
        Dim fntHeaders As New Font("Calibri", 24, FontStyle.Bold)
        Dim fntSubHeader As New Font("Calibri", 18)
        Dim fntSubHeaderAddress As New Font("Calibri", 14)
        Dim fntBody As New Font("Consolas", 10)

        Dim strHeader As String = " TOP MENU REPORT"
        Dim strHeaders As String = vbNewLine & " WITH NUMBER OF ORDERS >= " & intNoOfOrders
        Dim strSubHeader As String = " Island Cafe Inc."
        Dim strSubHeaderAddress As String = "Cyber Centre, KL, Main Campus" & vbNewLine & "  Jalan Genting Kelang Setapak"
        Dim body As New StringBuilder()
        body.AppendLine("Top Menu:")
        body.AppendLine("--------")
        body.AppendLine()
        body.AppendLine("Description  Menu ID  Price  No of Orders")
        body.AppendLine("-----------  -------  -----  ------------")
        For intIndex = 0 To menus.Length - 1 Step 1
            If menus(intIndex).GetIntOrderCount() >= intNoOfOrders Then
                body.AppendFormat("{0}  {1}     {2}  {3} " & vbNewLine,
                menus(intIndex).GetStrDescription(), menus(intIndex).GetStrMenuId(),
                menus(intIndex).GetDecPrice().ToString(), menus(intIndex).GetIntOrderCount().ToString)
            End If

        Next intIndex
        body.AppendLine()
        body.AppendLine()
        body.AppendLine()
        body.AppendLine()
        body.AppendLine("**************************************************************************************" & vbNewLine & vbNewLine & vbTab & vbTab & vbTab & vbTab & vbTab & " END OF REPORT" & vbNewLine & vbTab & vbTab & vbTab & "     This is a Computer-Generated Report" & vbNewLine & vbNewLine & "**************************************************************************************")
        '-------- --------------------- ----------- ------------------- -------- --------------
        With e.Graphics
            .DrawImage(My.Resources.Island_Cafe_Logo, 250, 0, 165, 180)
            .DrawString(strHeader, fntHeader, Brushes.Blue, 185, 270)
            .DrawString(strHeaders, fntHeaders, Brushes.Blue, 100, 270)
            .DrawString(strSubHeader, fntSubHeader, Brushes.Black, 250, 190)
            .DrawString(strSubHeaderAddress, fntSubHeaderAddress, Brushes.Black, 205, 220)
            .DrawString(body.ToString(), fntBody, Brushes.Black, 0, 360)
        End With
    End Sub
End Class