﻿Imports System.Data.SqlClient
Imports System.IO

Public Class AsgFrmUpadate
    Private opf As New OpenFileDialog()
    Private result As DialogResult
    Private da As SqlDataAdapter
    Private ds As DataSet = New DataSet()
    'Private blnIsFileUploaded As Boolean = False
    Private blnIsAdd As Boolean = False
    Friend strMenu As String
    Private Sub btnBrowse_Click(sender As Object, e As EventArgs) Handles btnBrowse.Click
        Dim strFileName As String()
        opf.Filter = "Choose Image(*.jpg;*.png;*.gif;*.jpeg)|*.jpg;*.png;*.gif;*.jpeg"
        result = opf.ShowDialog()
        If result <> DialogResult.Cancel Then
            strFileName = opf.FileName.Split("\"c)
            picImage.Image = Image.FromFile(opf.FileName)
            lblImageName.Text = strFileName(strFileName.Length - 1)
        End If
    End Sub

    Friend Sub IsAdd()
        blnIsAdd = True
    End Sub
    'Private Sub btnUpload_Click(sender As Object, e As EventArgs) Handles btnUpload.Click
    '    Dim strFileName As String()
    '    Try
    '        If result = DialogResult.OK Then
    '            strFileName = opf.FileName.Split("\"c)
    '            File.Copy(opf.FileName, "Images\" & strFileName(strFileName.Length - 1))
    '            'MessageBox.Show("File uploaded", "Upload Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information)
    '            blnIsFileUploaded = True
    '        Else
    '            MessageBox.Show("Please browse for an image before upload.", "No image found", MessageBoxButtons.OK, MessageBoxIcon.Warning)
    '        End If
    '    Catch ex As IOException
    '        MessageBox.Show("The image is in the folder already.", "Image duplicated", MessageBoxButtons.OK, MessageBoxIcon.Warning)
    '    End Try
    'End Sub

    'Private Sub btnShow_Click(sender As Object, e As EventArgs)
    '    Dim strImageName As String = ""
    '    strImageName = txtImageName.Text
    '    Try
    '        picPicture.Image = Image.FromFile("Upload\" & strImageName)
    '    Catch ex As FileNotFoundException
    '        MessageBox.Show("The file with the file name isn't exist", "File not found", MessageBoxButtons.OK, MessageBoxIcon.Error)
    '    End Try

    'End Sub

    Private Sub Form1_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        blnIsAdd = False
        'errValidation.Clear()
        AsgFrmStaffOrder.Show()
    End Sub

    'Private Sub txtMenuDescription_TextChanged(sender As Object, e As EventArgs) Handles txtMenuDescription.TextChanged

    'End Sub
    Private Sub txtMenuDescription_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtMenuDescription.Validating
        Dim strDescription As String = txtMenuDescription.Text
        If strDescription = "" Then
            errValidation.SetError(txtMenuDescription, "Please provide menu item description")
            e.Cancel = True ' Indicate the validating event DOES NOT pass (i.e. there is input error)
        Else
            errValidation.SetError(txtMenuDescription, Nothing) ' Remove the error from the error provider
        End If
    End Sub
    Private Sub txtPrice_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtPrice.Validating
        Dim strPrice As String = txtPrice.Text
        If strPrice = "" Then
            errValidation.SetError(txtPrice, "Please provide menu item price")
            e.Cancel = True ' Indicate the validating event DOES NOT pass (i.e. there is input error)
        Else
            errValidation.SetError(txtPrice, Nothing) ' Remove the error from the error provider
        End If
    End Sub
    Private Sub cboCategory_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles cboCategory.Validating
        'Dim strPrice As String = cboCategory.Text
        If cboCategory.SelectedIndex = -1 Then
            errValidation.SetError(cboCategory, "Please select the item category")
            e.Cancel = True ' Indicate the validating event DOES NOT pass (i.e. there is input error)
        Else
            errValidation.SetError(cboCategory, Nothing) ' Remove the error from the error provider
        End If
    End Sub
    Private Sub cboSubCategory_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles cboSubCategory.Validating
        'Dim strPrice As String = cboCategory.Text
        If cboSubCategory.SelectedIndex = -1 Then
            errValidation.SetError(cboSubCategory, "Please select the item sub-category")
            e.Cancel = True ' Indicate the validating event DOES NOT pass (i.e. there is input error)
        Else
            errValidation.SetError(cboSubCategory, Nothing) ' Remove the error from the error provider
        End If
    End Sub

    Private Sub cboStatus_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles cboStatus.Validating
        'Dim strPrice As String = cboCategory.Text
        If cboStatus.Visible = True And cboStatus.SelectedIndex = -1 Then
            errValidation.SetError(cboStatus, "Please determine the item status")
            e.Cancel = True ' Indicate the validating event DOES NOT pass (i.e. there is input error)
        Else
            errValidation.SetError(cboStatus, Nothing) ' Remove the error from the error provider
        End If
    End Sub

    Private Sub btnAddNewItem_Click(sender As Object, e As EventArgs) Handles btnAddNewItem.Click
        Dim MSSqlCommand As New SqlCommand
        Dim strSql As String
        Dim strMenuId As String = ""
        Dim strLastTwoDigits As String
        Dim intLastTwoDigits As Integer
        If Me.ValidateChildren() = False Then
            Return ' There are input error --> Stop insertion
        End If
        If lblImageName.Text = "" Then
            MessageBox.Show("Please upload the item image.", "Item Image Not Uploaded", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If
        Try
            Dim decPrice As Decimal = 0D
            decPrice = Decimal.Parse(txtPrice.Text)
        Catch ex As Exception
            MessageBox.Show("Error: Price requires numeric data.", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End Try

        If btnAddNewItem.Text = "&Add New Item" Then
            If cboCategory.SelectedItem = "Food" Then
                If StartConnection() = True Then
                    strSql = "Select * From Menu Where Category = 'Food'"
                    da = New SqlDataAdapter(strSql, connection)
                    ds.Clear()
                    Try
                        da.Fill(ds, "Menu")
                    Catch ex As Exception
                        'do something
                    End Try
                    If ds.Tables("Menu").Rows.Count > 0 Then
                        strLastTwoDigits = ds.Tables("Menu").Rows(ds.Tables("Menu").Rows.Count - 1).Item("Menu_Id").ToString().Substring(2, 2)
                        intLastTwoDigits = Integer.Parse(strLastTwoDigits) + 1
                        If intLastTwoDigits < 10 Then
                            strMenuId = "FD0" & intLastTwoDigits.ToString()
                        Else
                            strMenuId = "FD" & intLastTwoDigits.ToString()
                        End If
                    End If
                    intLastTwoDigits = 0
                    EndConnection()
                End If

            ElseIf cboCategory.SelectedItem = "Beverages" Then
                If StartConnection() = True Then
                    strSql = "Select * From Menu Where Category = 'Beverages'"
                    da = New SqlDataAdapter(strSql, connection)
                    ds.Clear()
                    Try
                        da.Fill(ds, "Menu")
                    Catch ex As Exception
                        'do something
                    End Try
                    If ds.Tables("Menu").Rows.Count > 0 Then
                        strLastTwoDigits = ds.Tables("Menu").Rows(ds.Tables("Menu").Rows.Count - 1).Item("Menu_Id").ToString().Substring(2, 2)
                        intLastTwoDigits = Integer.Parse(strLastTwoDigits) + 1
                        If intLastTwoDigits < 10 Then
                            strMenuId = "BE0" & intLastTwoDigits.ToString()
                        Else
                            strMenuId = "BE" & intLastTwoDigits.ToString()
                        End If

                    End If
                    intLastTwoDigits = 0
                    EndConnection()
                End If
            Else
                If StartConnection() = True Then
                    strSql = "Select * From Menu Where Category = 'Desserts'"
                    da = New SqlDataAdapter(strSql, connection)
                    ds.Clear()
                    Try
                        da.Fill(ds, "Menu")
                    Catch ex As Exception
                        'do something
                    End Try
                    If ds.Tables("Menu").Rows.Count > 0 Then
                        strLastTwoDigits = ds.Tables("Menu").Rows(ds.Tables("Menu").Rows.Count - 1).Item("Menu_Id").ToString().Substring(2, 2)
                        intLastTwoDigits = Integer.Parse(strLastTwoDigits) + 1
                        If intLastTwoDigits < 10 Then
                            strMenuId = "DE0" & intLastTwoDigits.ToString()
                        Else
                            strMenuId = "DE" & intLastTwoDigits.ToString()
                        End If
                    End If
                    intLastTwoDigits = 0
                    EndConnection()
                End If
            End If
            If StartConnection() = True Then
                Dim strFileName As String()
                Try
                    If result = DialogResult.OK Then
                        strFileName = opf.FileName.Split("\"c)
                        File.Copy(opf.FileName, "Images\" & strFileName(strFileName.Length - 1))
                        'MessageBox.Show("File uploaded", "Upload Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        'blnIsFileUploaded = True
                    Else
                        MessageBox.Show("Please browse for an image before upload.", "No image found", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                        Return
                    End If
                Catch ex As IOException
                    MessageBox.Show("The image is in the folder already.", "Image duplicated", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    Return
                End Try
                strSql = "Insert Into Menu(Menu_Id, Description, Price, Category, IsPromotion, SubCategory, Image, Status, Availability)
                 Values(@Menu_Id, @Description, @Price, @Category, @IsPromotion, @SubCategory, @Image, @Status, @Availability)"
                MSSqlCommand = New SqlCommand(strSql, connection)
                MSSqlCommand.Parameters.AddWithValue("@Menu_Id", strMenuId)
                MSSqlCommand.Parameters.AddWithValue("@Description", txtMenuDescription.Text.Trim())
                MSSqlCommand.Parameters.AddWithValue("@Price", txtPrice.Text.Trim())
                MSSqlCommand.Parameters.AddWithValue("@Category", cboCategory.SelectedItem)
                MSSqlCommand.Parameters.AddWithValue("@IsPromotion", "F")
                MSSqlCommand.Parameters.AddWithValue("@SubCategory", cboSubCategory.SelectedItem)
                MSSqlCommand.Parameters.AddWithValue("@Image", lblImageName.Text)
                MSSqlCommand.Parameters.AddWithValue("@Status", "Selling")
                MSSqlCommand.Parameters.AddWithValue("@Availability", "Available")
                'MSSqlCommand.Parameters.AddWithValue("@Status", "Waiting for Accept")
                'MSSqlCommand.Parameters.AddWithValue("@CardName", "")
                'MSSqlCommand.Parameters.AddWithValue("@CardNumber", "")
                'MSSqlCommand.Parameters.AddWithValue("@CVV", "")
                'MSSqlCommand.Parameters.AddWithValue("@CardExpDate", "")
                'MSSqlCommand.Parameters.AddWithValue("@Date", Date.Now)
                'MSSqlCommand.Parameters.AddWithValue("@Staff_Id", 1001)
                MSSqlCommand.ExecuteNonQuery()
                EndConnection()
                MessageBox.Show("Menu item has been added successfully!", "New Item Added", MessageBoxButtons.OK, MessageBoxIcon.Information)
                'blnIsFileUploaded = False
                btnClear_Click(Nothing, Nothing)
            End If
        Else
            If StartConnection() = True Then
                Dim strFileName As String()
                Dim strImageName As String
                Try
                    If lblImageName.Text = "" Then
                        If result = DialogResult.OK Then
                            strFileName = opf.FileName.Split("\"c)
                            File.Copy(opf.FileName, "Images\" & strFileName(strFileName.Length - 1))
                            'MessageBox.Show("File uploaded", "Upload Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information)
                            'blnIsFileUploaded = True
                        Else
                            'MessageBox.Show("Please browse for an image before upload.", "No image found", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                            'Return
                        End If
                    Else
                        Try
                            strImageName = lblImageName.Text
                            File.Copy(opf.FileName, "Images\" & strImageName)
                        Catch ex As Exception

                        End Try
                    End If
                Catch ex As IOException
                    MessageBox.Show("The image is in the folder already.", "Image duplicated", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    Return
                End Try
                strSql = "Update Menu Set Description = @Description, Price = @Price, Category = @Category, SubCategory = @SubCategory, Image = @Image, Status = @Status Where Menu_Id = @Menu_Id"
                MSSqlCommand = New SqlCommand(strSql, connection)
                MSSqlCommand.Parameters.AddWithValue("@Description", txtMenuDescription.Text.Trim())
                MSSqlCommand.Parameters.AddWithValue("@Price", txtPrice.Text.Trim())
                MSSqlCommand.Parameters.AddWithValue("@Category", cboCategory.SelectedItem)
                'MSSqlCommand.Parameters.AddWithValue("@IsPromotion", "F")
                MSSqlCommand.Parameters.AddWithValue("@SubCategory", cboSubCategory.SelectedItem)
                MSSqlCommand.Parameters.AddWithValue("@Image", lblImageName.Text)
                MSSqlCommand.Parameters.AddWithValue("@Status", cboStatus.SelectedItem)
                MSSqlCommand.Parameters.AddWithValue("@Menu_Id", lblItem.Text)
                'MSSqlCommand.Parameters.AddWithValue("@Availability", "Available")
                'MSSqlCommand.Parameters.AddWithValue("@Status", "Waiting for Accept")
                'MSSqlCommand.Parameters.AddWithValue("@CardName", "")
                'MSSqlCommand.Parameters.AddWithValue("@CardNumber", "")
                'MSSqlCommand.Parameters.AddWithValue("@CVV", "")
                'MSSqlCommand.Parameters.AddWithValue("@CardExpDate", "")
                'MSSqlCommand.Parameters.AddWithValue("@Date", Date.Now)
                'MSSqlCommand.Parameters.AddWithValue("@Staff_Id", 1001)
                MSSqlCommand.ExecuteNonQuery()
                EndConnection()
                MessageBox.Show("Menu item has been updated successfully!", "Item Updated", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        End If


    End Sub

    Private Sub AsgFrmUpadate_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim strSql As String
        Dim dataSets As DataSet = New DataSet()
        If blnIsAdd = True Then
            lblTitle.Text = "ADD MENU ITEM"
            btnAddNewItem.Text = "&Add New Item"
            Me.Text = "Add New Item"
            lblItem.Visible = False
            lblSelected.Visible = False
            lblStatus.Visible = False
            cboStatus.Visible = False
        Else
            lblTitle.Text = "EDIT MENU ITEM"
            btnAddNewItem.Text = "&Update Item"
            Me.Text = "Edit Menu Item"
            lblItem.Visible = True
            lblSelected.Visible = True
            lblStatus.Visible = True
            cboStatus.Visible = True
            If StartConnection() = True Then
                strSql = "Select * From Menu Where Menu_Id = '" & strMenu & "'"
                da = New SqlDataAdapter(strSql, connection)
                dataSets.Clear()
                Try
                    da.Fill(dataSets, "Menu")
                Catch ex As Exception
                    'do something
                End Try
                If dataSets.Tables("Menu").Rows.Count > 0 Then
                    lblItem.Text = dataSets.Tables("Menu").Rows(0).Item("Menu_Id")
                    txtMenuDescription.Text = dataSets.Tables("Menu").Rows(0).Item("Description")
                    txtPrice.Text = dataSets.Tables("Menu").Rows(0).Item("Price")
                    cboCategory.SelectedItem = dataSets.Tables("Menu").Rows(0).Item("Category")
                    If cboCategory.SelectedItem = "Food" Then
                        cboSubCategory.Items.Clear()
                        cboSubCategory.Items.Add("Western")
                        cboSubCategory.Items.Add("Chicken")
                        cboSubCategory.Items.Add("Salad and Soup")
                        cboSubCategory.SelectedItem = dataSets.Tables("Menu").Rows(0).Item("SubCategory")
                    ElseIf cboCategory.SelectedItem = "Beverages" Then
                        cboSubCategory.Items.Clear()
                        cboSubCategory.Items.Add("Coffee")
                        cboSubCategory.Items.Add("Tea")
                        cboSubCategory.Items.Add("Iced")
                        cboSubCategory.SelectedItem = dataSets.Tables("Menu").Rows(0).Item("SubCategory")
                    Else
                        cboSubCategory.Items.Clear()
                        cboSubCategory.Items.Add("Pudding")
                        cboSubCategory.Items.Add("Ice Cream")
                        cboSubCategory.Items.Add("Cake")
                        cboSubCategory.SelectedItem = dataSets.Tables("Menu").Rows(0).Item("SubCategory")
                    End If
                    cboStatus.SelectedItem = dataSets.Tables("Menu").Rows(0).Item("Status")
                    picImage.Image = Image.FromFile("Images\" & dataSets.Tables("Menu").Rows(0).Item("Image"))
                    lblImageName.Text = dataSets.Tables("Menu").Rows(0).Item("Image")
                    'blnIsFileUploaded = True
                End If
                EndConnection()
            End If
        End If
    End Sub

    Private Sub cboCategory_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboCategory.SelectedIndexChanged
        If cboCategory.SelectedItem = "Food" Then
            cboSubCategory.Items.Clear()
            cboSubCategory.Items.Add("Western")
            cboSubCategory.Items.Add("Chicken")
            cboSubCategory.Items.Add("Salad and Soup")
        ElseIf cboCategory.SelectedItem = "Beverages" Then
            cboSubCategory.Items.Clear()
            cboSubCategory.Items.Add("Coffee")
            cboSubCategory.Items.Add("Tea")
            cboSubCategory.Items.Add("Iced")
        ElseIf cboCategory.SelectedIndex = -1 Then
            cboSubCategory.Items.Clear()
        Else
            cboSubCategory.Items.Clear()
            cboSubCategory.Items.Add("Pudding")
            cboSubCategory.Items.Add("Ice Cream")
            cboSubCategory.Items.Add("Cake")
        End If

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtMenuDescription.Text = String.Empty
        txtPrice.Clear()
        picImage.Image = Nothing
        lblImageName.Text = ""
        cboCategory.SelectedIndex = -1
        cboSubCategory.Items.Clear()
        cboStatus.SelectedIndex = -1
        errValidation.Clear()
        'blnIsFileUploaded = False
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    'Private Sub txtPrice_TextChanged(sender As Object, e As EventArgs) Handles txtPrice.TextChanged

    'End Sub
End Class
