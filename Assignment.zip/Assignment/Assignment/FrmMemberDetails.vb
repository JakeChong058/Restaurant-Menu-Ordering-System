﻿Imports System.Data.SqlClient

Public Class FrmMemberDetails
    Private da As SqlDataAdapter
    Private ds As DataSet = New DataSet()
    Friend intMember As Integer = 0
    Friend Sub FrmMemberDetails_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim strSql As String
        'connection = New SqlConnection(connectionString)
        If StartConnection() = True Then
            strSql = "Select M.Member_Id, M.Member_Name, M.Member_Name, M.Member_IC, M.Cust_No, M.Member_Email, M.Gender, M.Points From Member M, Customer C Where M.Cust_No = C.Cust_No AND C.Cust_No = " & FrmMember.intCustNo
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            Try
                da.Fill(ds, "Customer")
            Catch ex As Exception

            End Try
            If ds.Tables("Customer").Rows.Count > 0 Then
                lblCust.Text = "Member Details of Customer [" & FrmMember.intCustNo.ToString() & "]"
                lblID.Text = ds.Tables("Customer").Rows(0).Item("Member_Id")
                lblName.Text = ds.Tables("Customer").Rows(0).Item("Member_Name")
                lblIC.Text = ds.Tables("Customer").Rows(0).Item("Member_IC")
                lblEmail.Text = ds.Tables("Customer").Rows(0).Item("Member_Email")
                lblGender.Text = ds.Tables("Customer").Rows(0).Item("Gender")
                lblPoints.Text = ds.Tables("Customer").Rows(0).Item("Points").ToString()
                intMember = Integer.Parse(lblID.Text)
            End If
            EndConnection()
        End If
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Close()
    End Sub

    Private Sub FrmMemberDetails_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        FrmMember.Show()
    End Sub

    Private Sub btnChangeData_Click(sender As Object, e As EventArgs) Handles btnChangeData.Click
        Dim strSql As String
        Dim strPosition As String = ""
        If StartConnection() = True Then
            strSql = "Select Position From Staff Where Staff_Id = " & frmStaffLoginPage.intCurrentStaffID
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            Try
                da.Fill(ds, "Staff")
            Catch ex As Exception

            End Try
            If ds.Tables("Staff").Rows.Count > 0 Then
                strPosition = ds.Tables("Staff").Rows(0).Item("Position")
            End If
            EndConnection()
        End If
        If strPosition <> "Administrator" Then
            MessageBox.Show("Admin access only! You are not authorised to perform this action.", "Forbidden Action", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            Me.Hide()
            FrmEditMembership.Show()
        End If
    End Sub
End Class