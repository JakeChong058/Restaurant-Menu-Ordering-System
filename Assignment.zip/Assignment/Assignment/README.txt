﻿Startup Forms for our system:
Customer side:
FrmLoginPage

Staff side:
frmHomePage