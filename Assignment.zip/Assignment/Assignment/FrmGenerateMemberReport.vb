﻿Public Class FrmGenerateMemberReport

    Friend intSelection As Integer
    Friend blnDescending As Boolean = False
    Private Sub btnGenerate_Click(sender As Object, e As EventArgs) Handles btnGenerate.Click

        If lstSelect.SelectedIndex = -1 Then
            MessageBox.Show("Please select a report to generate", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        ElseIf lstSelect.SelectedIndex = 0 Then
            blnDescending = True
            Me.Hide()
            FrmMemberReport.Show()
        ElseIf lstSelect.SelectedIndex = 1 Then
            intSelection = 50
            Me.Hide()
            FrmMemberReport.Show()
        Else
            intSelection = 200
            Me.Hide()
            FrmMemberReport.Show()
        End If

    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub FrmGenerateMemberReport_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        FrmMember.Show()
    End Sub
End Class