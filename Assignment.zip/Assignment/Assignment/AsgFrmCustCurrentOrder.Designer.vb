﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AsgFrmCustCurrentOrder
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.lblCart = New System.Windows.Forms.Label()
        Me.grpOrderInfo = New System.Windows.Forms.GroupBox()
        Me.lblTime = New System.Windows.Forms.Label()
        Me.lblPayment = New System.Windows.Forms.Label()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.lblPhone = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblID = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.grpPayment = New System.Windows.Forms.GroupBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Item = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lblService = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.lblGrand = New System.Windows.Forms.Label()
        Me.lblSST = New System.Windows.Forms.Label()
        Me.lblSubtotal = New System.Windows.Forms.Label()
        Me.lblQty = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblTax = New System.Windows.Forms.Label()
        Me.lblSub = New System.Windows.Forms.Label()
        Me.lblQuantity = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.btnBackMenu = New System.Windows.Forms.Button()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.grpOrderInfo.SuspendLayout()
        Me.grpPayment.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblCart
        '
        Me.lblCart.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCart.Location = New System.Drawing.Point(525, 225)
        Me.lblCart.Name = "lblCart"
        Me.lblCart.Size = New System.Drawing.Size(239, 47)
        Me.lblCart.TabIndex = 17
        Me.lblCart.Text = "YOUR ORDER"
        Me.lblCart.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'grpOrderInfo
        '
        Me.grpOrderInfo.Controls.Add(Me.lblTime)
        Me.grpOrderInfo.Controls.Add(Me.lblPayment)
        Me.grpOrderInfo.Controls.Add(Me.lblStatus)
        Me.grpOrderInfo.Controls.Add(Me.lblPhone)
        Me.grpOrderInfo.Controls.Add(Me.Label5)
        Me.grpOrderInfo.Controls.Add(Me.Label4)
        Me.grpOrderInfo.Controls.Add(Me.Label3)
        Me.grpOrderInfo.Controls.Add(Me.Label2)
        Me.grpOrderInfo.Controls.Add(Me.lblID)
        Me.grpOrderInfo.Controls.Add(Me.Label1)
        Me.grpOrderInfo.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpOrderInfo.Location = New System.Drawing.Point(9, 520)
        Me.grpOrderInfo.Name = "grpOrderInfo"
        Me.grpOrderInfo.Size = New System.Drawing.Size(580, 421)
        Me.grpOrderInfo.TabIndex = 18
        Me.grpOrderInfo.TabStop = False
        Me.grpOrderInfo.Text = "ORDER INFORMATION"
        '
        'lblTime
        '
        Me.lblTime.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTime.Location = New System.Drawing.Point(205, 376)
        Me.lblTime.Name = "lblTime"
        Me.lblTime.Size = New System.Drawing.Size(357, 30)
        Me.lblTime.TabIndex = 9
        Me.lblTime.Text = "Label6"
        '
        'lblPayment
        '
        Me.lblPayment.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPayment.Location = New System.Drawing.Point(205, 305)
        Me.lblPayment.Name = "lblPayment"
        Me.lblPayment.Size = New System.Drawing.Size(357, 30)
        Me.lblPayment.TabIndex = 8
        Me.lblPayment.Text = "Label6"
        '
        'lblStatus
        '
        Me.lblStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatus.Location = New System.Drawing.Point(205, 227)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(357, 30)
        Me.lblStatus.TabIndex = 7
        Me.lblStatus.Text = "Label6"
        '
        'lblPhone
        '
        Me.lblPhone.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPhone.Location = New System.Drawing.Point(205, 154)
        Me.lblPhone.Name = "lblPhone"
        Me.lblPhone.Size = New System.Drawing.Size(357, 30)
        Me.lblPhone.TabIndex = 6
        Me.lblPhone.Text = "Label6"
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(6, 377)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(201, 29)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "Order Time: "
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(6, 305)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(201, 29)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Payment Method: "
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(6, 224)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(201, 29)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Order Status: "
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(113, 153)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(94, 29)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Phone: "
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblID
        '
        Me.lblID.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblID.Location = New System.Drawing.Point(223, 86)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(127, 30)
        Me.lblID.TabIndex = 1
        Me.lblID.Text = "Order ID: "
        Me.lblID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(223, 46)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(127, 30)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Order ID: "
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'grpPayment
        '
        Me.grpPayment.Controls.Add(Me.DataGridView1)
        Me.grpPayment.Controls.Add(Me.lblService)
        Me.grpPayment.Controls.Add(Me.Label19)
        Me.grpPayment.Controls.Add(Me.lblGrand)
        Me.grpPayment.Controls.Add(Me.lblSST)
        Me.grpPayment.Controls.Add(Me.lblSubtotal)
        Me.grpPayment.Controls.Add(Me.lblQty)
        Me.grpPayment.Controls.Add(Me.Label6)
        Me.grpPayment.Controls.Add(Me.lblTax)
        Me.grpPayment.Controls.Add(Me.lblSub)
        Me.grpPayment.Controls.Add(Me.lblQuantity)
        Me.grpPayment.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpPayment.Location = New System.Drawing.Point(595, 520)
        Me.grpPayment.Name = "grpPayment"
        Me.grpPayment.Size = New System.Drawing.Size(620, 421)
        Me.grpPayment.TabIndex = 19
        Me.grpPayment.TabStop = False
        Me.grpPayment.Text = "ORDER SUMMARY"
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.DataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.White
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.White
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Item})
        Me.DataGridView1.Location = New System.Drawing.Point(38, 39)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.RowHeadersWidth = 62
        Me.DataGridView1.RowTemplate.Height = 28
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(540, 185)
        Me.DataGridView1.TabIndex = 12
        '
        'Item
        '
        Me.Item.HeaderText = "Item"
        Me.Item.MinimumWidth = 8
        Me.Item.Name = "Item"
        Me.Item.ReadOnly = True
        Me.Item.Width = 108
        '
        'lblService
        '
        Me.lblService.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblService.Location = New System.Drawing.Point(210, 339)
        Me.lblService.Name = "lblService"
        Me.lblService.Size = New System.Drawing.Size(345, 26)
        Me.lblService.TabIndex = 11
        Me.lblService.Text = "d"
        '
        'Label19
        '
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(7, 338)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(206, 27)
        Me.Label19.TabIndex = 10
        Me.Label19.Text = "Service Charge: "
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblGrand
        '
        Me.lblGrand.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGrand.Location = New System.Drawing.Point(210, 380)
        Me.lblGrand.Name = "lblGrand"
        Me.lblGrand.Size = New System.Drawing.Size(340, 26)
        Me.lblGrand.TabIndex = 8
        Me.lblGrand.Text = "e"
        '
        'lblSST
        '
        Me.lblSST.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSST.Location = New System.Drawing.Point(210, 305)
        Me.lblSST.Name = "lblSST"
        Me.lblSST.Size = New System.Drawing.Size(345, 26)
        Me.lblSST.TabIndex = 7
        Me.lblSST.Text = "c"
        '
        'lblSubtotal
        '
        Me.lblSubtotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubtotal.Location = New System.Drawing.Point(210, 265)
        Me.lblSubtotal.Name = "lblSubtotal"
        Me.lblSubtotal.Size = New System.Drawing.Size(345, 26)
        Me.lblSubtotal.TabIndex = 6
        Me.lblSubtotal.Text = "b"
        '
        'lblQty
        '
        Me.lblQty.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblQty.Location = New System.Drawing.Point(210, 227)
        Me.lblQty.Name = "lblQty"
        Me.lblQty.Size = New System.Drawing.Size(350, 26)
        Me.lblQty.TabIndex = 5
        Me.lblQty.Text = "a"
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(53, 380)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(160, 31)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "Grand Total: "
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblTax
        '
        Me.lblTax.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTax.Location = New System.Drawing.Point(58, 305)
        Me.lblTax.Name = "lblTax"
        Me.lblTax.Size = New System.Drawing.Size(155, 27)
        Me.lblTax.TabIndex = 3
        Me.lblTax.Text = "SST: "
        Me.lblTax.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblSub
        '
        Me.lblSub.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSub.Location = New System.Drawing.Point(53, 265)
        Me.lblSub.Name = "lblSub"
        Me.lblSub.Size = New System.Drawing.Size(160, 40)
        Me.lblSub.TabIndex = 2
        Me.lblSub.Text = "Subtotal: "
        Me.lblSub.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblQuantity
        '
        Me.lblQuantity.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblQuantity.Location = New System.Drawing.Point(18, 227)
        Me.lblQuantity.Name = "lblQuantity"
        Me.lblQuantity.Size = New System.Drawing.Size(195, 43)
        Me.lblQuantity.TabIndex = 1
        Me.lblQuantity.Text = "Total Quantity: "
        Me.lblQuantity.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(19, Byte), Integer), CType(CType(156, Byte), Integer), CType(CType(75, Byte), Integer))
        Me.Label7.Location = New System.Drawing.Point(350, 420)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(655, 64)
        Me.Label7.TabIndex = 20
        Me.Label7.Text = "Your Order has been placed successfully!"
        '
        'btnBackMenu
        '
        Me.btnBackMenu.BackColor = System.Drawing.Color.MediumTurquoise
        Me.btnBackMenu.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBackMenu.Location = New System.Drawing.Point(511, 982)
        Me.btnBackMenu.Name = "btnBackMenu"
        Me.btnBackMenu.Size = New System.Drawing.Size(216, 69)
        Me.btnBackMenu.TabIndex = 22
        Me.btnBackMenu.Text = "Back &To Menu"
        Me.btnBackMenu.UseVisualStyleBackColor = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.Assignment.My.Resources.Resources.tick
        Me.PictureBox2.Location = New System.Drawing.Point(562, 275)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(165, 142)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 21
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Assignment.My.Resources.Resources.Island_Cafe_Logo
        Me.PictureBox1.Location = New System.Drawing.Point(562, -3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(165, 180)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 7
        Me.PictureBox1.TabStop = False
        '
        'AsgFrmCustCurrentOrder
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1227, 1084)
        Me.Controls.Add(Me.btnBackMenu)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.grpPayment)
        Me.Controls.Add(Me.grpOrderInfo)
        Me.Controls.Add(Me.lblCart)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "AsgFrmCustCurrentOrder"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Your Order"
        Me.grpOrderInfo.ResumeLayout(False)
        Me.grpPayment.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents lblCart As Label
    Friend WithEvents grpOrderInfo As GroupBox
    Friend WithEvents lblPhone As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lblID As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents lblTime As Label
    Friend WithEvents lblPayment As Label
    Friend WithEvents lblStatus As Label
    Friend WithEvents grpPayment As GroupBox
    Friend WithEvents lblService As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents lblGrand As Label
    Friend WithEvents lblSST As Label
    Friend WithEvents lblSubtotal As Label
    Friend WithEvents lblQty As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents lblTax As Label
    Friend WithEvents lblSub As Label
    Friend WithEvents lblQuantity As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents btnBackMenu As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Item As DataGridViewTextBoxColumn
End Class
