﻿Public Class frmStaffLoginPage
    Friend intCurrentStaffID As Integer = 0
    Friend Sub frmStaffLoginPage_Load(sender As Object, e As EventArgs) Handles MyBase.Load, Me.Shown
        StaffData.currentStaff = Nothing
        StaffData.ConnectServer()
        txtStaffId.ForeColor = SystemColors.ControlLight
        txtStaffId.Text = "Staff Id"
        txtPassword.ForeColor = SystemColors.ControlLight
        txtPassword.Text = "Password"
        txtPassword.PasswordChar = ""
        btnLogIn.Focus()
    End Sub

    Private Sub frmStaffLoginPage_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        frmHomePage.Show()
    End Sub

    Private Sub txtStaffId_Enter(sender As Object, e As EventArgs) Handles txtStaffId.Enter
        If txtStaffId.Text = "Staff Id" Then
            txtStaffId.ForeColor = SystemColors.WindowText
            txtStaffId.Text = ""
        End If
    End Sub
    Private Sub txtStaffId_Leave(sender As Object, e As EventArgs) Handles txtStaffId.Leave
        If txtStaffId.Text = Nothing Then
            txtStaffId.ForeColor = SystemColors.ControlLight
            txtStaffId.Text = "Staff Id"
        End If
    End Sub
    Private Sub txtPassword_Leave(sender As Object, e As EventArgs) Handles txtPassword.Leave
        If txtPassword.Text = Nothing Then
            txtPassword.ForeColor = SystemColors.ControlLight
            txtPassword.Text = "Password"
            txtPassword.PasswordChar = ""
        End If
    End Sub
    Private Sub txtPassword_Enter(sender As Object, e As EventArgs) Handles txtPassword.Enter
        If txtPassword.Text = "Password" Then
            txtPassword.ForeColor = SystemColors.WindowText
            txtPassword.Text = ""
            txtPassword.PasswordChar = "*"
        End If
    End Sub
    Private Sub frmStaffLoginPage_Click(sender As Object, e As EventArgs) Handles Me.Click, Label1.Click, PictureBox1.Click, PictureBox2.Click, PictureBox3.Click
        btnLogIn.Focus()
    End Sub

    Private Sub btnLogIn_Click(sender As Object, e As EventArgs) Handles btnLogIn.Click
        Dim checkStaffExist As Boolean = False
        Dim strErrorMsg As String = ""
        If txtStaffId.Text = "Staff Id" Or txtStaffId.Text = "" Then
            strErrorMsg += "Please provide your Staff ID" & vbNewLine
        End If
        If txtPassword.Text = "" Or txtPassword.Text = "Password" Then
            strErrorMsg += "Please provide your Password" & vbNewLine
        End If
        If strErrorMsg <> "" Then
            MessageBox.Show(strErrorMsg, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            strErrorMsg = ""
            For intIndex = 0 To StaffData.staff.Length - 1
                If txtStaffId.Text = StaffData.staff(intIndex).GetStaff_Id.ToString() And txtPassword.Text = StaffData.staff(intIndex).GetPassword Then
                    checkStaffExist = True
                    StaffData.currentStaff = StaffData.staff(intIndex)
                    intCurrentStaffID = txtStaffId.Text.Trim()
                    frmStaffMainPage.Show()
                    Me.Hide()
                    Exit For
                End If
            Next
            If checkStaffExist = False Then
                MessageBox.Show("Invalid Staff Id or Password!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
        currentStaff = Nothing
        'frmHomePage.Show()
    End Sub

    Private Sub lblForgotPassword_Click(sender As Object, e As EventArgs) Handles lblForgotPassword.Click
        'StaffData.currentStaff = Nothing
        'StaffData.ConnectServer()
        Me.Hide()
        frmStaffForgotPassword.Show()
    End Sub
End Class
