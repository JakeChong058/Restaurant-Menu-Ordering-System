﻿Public Class StaffClass
    Private Shared CurrentID As Integer = 1000
    Private Property Staff_Id As Integer
    Private Property Staff_Name As String
    Private Property Position As String
    Private Property Password As String
    Private Property No_Of_Order As Integer
    Private Property Status As String
    Private Property SecretQuestion As String
    Private Property SecretAnswer As String


    Public Sub New(Staff_Id As Integer, Staff_Name As String, Position As String, Password As String, No_Of_Order As Integer, Status As String, SecretQuestion As String, SecretAnswer As String) ' extract all data from server
        Me.Staff_Id = Staff_Id
        Me.Staff_Name = Staff_Name
        Me.Position = Position
        Me.Password = Password
        Me.No_Of_Order = No_Of_Order
        Me.Status = Status
        Me.SecretQuestion = SecretQuestion
        Me.SecretAnswer = SecretAnswer
        StaffClass.CurrentID += 1
    End Sub
    Public Sub New(Staff_Name As String, Position As String, Password As String)
        Me.Staff_Id = CurrentID
        Me.Staff_Name = Staff_Name
        Me.Position = Position
        Me.Password = Password
        Me.No_Of_Order = 0
        Me.Status = "Available"
        StaffClass.CurrentID += 1
    End Sub
    Public Sub New(Staff_Id As Integer, Staff_Name As String, Position As String, No_Of_Order As Integer, Status As String) 'To Generate Printable Report
        Me.Staff_Id = Staff_Id
        Me.Staff_Name = Staff_Name
        Me.Position = Position
        Me.No_Of_Order = No_Of_Order
        Me.Status = Status
        Me.Password = ""
        Me.SecretAnswer = ""
        Me.SecretQuestion = ""
    End Sub
    Public Shared Function GetCurrentID() As Integer
        Return CurrentID
    End Function
    Public Function GetStaff_Id() As Integer
        Return Staff_Id
    End Function
    Public Function GetStaff_Name() As String
        Return Staff_Name
    End Function
    Public Function GetPosition() As String
        Return Position
    End Function
    Public Function GetPassword() As String
        Return Password
    End Function
    Public Function GetNo_Of_Order() As Integer
        Return No_Of_Order
    End Function
    Public Function GetStatus() As String
        Return Status
    End Function
    Public Function GetSecretQuestion() As String
        Return SecretQuestion
    End Function
    Public Function GetSecretAnswer() As String
        Return SecretAnswer
    End Function
    Public Sub SetStaff_Name(Staff_Name As String)
        Me.Staff_Name = Staff_Name
    End Sub
    Public Sub SetPosition(Position As String)
        Me.Position = Position
    End Sub
    Public Sub SetPassword(Password As String)
        Me.Password = Password
    End Sub
    Public Sub SetStatus(Status As String)
        Me.Status = Status
    End Sub
    Public Sub SetSecretQuestion(SecretQuestion As String)
        Me.SecretQuestion = SecretQuestion
    End Sub
    Public Sub SetSecretAnswer(SecretAnswer As String)
        Me.SecretAnswer = SecretAnswer
    End Sub
End Class
