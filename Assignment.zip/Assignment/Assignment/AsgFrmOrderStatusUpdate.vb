﻿Imports System.Data.SqlClient

Public Class AsgFrmOrderStatusUpdate
    Private da As SqlDataAdapter
    Private ds As DataSet = New DataSet()
    Private intOrderNumber As Integer
    Private strMethod As String
    'Testing
    Private intStaffId As Integer = frmStaffLoginPage.intCurrentStaffID
    Private intCustNo As Integer
    Private blnMember As Boolean = False
    Private intPoints As Integer = 0
    Private Sub AsgFrmOrderStatusUpdate_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim strSql As String
        Me.intOrderNumber = AsgFrmStaffCurrentOrder.intOrderNumber
        cboStatus.Items.Clear()
        If StartConnection() = True Then
            Dim custDS As DataSet = New DataSet()
            strSql = "Select F.Cust_No From Food_Order F, Customer C WHERE F.Cust_No = C.Cust_No AND F.Order_No = " & intOrderNumber
            'da = New SqlDataAdapter(strSql, connection) 'F.Cust_Id = " & intCustNo '& " And I.Menu_Id = '" & menuItem(intNumber).GetStrMenuId() & "'"
            da = New SqlDataAdapter(strSql, connection)
            custDS.Clear()
            Try
                da.Fill(custDS, "Food_Order")
            Catch ex As Exception
                'do something
            End Try
            If custDS.Tables("Food_Order").Rows.Count > 0 Then
                intCustNo = custDS.Tables("Food_Order").Rows(0).Item("Cust_No")
            End If
            EndConnection()
        End If
        If StartConnection() = True Then
            blnMember = False
            Dim custDS As DataSet = New DataSet()
            strSql = "Select Membership From Customer WHERE Cust_No = " & intCustNo
            'da = New SqlDataAdapter(strSql, connection) 'F.Cust_Id = " & intCustNo '& " And I.Menu_Id = '" & menuItem(intNumber).GetStrMenuId() & "'"
            da = New SqlDataAdapter(strSql, connection)
            custDS.Clear()
            Try
                da.Fill(custDS, "Customer")
            Catch ex As Exception
                'do something
            End Try
            If custDS.Tables("Customer").Rows.Count > 0 Then
                If custDS.Tables("Customer").Rows(0).Item("Membership") = "Member" Then
                    blnMember = True
                Else
                    blnMember = False
                End If
            End If
            EndConnection()
        End If
        If blnMember = True Then
            If StartConnection() = True Then
                'blnMember = False
                Dim custDS As DataSet = New DataSet()
                strSql = "Select Points From Member WHERE Cust_No = " & intCustNo
                'da = New SqlDataAdapter(strSql, connection) 'F.Cust_Id = " & intCustNo '& " And I.Menu_Id = '" & menuItem(intNumber).GetStrMenuId() & "'"
                da = New SqlDataAdapter(strSql, connection)
                custDS.Clear()
                Try
                    da.Fill(custDS, "Customer")
                Catch ex As Exception
                    'do something
                End Try
                If custDS.Tables("Customer").Rows.Count > 0 Then
                    intPoints = custDS.Tables("Customer").Rows(0).Item("Points")
                End If
                EndConnection()
            End If
        End If

        If StartConnection() = True Then
            strSql = "Select Order_No, Status, Payment_Method From Food_Order WHERE Order_No = " & intOrderNumber
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            Try
                da.Fill(ds, "Food_Order")
            Catch ex As Exception
                'do something
            End Try
            'ReDim orders(ds.Tables("Food_Order").Rows.Count - 1)
            'ReDim menus(ds.Tables("Food_Order").Rows.Count - 1)
            If ds.Tables("Food_Order").Rows.Count > 0 Then
                strMethod = ds.Tables("Food_Order").Rows(0).Item("Payment_Method")
                lblOrderID.Text = ds.Tables("Food_Order").Rows(0).Item("Order_No")
                If ds.Tables("Food_Order").Rows(0).Item("Status") = "Received" Then
                    cboStatus.Items.Add("Received")
                    cboStatus.Items.Add("Preparing")
                    cboStatus.SelectedIndex = 0
                ElseIf ds.Tables("Food_Order").Rows(0).Item("Status") = "Preparing" Then
                    cboStatus.Items.Add("Received")
                    cboStatus.Items.Add("Preparing")
                    cboStatus.Items.Add("Ready")
                    cboStatus.SelectedIndex = 1
                Else
                    cboStatus.Items.Add("Received")
                    cboStatus.Items.Add("Preparing")
                    cboStatus.Items.Add("Ready")
                    cboStatus.SelectedIndex = 2
                End If
            End If
            EndConnection()
        End If
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        'Console.WriteLine(cboStatus.SelectedItem)
        Dim strStatus As String = cboStatus.SelectedItem
        Dim strSql As String
        Dim MSSqlCommand As New SqlCommand
        Dim aDataSet As DataSet = New DataSet()
        Dim intNoOfOrder As Integer = 0
        If strMethod = "Pay by Credit Card" And strStatus = "Ready" Then
            If StartConnection() = True Then
                strSql = "Select * From Staff Where Staff_Id = " & frmStaffLoginPage.intCurrentStaffID
                da = New SqlDataAdapter(strSql, connection)
                aDataSet.Clear()
                Try
                    da.Fill(aDataSet, "Staff")
                Catch ex As Exception
                    'do something
                End Try
                If aDataSet.Tables("Staff").Rows.Count > 0 Then
                    intNoOfOrder = aDataSet.Tables("Staff").Rows(0).Item("No_Of_Order") + 1
                End If
                EndConnection()
            End If
            If StartConnection() = True Then
                strSql = "Update Staff set No_Of_Order = @No_Of_Order Where Staff_Id=@Staff_Id"
                MSSqlCommand = New SqlCommand(strSql, connection)
                MSSqlCommand.Parameters.AddWithValue("@No_Of_Order", intNoOfOrder)
                MSSqlCommand.Parameters.AddWithValue("@Staff_Id", frmStaffLoginPage.intCurrentStaffID)
                MSSqlCommand.ExecuteNonQuery()
                EndConnection()
                'Me.Hide()
            End If
            If blnMember = True Then
                If StartConnection() = True Then
                    strSql = "Update Member set Points = @Points Where Cust_No=@Cust_No"
                    MSSqlCommand = New SqlCommand(strSql, connection)
                    MSSqlCommand.Parameters.AddWithValue("@Points", intPoints + 10)
                    MSSqlCommand.Parameters.AddWithValue("@Cust_No", intCustNo)
                    MSSqlCommand.ExecuteNonQuery()
                    'MessageBox.Show("Payment of Order [" & intOrderNu & "] is completed!" & vbNewLine & "Receipt is generated and this order is completed." & vbNewLine & "You can view this order in Completed Order.", "Order Completed", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    'EndConnection()
                    'Me.Close()
                    EndConnection()
                    'Me.Hide()
                End If
                If StartConnection() = True Then
                    strSql = "Update Food_Order set Staff_Id = @Staff_Id, Status=@Status Where Order_No=@Order_No"
                    MSSqlCommand = New SqlCommand(strSql, connection)
                    MSSqlCommand.Parameters.AddWithValue("@Staff_Id", frmStaffLoginPage.intCurrentStaffID)
                    MSSqlCommand.Parameters.AddWithValue("@Status", "Completed")
                    MSSqlCommand.Parameters.AddWithValue("@Order_No", intOrderNumber)
                    MSSqlCommand.ExecuteNonQuery()
                    MessageBox.Show("Status of Order [" & intOrderNumber & "] has been updated.", "Order Status Updated Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    EndConnection()
                End If
            Else
                If StartConnection() = True Then
                    strSql = "Update Food_Order set Staff_Id = @Staff_Id, Status=@Status Where Order_No=@Order_No"
                    MSSqlCommand = New SqlCommand(strSql, connection)
                    MSSqlCommand.Parameters.AddWithValue("@Staff_Id", frmStaffLoginPage.intCurrentStaffID)
                    MSSqlCommand.Parameters.AddWithValue("@Status", "Completed")
                    MSSqlCommand.Parameters.AddWithValue("@Order_No", intOrderNumber)
                    MSSqlCommand.ExecuteNonQuery()
                    MessageBox.Show("Status of Order [" & intOrderNumber & "] has been updated.", "Order Status Updated Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    EndConnection()
                End If
            End If
        Else
            If StartConnection() = True Then
                strSql = "Update Food_Order set Status=@Status Where Order_No=@Order_No"
                MSSqlCommand = New SqlCommand(strSql, connection)
                MSSqlCommand.Parameters.AddWithValue("@Status", strStatus)
                MSSqlCommand.Parameters.AddWithValue("@Order_No", intOrderNumber)
                MSSqlCommand.ExecuteNonQuery()
                MessageBox.Show("Status of Order [" & intOrderNumber & "] has been updated.", "Order Status Updated Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information)
                'EndConnection()
                'Me.Close()
                EndConnection()
            End If
        End If
        AsgFrmStaffCompleteOrder.AsgFrmStaffCompleteOrder_Load(Nothing, Nothing)
        Me.Close()
    End Sub
End Class