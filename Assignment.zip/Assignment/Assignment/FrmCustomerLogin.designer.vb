﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmLoginPage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnLogin = New System.Windows.Forms.Button()
        Me.mskPhoneNumber = New System.Windows.Forms.MaskedTextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lbltxtPassword = New System.Windows.Forms.Label()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.btnAccountCreation = New System.Windows.Forms.Button()
        Me.pictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblError = New System.Windows.Forms.Label()
        CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(119, 483)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(281, 31)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Telphone Number:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnLogin
        '
        Me.btnLogin.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnLogin.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogin.Location = New System.Drawing.Point(192, 602)
        Me.btnLogin.Margin = New System.Windows.Forms.Padding(2)
        Me.btnLogin.Name = "btnLogin"
        Me.btnLogin.Size = New System.Drawing.Size(430, 55)
        Me.btnLogin.TabIndex = 2
        Me.btnLogin.Text = "Lets Go!"
        Me.btnLogin.UseVisualStyleBackColor = False
        '
        'mskPhoneNumber
        '
        Me.mskPhoneNumber.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.mskPhoneNumber.Location = New System.Drawing.Point(404, 483)
        Me.mskPhoneNumber.Margin = New System.Windows.Forms.Padding(2)
        Me.mskPhoneNumber.Mask = "0000000000"
        Me.mskPhoneNumber.Name = "mskPhoneNumber"
        Me.mskPhoneNumber.Size = New System.Drawing.Size(149, 35)
        Me.mskPhoneNumber.TabIndex = 5
        Me.mskPhoneNumber.ValidatingType = GetType(Date)
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(225, 398)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(348, 35)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Login and Get Started!"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbltxtPassword
        '
        Me.lbltxtPassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltxtPassword.Location = New System.Drawing.Point(234, 533)
        Me.lbltxtPassword.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lbltxtPassword.Name = "lbltxtPassword"
        Me.lbltxtPassword.Size = New System.Drawing.Size(166, 31)
        Me.lbltxtPassword.TabIndex = 8
        Me.lbltxtPassword.Text = "Password:"
        Me.lbltxtPassword.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'txtPassword
        '
        Me.txtPassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.txtPassword.Location = New System.Drawing.Point(405, 530)
        Me.txtPassword.Margin = New System.Windows.Forms.Padding(2)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPassword.Size = New System.Drawing.Size(148, 35)
        Me.txtPassword.TabIndex = 9
        '
        'btnAccountCreation
        '
        Me.btnAccountCreation.BackColor = System.Drawing.Color.White
        Me.btnAccountCreation.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAccountCreation.ForeColor = System.Drawing.Color.Blue
        Me.btnAccountCreation.Location = New System.Drawing.Point(192, 690)
        Me.btnAccountCreation.Margin = New System.Windows.Forms.Padding(2)
        Me.btnAccountCreation.Name = "btnAccountCreation"
        Me.btnAccountCreation.Size = New System.Drawing.Size(430, 36)
        Me.btnAccountCreation.TabIndex = 10
        Me.btnAccountCreation.Text = "Don't have an account? Create one now by clicking me"
        Me.btnAccountCreation.UseVisualStyleBackColor = False
        '
        'pictureBox1
        '
        Me.pictureBox1.Image = Global.Assignment.My.Resources.Resources.Island_Cafe_Logo
        Me.pictureBox1.Location = New System.Drawing.Point(325, 0)
        Me.pictureBox1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.pictureBox1.Name = "pictureBox1"
        Me.pictureBox1.Size = New System.Drawing.Size(165, 180)
        Me.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox1.TabIndex = 11
        Me.pictureBox1.TabStop = False
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(222, 195)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(362, 51)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "ISLAND CAFE"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(224, 247)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(378, 61)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "Cyber Centre, KL, Main Campus Jalan Genting Kelang Setapak "
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Lucida Handwriting", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(277, 321)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(260, 63)
        Me.Label5.TabIndex = 14
        Me.Label5.Text = "Welcome"
        '
        'lblError
        '
        Me.lblError.BackColor = System.Drawing.Color.Transparent
        Me.lblError.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblError.ForeColor = System.Drawing.Color.Red
        Me.lblError.Location = New System.Drawing.Point(11, 433)
        Me.lblError.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblError.Name = "lblError"
        Me.lblError.Size = New System.Drawing.Size(778, 35)
        Me.lblError.TabIndex = 15
        Me.lblError.Text = "Login and Get Started!"
        Me.lblError.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblError.Visible = False
        '
        'FrmLoginPage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(837, 740)
        Me.Controls.Add(Me.lblError)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.pictureBox1)
        Me.Controls.Add(Me.btnAccountCreation)
        Me.Controls.Add(Me.txtPassword)
        Me.Controls.Add(Me.lbltxtPassword)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.mskPhoneNumber)
        Me.Controls.Add(Me.btnLogin)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.MaximizeBox = False
        Me.Name = "FrmLoginPage"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Login"
        CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As Label
    Friend WithEvents btnLogin As Button
    Friend WithEvents mskPhoneNumber As MaskedTextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents lbltxtPassword As Label
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents btnAccountCreation As Button
    Friend WithEvents pictureBox1 As PictureBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lblError As Label
End Class
