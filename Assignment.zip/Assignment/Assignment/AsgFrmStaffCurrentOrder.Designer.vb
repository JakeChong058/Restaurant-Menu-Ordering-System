﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class AsgFrmStaffCurrentOrder
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.mnuUpcomingOrder = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuCurrentOrder = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuCompleteOrder = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblUpcomingOrder = New System.Windows.Forms.Label()
        Me.grpOverview = New System.Windows.Forms.GroupBox()
        Me.lblCredit = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblCash = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblOrderToday = New System.Windows.Forms.Label()
        Me.lblReady = New System.Windows.Forms.Label()
        Me.lblReceived = New System.Windows.Forms.Label()
        Me.lblPreparing = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.MenuStrip1.SuspendLayout()
        Me.grpOverview.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtSearch
        '
        Me.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSearch.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSearch.Location = New System.Drawing.Point(747, 74)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(388, 39)
        Me.txtSearch.TabIndex = 3
        '
        'MenuStrip1
        '
        Me.MenuStrip1.AutoSize = False
        Me.MenuStrip1.BackColor = System.Drawing.Color.LightCyan
        Me.MenuStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.MenuStrip1.GripMargin = New System.Windows.Forms.Padding(2, 2, 0, 2)
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuUpcomingOrder, Me.mnuCurrentOrder, Me.mnuCompleteOrder})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 179)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1226, 46)
        Me.MenuStrip1.TabIndex = 24
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'mnuUpcomingOrder
        '
        Me.mnuUpcomingOrder.AutoSize = False
        Me.mnuUpcomingOrder.Name = "mnuUpcomingOrder"
        Me.mnuUpcomingOrder.Size = New System.Drawing.Size(270, 42)
        Me.mnuUpcomingOrder.Text = "UPCOMING ORDERS"
        '
        'mnuCurrentOrder
        '
        Me.mnuCurrentOrder.AutoSize = False
        Me.mnuCurrentOrder.Name = "mnuCurrentOrder"
        Me.mnuCurrentOrder.Size = New System.Drawing.Size(270, 42)
        Me.mnuCurrentOrder.Text = "CURRENT ORDERS"
        '
        'mnuCompleteOrder
        '
        Me.mnuCompleteOrder.AutoSize = False
        Me.mnuCompleteOrder.Name = "mnuCompleteOrder"
        Me.mnuCompleteOrder.Size = New System.Drawing.Size(270, 42)
        Me.mnuCompleteOrder.Text = "COMPLETED ORDERS"
        '
        'lblUpcomingOrder
        '
        Me.lblUpcomingOrder.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUpcomingOrder.Location = New System.Drawing.Point(449, 225)
        Me.lblUpcomingOrder.Name = "lblUpcomingOrder"
        Me.lblUpcomingOrder.Size = New System.Drawing.Size(393, 29)
        Me.lblUpcomingOrder.TabIndex = 25
        Me.lblUpcomingOrder.Text = "CURRENT ORDERS"
        Me.lblUpcomingOrder.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'grpOverview
        '
        Me.grpOverview.Controls.Add(Me.lblCredit)
        Me.grpOverview.Controls.Add(Me.Label1)
        Me.grpOverview.Controls.Add(Me.Label2)
        Me.grpOverview.Controls.Add(Me.lblCash)
        Me.grpOverview.Controls.Add(Me.Label3)
        Me.grpOverview.Controls.Add(Me.Label6)
        Me.grpOverview.Controls.Add(Me.lblOrderToday)
        Me.grpOverview.Controls.Add(Me.lblReady)
        Me.grpOverview.Controls.Add(Me.lblReceived)
        Me.grpOverview.Controls.Add(Me.lblPreparing)
        Me.grpOverview.Controls.Add(Me.Label4)
        Me.grpOverview.Controls.Add(Me.Label5)
        Me.grpOverview.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpOverview.Location = New System.Drawing.Point(21, 270)
        Me.grpOverview.Name = "grpOverview"
        Me.grpOverview.Size = New System.Drawing.Size(1185, 167)
        Me.grpOverview.TabIndex = 26
        Me.grpOverview.TabStop = False
        Me.grpOverview.Text = "Overview"
        '
        'lblCredit
        '
        Me.lblCredit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCredit.Location = New System.Drawing.Point(893, 114)
        Me.lblCredit.Name = "lblCredit"
        Me.lblCredit.Size = New System.Drawing.Size(87, 30)
        Me.lblCredit.TabIndex = 11
        Me.lblCredit.Text = "Label2"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(13, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(438, 30)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Number of Current Orders: "
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(18, 74)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(433, 30)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Number of Received Orders: "
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblCash
        '
        Me.lblCash.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCash.Location = New System.Drawing.Point(893, 74)
        Me.lblCash.Name = "lblCash"
        Me.lblCash.Size = New System.Drawing.Size(87, 30)
        Me.lblCash.TabIndex = 10
        Me.lblCash.Text = "Label2"
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(13, 114)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(438, 30)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Number of Preparing Orders: "
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(551, 114)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(351, 30)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "Pay by Credit Card Orders:  "
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblOrderToday
        '
        Me.lblOrderToday.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOrderToday.Location = New System.Drawing.Point(451, 34)
        Me.lblOrderToday.Name = "lblOrderToday"
        Me.lblOrderToday.Size = New System.Drawing.Size(87, 30)
        Me.lblOrderToday.TabIndex = 1
        Me.lblOrderToday.Text = "Label2"
        '
        'lblReady
        '
        Me.lblReady.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblReady.Location = New System.Drawing.Point(893, 34)
        Me.lblReady.Name = "lblReady"
        Me.lblReady.Size = New System.Drawing.Size(87, 30)
        Me.lblReady.TabIndex = 9
        Me.lblReady.Text = "Label2"
        '
        'lblReceived
        '
        Me.lblReceived.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblReceived.Location = New System.Drawing.Point(451, 74)
        Me.lblReceived.Name = "lblReceived"
        Me.lblReceived.Size = New System.Drawing.Size(87, 30)
        Me.lblReceived.TabIndex = 6
        Me.lblReceived.Text = "Label2"
        '
        'lblPreparing
        '
        Me.lblPreparing.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPreparing.Location = New System.Drawing.Point(451, 114)
        Me.lblPreparing.Name = "lblPreparing"
        Me.lblPreparing.Size = New System.Drawing.Size(87, 30)
        Me.lblPreparing.TabIndex = 7
        Me.lblPreparing.Text = "Label2"
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(541, 34)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(355, 30)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Number of Ready Orders: "
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(546, 74)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(356, 30)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "Pay by Cash Orders:  "
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.DataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.White
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.Black
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Black
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.EnableHeadersVisualStyles = False
        Me.DataGridView1.Location = New System.Drawing.Point(25, 443)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.RowHeadersWidth = 62
        Me.DataGridView1.RowTemplate.Height = 28
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(1176, 479)
        Me.DataGridView1.TabIndex = 27
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Assignment.My.Resources.Resources.Island_Cafe_Logo
        Me.PictureBox1.Location = New System.Drawing.Point(562, -3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(165, 180)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(742, 40)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(238, 31)
        Me.Label7.TabIndex = 32
        Me.Label7.Text = "Search Order Records: "
        '
        'btnBack
        '
        Me.btnBack.BackColor = System.Drawing.Color.MediumTurquoise
        Me.btnBack.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnBack.Location = New System.Drawing.Point(97, 56)
        Me.btnBack.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(334, 48)
        Me.btnBack.TabIndex = 35
        Me.btnBack.Text = "&Back To Admin Gateway"
        Me.btnBack.UseVisualStyleBackColor = False
        '
        'AsgFrmStaffCurrentOrder
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.White
        Me.CancelButton = Me.btnBack
        Me.ClientSize = New System.Drawing.Size(1227, 944)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.grpOverview)
        Me.Controls.Add(Me.lblUpcomingOrder)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.txtSearch)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "AsgFrmStaffCurrentOrder"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Current Orders"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.grpOverview.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents txtSearch As TextBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents mnuUpcomingOrder As ToolStripMenuItem
    Friend WithEvents mnuCurrentOrder As ToolStripMenuItem
    Friend WithEvents mnuCompleteOrder As ToolStripMenuItem
    Friend WithEvents lblUpcomingOrder As Label
    Friend WithEvents grpOverview As GroupBox
    Friend WithEvents lblOrderToday As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lblReceived As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lblPreparing As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents lblCredit As Label
    Friend WithEvents lblCash As Label
    Friend WithEvents lblReady As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Label7 As Label
    Friend WithEvents btnBack As Button
End Class
