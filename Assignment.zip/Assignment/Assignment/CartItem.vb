﻿Public Class CartItem
    Private Property intCustNo As Integer
    'Private Property intRecords As Integer
    'Private Property strMenuId As String
    Private Property nmQuantity As NumericUpDown
    Private Property decPrice As Decimal
    Private Property btnRemove As Button
    Private Property menu As CustMenuItems

    Friend Sub New(intCustNo As Integer, menu As CustMenuItems)
        Me.intCustNo = intCustNo
        'Me.decPrice = decPrice
        'Me.intRecords = intRecords
        Me.menu = menu
        nmQuantity = New NumericUpDown()
        nmQuantity.Maximum = 10
        nmQuantity.Minimum = 1
        nmQuantity.Dock = DockStyle.Fill
        btnRemove = New Button()
        btnRemove.BackgroundImage = My.Resources.redcross
        btnRemove.BackgroundImageLayout = ImageLayout.Zoom
        btnRemove.Dock = DockStyle.Fill
    End Sub

    'Friend Sub New(intCustNo As Integer)
    '    Me.intCustNo = intCustNo
    '    'Me.decPrice = decPrice
    '    'Me.intRecords = intRecords
    '    'Me.menu = menu
    '    nmQuantity = New NumericUpDown()
    '    nmQuantity.Maximum = 10
    '    nmQuantity.Minimum = 1
    '    nmQuantity.Dock = DockStyle.Fill
    '    btnRemove = New Button()
    '    btnRemove.BackgroundImage = My.Resources.redcross
    '    btnRemove.BackgroundImageLayout = ImageLayout.Zoom
    '    btnRemove.Dock = DockStyle.Fill
    'End Sub

    Friend Function GetIntCustNo() As Integer
        Return intCustNo
    End Function

    Friend Function GetNMQuantity() As NumericUpDown
        Return nmQuantity
    End Function

    Friend Function GetDecPrice() As Decimal
        Return decPrice
    End Function

    Friend Function GetBtnRemove() As Button
        Return btnRemove
    End Function

    Friend Function GetMenuItem() As CustMenuItems
        Return menu
    End Function

    Friend Sub SetDecPrice(decPrice As Decimal)
        If menu.GetChIsPromotion() = "T" Then
            Me.decPrice = menu.GetDecDiscount() * nmQuantity.Value
        Else
            Me.decPrice = menu.GetDecPrice()
        End If
    End Sub

    Friend Sub SetDecPrice2(decPrice As Decimal)
        If menu.GetChIsPromotion() = "T" Then
            Me.decPrice = menu.GetDecDiscount() * nmQuantity.Value
        Else
            Me.decPrice = menu.GetDecPrice()
        End If
    End Sub
End Class
