﻿Imports System.Data.SqlClient
Imports System.Net
Imports Microsoft.VisualBasic.ApplicationServices

Public Class FrmCustomerRegistration
    Private da As SqlDataAdapter
    Private ds As DataSet = New DataSet()

    Private Sub txtPassword_TextChanged(sender As Object, e As EventArgs) Handles txtPassword.TextChanged
        If txtPassword.Text.Trim() = "" Then
            txtConfirmPassword.Enabled = False
        Else
            txtConfirmPassword.Enabled = True
        End If
    End Sub

    Private Sub btnCreate_Click(sender As Object, e As EventArgs) Handles btnCreate.Click
        Dim strQuery As String
        Dim MSSqlCommand As New SqlCommand
        Dim intNewCustNo As Integer = 0
        If Me.ValidateChildren() = False Then
            Return
        End If

        If StartConnection() = True Then
            strQuery = "SELECT Phone_Num FROM Customer WHERE Phone_Num = '" & mskPhoneNumber.Text & "'"
            da = New SqlDataAdapter(strQuery, connection)
            ds.Clear()
            Try
                da.Fill(ds, "Customer")
            Catch ex As Exception
            End Try
            If ds.Tables("Customer").Rows.Count > 0 Then
                MessageBox.Show("The phone number, " & mskPhoneNumber.Text & " is invalid since it has been used to create an account before.", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error)
                EndConnection()
                Return
            End If
            EndConnection()
        End If

        If StartConnection() = True Then
            strQuery = "SELECT Cust_No FROM Customer"
            da = New SqlDataAdapter(strQuery, connection)
            ds.Clear()
            Try
                da.Fill(ds, "Customer")
            Catch ex As Exception
            End Try
            If ds.Tables("Customer").Rows.Count > 0 Then
                intNewCustNo = Integer.Parse(ds.Tables("Customer").Rows(ds.Tables("Customer").Rows.Count - 1).Item("Cust_No")) + 1
            End If
            EndConnection()
        End If

        If StartConnection() = True Then
            strQuery = "Insert Into Customer(Cust_No, Phone_Num, Membership, Password)Values(@Cust_No, @Phone_Num, @Membership, @Password)"
            MSSqlCommand = New SqlCommand(strQuery, connection)
            MSSqlCommand.Parameters.AddWithValue("@Cust_No", intNewCustNo)
            MSSqlCommand.Parameters.AddWithValue("@Phone_Num", mskPhoneNumber.Text)
            MSSqlCommand.Parameters.AddWithValue("@Membership", "Not a member")
            MSSqlCommand.Parameters.AddWithValue("@Password", txtPassword.Text.Trim())
            MSSqlCommand.ExecuteNonQuery()
            MessageBox.Show("Your account has been created successfully!" & vbNewLine & "Please remember your phone number and password. You CANNOT change your PASSWORD after this." & vbNewLine & "Your phone number: " & mskPhoneNumber.Text & vbNewLine & "Your password: " & txtPassword.Text.Trim(), "Account Created", MessageBoxButtons.OK, MessageBoxIcon.Information)
            EndConnection()
            Me.Close()
        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        mskPhoneNumber.Clear()
        txtPassword.Clear()
        txtConfirmPassword.Clear()
        txtConfirmPassword.Enabled = False
        err.Clear()
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub FrmCustomerRegistration_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtConfirmPassword.Enabled = False
        btnCreate.Focus()
    End Sub

    Private Sub FrmCustomerRegistration_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        FrmLoginPage.Show()
    End Sub

    Private Sub mskPhoneNumber_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles mskPhoneNumber.Validating
        Dim strPhoneNumber As String = If(mskPhoneNumber.MaskCompleted, mskPhoneNumber.Text, "")

        If strPhoneNumber = "" Then
            err.SetError(mskPhoneNumber, "Please provide your phone number")
            e.Cancel = True
        Else
            err.SetError(mskPhoneNumber, Nothing)
        End If
    End Sub

    Private Sub txtPassword_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtPassword.Validating

        If txtPassword.Text.Trim() = "" Then
            err.SetError(txtPassword, "Please provide your password")
            e.Cancel = True
        Else
            err.SetError(txtPassword, Nothing)
        End If
    End Sub

    Private Sub txtConfirmPassword_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtConfirmPassword.Validating

        If txtConfirmPassword.Enabled = True Then
            If txtConfirmPassword.Text.Trim() = "" Then
                err.SetError(txtConfirmPassword, "Please confirm your password")
                e.Cancel = True
            ElseIf txtConfirmPassword.Text.Trim() <> txtPassword.Text.Trim() Then
                err.SetError(txtConfirmPassword, "Confirm password must be same with the password created")
                e.Cancel = True
            Else
                err.SetError(txtConfirmPassword, Nothing)
            End If
        End If

    End Sub
End Class