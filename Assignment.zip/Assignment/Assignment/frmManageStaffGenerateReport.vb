﻿Imports System.Data.SqlClient
Imports System.Text
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class frmManageStaffGenerateReport
    Private da As SqlDataAdapter
    Private ds As DataSet = New DataSet()
    Private intRecord As Integer
    Private intHigh As Integer
    Private intLow As Integer
    Private strDate As String
    Private GenerateReportStaffs() As StaffClass
    Private goodStaff As StaffClass
    Private badStaff As StaffClass
    Private currentView As String = ""
    'done
    Friend Sub loadDataGridView(strSql As String)
        'AsgFrmStaffCompleteOrder.Hide()

        strDate = Date.Now

        If StartConnection() = True Then
            ' strSql = frmManageStaff.strSQLAll
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            Try
                da.Fill(ds, "Staff")
            Catch ex As Exception
            End Try

            If ds.Tables("Staff").Rows.Count > 0 Then
                ReDim GenerateReportStaffs(ds.Tables("Staff").Rows.Count - 1)
                For intIndex = 0 To GenerateReportStaffs.Length - 1 Step 1
                    GenerateReportStaffs(intIndex) = New StaffClass(ds.Tables("Staff").Rows(intIndex).Item(0),
                    ds.Tables("Staff").Rows(intIndex).Item(1).ToString(), ds.Tables("Staff").Rows(intIndex).Item(2),
                    ds.Tables("Staff").Rows(intIndex).Item(3), ds.Tables("Staff").Rows(intIndex).Item(4))
                Next intIndex

                DataGridView1.DataSource = ds.Tables("Staff")
                DataGridView1.Columns(0).HeaderText = "Staff ID"
                DataGridView1.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(0).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(0).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(1).HeaderText = "Staff Name"
                DataGridView1.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(1).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(1).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(2).HeaderText = "Staff Position"
                DataGridView1.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(2).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(2).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(3).HeaderText = "No Of Order Completed"
                DataGridView1.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(3).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(3).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(4).HeaderText = "Staff Status"
                DataGridView1.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(4).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(4).DefaultCellStyle.SelectionForeColor = Color.Black

                intHigh = ds.Tables("Staff").Rows(0).Item("No_Of_Order")
                intLow = ds.Tables("Staff").Rows(ds.Tables("Staff").Rows.Count - 1).Item("No_Of_Order")
                For intIndex = 0 To ds.Tables("Staff").Rows.Count - 1 Step 1
                    If ds.Tables("Staff").Rows(intIndex).Item("No_Of_Order") > intHigh Then
                        intHigh = ds.Tables("Staff").Rows(intIndex).Item("No_Of_Order")
                    End If
                    If ds.Tables("Staff").Rows(intIndex).Item("No_Of_Order") < intLow Then
                        intLow = ds.Tables("Staff").Rows(intIndex).Item("No_Of_Order")
                    End If
                Next intIndex

                lblCountRecords.Text = ds.Tables("Staff").Rows.Count.ToString() & " records(s)"
            End If
            EndConnection()
        End If
        If StartConnection() = True Then
            Dim dataSets As DataSet = New DataSet()
            Dim strSqlMax As String
            strSqlMax = strSql + " AND No_Of_Order = " & intHigh
            da = New SqlDataAdapter(strSqlMax, connection)

            dataSets.Clear()
            Try
                da.Fill(dataSets, "Staff")
            Catch ex As Exception
            End Try
            If dataSets.Tables("Staff").Rows.Count > 0 Then
                goodStaff = New StaffClass(dataSets.Tables("Staff").Rows(0).Item(0),
                    dataSets.Tables("Staff").Rows(0).Item(1).ToString(), dataSets.Tables("Staff").Rows(0).Item(2),
                    dataSets.Tables("Staff").Rows(0).Item(3), dataSets.Tables("Staff").Rows(0).Item(4))
                DataGridView2.DataSource = dataSets.Tables("Staff")
                DataGridView2.Columns(0).HeaderText = "Staff ID"
                DataGridView2.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView2.Columns(0).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView2.Columns(0).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView2.Columns(1).HeaderText = "Staff Name"
                DataGridView2.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView2.Columns(1).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView2.Columns(1).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView2.Columns(2).HeaderText = "Staff Position"
                DataGridView2.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView2.Columns(2).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView2.Columns(2).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView2.Columns(3).HeaderText = "No Of Order Completed"
                DataGridView2.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView2.Columns(3).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView2.Columns(3).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView2.Columns(4).HeaderText = "Staff Status"
                DataGridView2.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView2.Columns(4).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView2.Columns(4).DefaultCellStyle.SelectionForeColor = Color.Black
            End If
            EndConnection()
        End If
        If StartConnection() = True Then
            Dim dataSetss As DataSet = New DataSet()
            Dim strSqlMin As String
            strSqlMin = strSql + " AND No_Of_Order = " & intLow

            da = New SqlDataAdapter(strSqlMin, connection)

            dataSetss.Clear()
            Try
                da.Fill(dataSetss, "Staff")
            Catch ex As Exception
            End Try
            If dataSetss.Tables("Staff").Rows.Count > 0 Then
                badStaff = New StaffClass(dataSetss.Tables("Staff").Rows(0).Item(0),
                    dataSetss.Tables("Staff").Rows(0).Item(1).ToString(), dataSetss.Tables("Staff").Rows(0).Item(2),
                    dataSetss.Tables("Staff").Rows(0).Item(3), dataSetss.Tables("Staff").Rows(0).Item(4))
                DataGridView3.DataSource = dataSetss.Tables("Staff")
                DataGridView3.Columns(0).HeaderText = "Staff ID"
                DataGridView3.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView3.Columns(0).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView3.Columns(0).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView3.Columns(1).HeaderText = "Staff Name"
                DataGridView3.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView3.Columns(1).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView3.Columns(1).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView3.Columns(2).HeaderText = "Staff Position"
                DataGridView3.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView3.Columns(2).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView3.Columns(2).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView3.Columns(3).HeaderText = "No Of Order Completed"
                DataGridView3.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView3.Columns(3).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView3.Columns(3).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView3.Columns(4).HeaderText = "Staff Status"
                DataGridView3.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView3.Columns(4).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView3.Columns(4).DefaultCellStyle.SelectionForeColor = Color.Black
            End If
            EndConnection()
        End If
    End Sub
    'done
    Private Sub mnuFileClose_Click(sender As Object, e As EventArgs) Handles mnuFileClose.Click
        Me.Close()
    End Sub
    'done
    Private Sub AsgFrmOrderReport_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed 'done
        frmManageStaffGenerateReportChoice.Show()
    End Sub
    'done
    Private Sub mnuAbout_Click(sender As Object, e As EventArgs) Handles mnuAbout.Click
        MessageBox.Show("Report generated at " & strDate, "About", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Friend Function adjustSpace(mylength As Integer, hislength As Integer)
        Dim strSpace As String = ""
        For intIndex = 1 To hislength - mylength
            strSpace += " "
        Next
        Return strSpace
    End Function
    Private Sub doc_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles doc.PrintPage
        'e.HasMorePages = True
        ' (1) Fonts
        Dim fntHeader As New Font("Calibri", 24, FontStyle.Bold)
        Dim fntSubHeader As New Font("Calibri", 18)
        Dim fntSubHeaderAddress As New Font("Calibri", 14)
        'Dim fntEndOfReport As New Font("Calibri", 14)
        Dim fntBody As New Font("Consolas", 10)
        ' (2) Prepare header and sub-header
        Dim strHeader As String = " STAFF RECORD REPORT" & vbNewLine
        Dim strSubHeader As String = " Island Cafe Inc."
        Dim strSubHeaderAddress As String = "Cyber Centre, KL, Main Campus" & vbNewLine & "  Jalan Genting Kelang Setapak"
        ' (3) Prepare body
        Dim body As New StringBuilder()
        body.AppendLine("RECORD:")
        body.AppendLine("------------")
        body.AppendLine()
        body.AppendLine("Staff ID           Staff Name           Staff Position No Of Order Completed Staff Status")
        body.AppendLine("-------- ------------------------------ -------------- --------------------- ------------")
        'body.AppendLine(8                       30               13              21                   12          )

        For intIndex = 0 To GenerateReportStaffs.Length - 1 Step 1
            body.AppendFormat("  {0}   {1}" & adjustSpace(GenerateReportStaffs(intIndex).GetStaff_Name().ToString().Length(), 30) & " {2}" & adjustSpace(GenerateReportStaffs(intIndex).GetPosition().ToString().Length(), 13) & " {3}" & adjustSpace(GenerateReportStaffs(intIndex).GetNo_Of_Order(), 21) & " {4}" & vbNewLine, GenerateReportStaffs(intIndex).GetStaff_Id.ToString, GenerateReportStaffs(intIndex).GetStaff_Name.ToString, GenerateReportStaffs(intIndex).GetPosition.ToString, GenerateReportStaffs(intIndex).GetNo_Of_Order.ToString, GenerateReportStaffs(intIndex).GetStatus.ToString)
        Next intIndex
        body.AppendFormat("{0}", lblCountRecords.Text)
        body.AppendLine()
        body.AppendLine()
        body.AppendLine()
        body.AppendLine()
        body.AppendLine("STAFF WITH THE HIGHEST NO OF ORDER COMPLETED:") 'Order With The Highest Payment Amount
        body.AppendLine("--------------------------------------------")
        body.AppendLine()
        body.AppendLine("Staff ID           Staff Name           Staff Position No Of Order Completed Staff Status")
        body.AppendLine("-------- ------------------------------ -------------- --------------------- ------------")
        'body.AppendLine(8                       30               13              21                   12          )
        body.AppendFormat("  {0}   {1}" & adjustSpace(goodStaff.GetStaff_Name().ToString().Length(), 30) & " {2}" & adjustSpace(goodStaff.GetPosition().ToString().Length(), 13) & " {3}" & adjustSpace(goodStaff.GetNo_Of_Order(), 21) & " {4}" & vbNewLine, goodStaff.GetStaff_Id.ToString, goodStaff.GetStaff_Name.ToString, goodStaff.GetPosition.ToString, goodStaff.GetNo_Of_Order.ToString, goodStaff.GetStatus.ToString)


        body.AppendLine()
        body.AppendLine()
        body.AppendLine()
        body.AppendLine()
        body.AppendLine("STAFF WITH THE LOWEST NO OF ORDER COMPLETED:") 'Order With The Highest Payment Amount
        body.AppendLine("-------------------------------------------")
        body.AppendLine()

        body.AppendLine("Staff ID           Staff Name           Staff Position No Of Order Completed Staff Status")
        body.AppendLine("-------- ------------------------------ -------------- --------------------- ------------")
        'body.AppendLine(8                       30               13              21                   12          )
        body.AppendFormat("  {0}   {1}" & adjustSpace(badStaff.GetStaff_Name().ToString().Length(), 30) & " {2}" & adjustSpace(badStaff.GetPosition().ToString().Length(), 13) & " {3}" & adjustSpace(badStaff.GetNo_Of_Order(), 21) & " {4}" & vbNewLine, badStaff.GetStaff_Id.ToString, badStaff.GetStaff_Name.ToString, badStaff.GetPosition.ToString, badStaff.GetNo_Of_Order.ToString, badStaff.GetStatus.ToString)



        body.AppendLine()
        body.AppendLine()
        body.AppendLine()
        body.AppendLine()
        body.AppendLine("**************************************************************************************" & vbNewLine & vbNewLine & vbTab & vbTab & vbTab & vbTab & vbTab & " END OF REPORT" & vbNewLine & vbTab & vbTab & vbTab & "     This is a Computer-Generated Report" & vbNewLine & vbNewLine & "**************************************************************************************")
        '-------- --------------------- ----------- ------------------- -------- --------------
        With e.Graphics
            .DrawImage(My.Resources.Island_Cafe_Logo, 250, 0, 165, 180)
            .DrawString(strHeader, fntHeader, Brushes.Blue, 200, 270)
            .DrawString(strSubHeader, fntSubHeader, Brushes.Black, 250, 190)
            .DrawString(strSubHeaderAddress, fntSubHeaderAddress, Brushes.Black, 205, 220)
            .DrawString(body.ToString(), fntBody, Brushes.Black, 0, 360)
        End With
    End Sub
    'done
    Private Sub mnuFilePrint_Click(sender As Object, e As EventArgs) Handles mnuFilePrint.Click
        dlgPreview.Document = doc
        dlgPreview.ShowDialog(Me)
    End Sub

    Private Sub frmManageStaffGenerateReport_Load(sender As Object, e As EventArgs) Handles MyBase.Load, Me.Shown
        frmManageStaff.Hide()
        DataGridView1.Columns.Clear()
        DataGridView1.DataSource = ""
        DataGridView2.Columns.Clear()
        DataGridView2.DataSource = ""
        DataGridView3.Columns.Clear()
        DataGridView3.DataSource = ""
        If frmManageStaffGenerateReportChoice.blnGenerateReportManager = True And frmManageStaffGenerateReportChoice.blnGenerateReportStaff = False And frmManageStaffGenerateReportChoice.blnGenerateReportStaffManager = False Then
            currentView = "Manager"
            loadDataGridView(frmManageStaff.strSQLManager)
        ElseIf frmManageStaffGenerateReportChoice.blnGenerateReportManager = False And frmManageStaffGenerateReportChoice.blnGenerateReportStaff = True And frmManageStaffGenerateReportChoice.blnGenerateReportStaffManager = False Then
            currentView = "Staff"
            loadDataGridView(frmManageStaff.strSQLStaff)
        ElseIf frmManageStaffGenerateReportChoice.blnGenerateReportManager = False And frmManageStaffGenerateReportChoice.blnGenerateReportStaff = False And frmManageStaffGenerateReportChoice.blnGenerateReportStaffManager = True Then
            currentView = "All"
            loadDataGridView(frmManageStaff.strSQLAll)
        End If
    End Sub
End Class