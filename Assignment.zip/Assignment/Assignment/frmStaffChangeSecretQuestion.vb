﻿Imports System.Data.SqlClient

Public Class frmStaffChangeSecretQuestion
    Private Sub frmStaffChangeSecretQuestion_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        StaffData.ConnectServer()
        cboSecretQuestion.SelectedIndex = 0
        txtSecretAnswer.Text = ""
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        Dim strErrorMsg As String = ""
        If cboSecretQuestion.SelectedIndex = 0 Or cboSecretQuestion.SelectedIndex = -1 Then
            strErrorMsg += "Please choose a new secret question." & vbNewLine
        End If
        If txtSecretAnswer.Text.Trim() = "" Then
            strErrorMsg += "Please fill the secret answer." & vbNewLine
        End If
        If strErrorMsg <> "" Then
            MessageBox.Show(strErrorMsg, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            Dim strSQLStatement As String
            Dim MSSqlCommand As New SqlCommand

            If StartConnection() = True Then

                strSQLStatement = "Update Staff set SecretQuestion=@secretquestion, SecretAnswer=@secretanswer where Staff_Id=@staffid"
                MSSqlCommand = New SqlCommand(strSQLStatement, connection)
                MSSqlCommand.Parameters.AddWithValue("@secretquestion", cboSecretQuestion.Items(cboSecretQuestion.SelectedIndex))
                MSSqlCommand.Parameters.AddWithValue("@secretanswer", txtSecretAnswer.Text.Trim())
                MSSqlCommand.Parameters.AddWithValue("@staffid", currentStaff.GetStaff_Id)
                MSSqlCommand.ExecuteNonQuery()
                EndConnection()
                MessageBox.Show("New Secret Question and Secret Answer has been uptated", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Me.Close()
            End If

        End If
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        cboSecretQuestion.SelectedIndex = 0
        txtSecretAnswer.Text = ""
    End Sub
End Class