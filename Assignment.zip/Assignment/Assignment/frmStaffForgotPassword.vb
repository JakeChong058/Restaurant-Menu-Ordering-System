﻿Public Class frmStaffForgotPassword
    Private Sub cboSecretQuestion_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboSecretQuestion.SelectedIndexChanged
        If cboSecretQuestion.SelectedIndex = 0 Then
            txtSecretAnswer.Enabled = False
            txtSecretAnswer.Text = ""
        Else
            txtSecretAnswer.Enabled = True
            txtSecretAnswer.ForeColor = SystemColors.ControlLight
            txtSecretAnswer.Text = "Your Answer"
        End If
    End Sub

    Private Sub frmForgotPassword_Load(sender As Object, e As EventArgs) Handles MyBase.Load, Me.Shown
        StaffData.ConnectServer()
        cboSecretQuestion.SelectedIndex = 0
        txtSecretAnswer.Enabled = False
        txtStaffId.ForeColor = SystemColors.ControlLight
        txtStaffId.Text = "Staff Id"
    End Sub

    Private Sub txtSecretAnswer_Enter(sender As Object, e As EventArgs) Handles txtSecretAnswer.Enter
        If txtSecretAnswer.Text = "Your Answer" Then
            txtSecretAnswer.ForeColor = SystemColors.WindowText
            txtSecretAnswer.Text = ""
        End If
    End Sub

    Private Sub txtSecretAnswer_Leave(sender As Object, e As EventArgs) Handles txtSecretAnswer.Leave
        If txtSecretAnswer.Text = Nothing Then
            txtSecretAnswer.ForeColor = SystemColors.ControlLight
            txtSecretAnswer.Text = "Your Answer"
        End If
    End Sub

    Private Sub txtStaffId_Enter(sender As Object, e As EventArgs) Handles txtStaffId.Enter
        If txtStaffId.Text = "Staff Id" Then
            txtStaffId.ForeColor = SystemColors.WindowText
            txtStaffId.Text = ""
        End If
    End Sub

    Private Sub txtStaffId_Leave(sender As Object, e As EventArgs) Handles txtStaffId.Leave
        If txtStaffId.Text = Nothing Then
            txtStaffId.ForeColor = SystemColors.ControlLight
            txtStaffId.Text = "Staff Id"
        End If
    End Sub

    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click
        Dim checkStaffExist As Boolean = False
        Dim strErrorMsg As String = ""

        If txtStaffId.Text = "Staff Id" Or txtStaffId.Text = "" Then
            strErrorMsg += "Please provide your Staff ID" & vbNewLine
        End If

        If cboSecretQuestion.SelectedIndex = -1 Or cboSecretQuestion.SelectedIndex = 0 Then
                strErrorMsg += "Please choose your Secret Question" & vbNewLine
            End If

        If txtSecretAnswer.Text = "" Or txtSecretAnswer.Text = "Your Answer" Then
            strErrorMsg += "Please provide your Secret Answer" & vbNewLine
        End If

        If strErrorMsg <> "" Then
            MessageBox.Show(strErrorMsg, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            strErrorMsg = ""
            For intIndex = 0 To StaffData.staff.Length - 1
                If txtStaffId.Text = StaffData.staff(intIndex).GetStaff_Id.ToString() And cboSecretQuestion.SelectedItem = StaffData.staff(intIndex).GetSecretQuestion And txtSecretAnswer.Text = StaffData.staff(intIndex).GetSecretAnswer Then
                    checkStaffExist = True
                    MessageBox.Show("Login Success! Your password is " & StaffData.staff(intIndex).GetPassword & ". Please try login again!", "Info", MessageBoxButtons.OK)
                    frmStaffLoginPage.Show()
                    Me.Close()
                    Exit For
                End If
            Next
            If checkStaffExist = False Then
                MessageBox.Show("Invalid Staff Id or Choice or Answer", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If



    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
        frmStaffLoginPage.Show()
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click, Me.Click, Label1.Click, PictureBox2.Click
        btnOK.Focus()
    End Sub

    Private Sub frmStaffForgotPassword_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        frmStaffLoginPage.frmStaffLoginPage_Load(Nothing, Nothing)
        frmStaffLoginPage.Show()
    End Sub
End Class