﻿Public Class frmStaffMainPage

    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        'frmStaffLoginPage.Show()
        StaffData.currentStaff = Nothing
        'frmStaffLoginPage.frmStaffLoginPage_Load(Nothing, Nothing)
        Me.Close()
    End Sub

    Private Sub lblManageOrder_Click(sender As Object, e As EventArgs) Handles lblManageOrder.Click
        Me.Hide()
        AsgFrmStaffUpcomingOrder.Show()
    End Sub

    Private Sub lblManagePromotion_Click(sender As Object, e As EventArgs) Handles lblManagePromotion.Click
        Me.Hide()
        FrmPromotion.Show()
    End Sub

    Private Sub lblManageStaff_Click(sender As Object, e As EventArgs) Handles lblManageStaff.Click
        If currentStaff.GetPosition() = "Manager" Or currentStaff.GetPosition() = "Administrator" Then
            frmManageStaff.Show()
            Me.Hide()
        Else
            MessageBox.Show("You are not authorised to manage staff", "Cannot Manage Staff", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If


    End Sub

    Private Sub lblManageMenu_Click(sender As Object, e As EventArgs) Handles lblManageMenu.Click
        Me.Hide()
        If AsgFrmStaffOrder.blnNotFirstVisit = True Then
            AsgFrmStaffOrder.AsgFrmStaffOrder_Load(Nothing, Nothing)
            AsgFrmStaffOrder.Show()
        Else
            AsgFrmStaffOrder.Show()
        End If
    End Sub

    Private Sub lblManageCustomerMembership_Click(sender As Object, e As EventArgs) Handles lblManageCustomerMembership.Click
        Me.Hide()
        FrmMember.Show()
    End Sub

    Private Sub lblProfile_Click(sender As Object, e As EventArgs) Handles lblProfile.Click
        frmStaffProfile.Show()
        Me.Hide()
    End Sub

    Private Sub frmStaffMainPage_Shown(sender As Object, e As EventArgs) Handles MyBase.Load
        StaffData.ConnectServer()
        lblCurrentStaffName.Text = "Welcome, " & StaffData.currentStaff.GetStaff_Name()
    End Sub

    Private Sub frmStaffMainPage_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        frmStaffLoginPage.frmStaffLoginPage_Load(Nothing, Nothing)
        frmStaffLoginPage.Show()
    End Sub
End Class
