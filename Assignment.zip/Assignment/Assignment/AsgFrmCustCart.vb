﻿Imports System.Data.SqlClient
Imports System.Windows.Forms.VisualStyles.VisualStyleElement.Tab

Public Class AsgFrmCustCart
    Private intCustNo = FrmLoginPage.intCustNo
    'Private decUpdatedPrice As Decimal
    'Friend strParts() As String
    Private da As SqlDataAdapter
    Private ds As DataSet = New DataSet()
    Private cartItem() As CartItem
    Private menus() As CustMenuItems
    Private descriptionLabel() As Label
    Private priceLabel() As Label
    Private blnFromOrder As Boolean = False
    Private Sub AsgFrmCustCart_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        AsgFrmCustOrder.Show()
    End Sub

    Friend Sub IsFromOrder()
        blnFromOrder = True
    End Sub

    Friend Sub AsgFrmCustCart_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim strSql As String
        If StartConnection() = True Then
            strSql = "Select M.Menu_Id, M.Description, I.Price, M.Category, M.IsPromotion, M.SubCategory, M.Image, M.Status, M.Availability, M.Order_Count, M.PromotionRate, M.Discounted_Price From Menu M, CartItem I, Customer C WHERE I.Cust_Id = C.Cust_No AND I.Menu_Id = M.Menu_Id AND I.Cust_Id = " & intCustNo
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            da.Fill(ds, "Menu")
            ReDim menus(ds.Tables("Menu").Rows.Count - 1)
            If ds.Tables("Menu").Rows.Count > 0 Then
                For intCount = 0 To menus.Length - 1 Step 1
                    If ds.Tables("Menu").Rows(intCount).Item("IsPromotion") = "T" Then
                        menus(intCount) = New CustMenuItems(ds.Tables("Menu").Rows(intCount).Item(0),
                    ds.Tables("Menu").Rows(intCount).Item(1), ds.Tables("Menu").Rows(intCount).Item(2),
                    ds.Tables("Menu").Rows(intCount).Item(3), ds.Tables("Menu").Rows(intCount).Item(4),
                    ds.Tables("Menu").Rows(intCount).Item(5), ds.Tables("Menu").Rows(intCount).Item(6),
                    ds.Tables("Menu").Rows(intCount).Item(7), ds.Tables("Menu").Rows(intCount).Item(8), ds.Tables("Menu").Rows(intCount).Item(9), ds.Tables("Menu").Rows(intCount).Item(10),
                    ds.Tables("Menu").Rows(intCount).Item(11))
                        'menus(intCount).SetPrice(menus(intCount).GetDecPromotionRate())
                    Else
                        menus(intCount) = New CustMenuItems(ds.Tables("Menu").Rows(intCount).Item(0),
                   ds.Tables("Menu").Rows(intCount).Item(1), ds.Tables("Menu").Rows(intCount).Item(2),
                   ds.Tables("Menu").Rows(intCount).Item(3), ds.Tables("Menu").Rows(intCount).Item(4),
                   ds.Tables("Menu").Rows(intCount).Item(5), ds.Tables("Menu").Rows(intCount).Item(6),
                   ds.Tables("Menu").Rows(intCount).Item(7), ds.Tables("Menu").Rows(intCount).Item(8))
                    End If
                Next intCount
            End If
            EndConnection()
        End If
        If StartConnection() = True Then
            strSql = "Select I.Cust_Id, I.Menu_Id, I.Price, I.Quantity From Menu M, CartItem I, Customer C WHERE I.Cust_Id = C.Cust_No AND I.Menu_Id = M.Menu_Id AND I.Cust_Id = " & intCustNo '& " AND I.Menu_Id = '" & menuItem(intNumber).GetStrMenuId() & "'"
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            Try
                da.Fill(ds, "CartItem")
            Catch ex As Exception
                'do something
            End Try
            If ds.Tables("CartItem").Rows.Count > 0 Then
                ReDim descriptionLabel(ds.Tables("CartItem").Rows.Count - 1)
                ReDim priceLabel(ds.Tables("CartItem").Rows.Count - 1)
                'ReDim decUpdatedPrice(ds.Tables("CartItem").Rows.Count - 1)
                lblEmpty.Visible = False
                TableLayoutPanel1.Visible = True
                btnClearCart.Enabled = True
                btnProceed.Enabled = True
                ReDim cartItem(ds.Tables("CartItem").Rows.Count - 1)
                TableLayoutPanel1.RowCount = ds.Tables("CartItem").Rows.Count + 1
                'TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 41))
                TableLayoutPanel1.Height = 33 * TableLayoutPanel1.RowCount
                TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 48))
                For intIndex = 0 To cartItem.Length - 1 Step 1
                    'TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 48))
                    'TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 0))
                    cartItem(intIndex) = New CartItem(ds.Tables("CartItem").Rows(intIndex).Item(0), menus(intIndex))
                    cartItem(intIndex).GetNMQuantity().Value = ds.Tables("CartItem").Rows(intIndex).Item("Quantity")
                    If blnFromOrder = True Then
                        cartItem(intIndex).SetDecPrice(ds.Tables("CartItem").Rows(intIndex).Item("Price"))
                        blnFromOrder = False
                    Else
                        cartItem(intIndex).SetDecPrice2(ds.Tables("CartItem").Rows(intIndex).Item("Price"))
                    End If
                    descriptionLabel(intIndex) = New Label()
                    descriptionLabel(intIndex).Text = cartItem(intIndex).GetMenuItem().GetStrDescription()
                    descriptionLabel(intIndex).Dock = DockStyle.Fill
                    descriptionLabel(intIndex).TextAlign = ContentAlignment.MiddleCenter
                    descriptionLabel(intIndex).Font = New Font("Microsoft Sans Serif", 12)
                    'descriptionLabel(intIndex).Height = 44
                    priceLabel(intIndex) = New Label()
                    'decUpdatedPrice(intIndex) = cartItem(intIndex).GetDecPrice()
                    priceLabel(intIndex).Text = cartItem(intIndex).GetDecPrice().ToString("C")
                    priceLabel(intIndex).Dock = DockStyle.Fill
                    priceLabel(intIndex).TextAlign = ContentAlignment.MiddleCenter
                    priceLabel(intIndex).Font = New Font("Microsoft Sans Serif", 12)
                    'priceLabel(intIndex).Height = 44
                    AddHandler cartItem(intIndex).GetBtnRemove().Click, AddressOf btnRemoveItem_Click
                    AddHandler cartItem(intIndex).GetNMQuantity().ValueChanged, AddressOf NumericUpDown1_ValueChanged
                    TableLayoutPanel1.Controls.Add(cartItem(intIndex).GetBtnRemove())
                    TableLayoutPanel1.Controls.Add(descriptionLabel(intIndex))
                    TableLayoutPanel1.Controls.Add(cartItem(intIndex).GetNMQuantity())
                    TableLayoutPanel1.Controls.Add(priceLabel(intIndex))
                Next intIndex
                'TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 45))
            Else
                TableLayoutPanel1.Visible = False
                lblEmpty.Visible = True
                btnClearCart.Enabled = False
                btnProceed.Enabled = False
            End If
        End If
        'MessageBox.Show(menuItem(intNumber).GetStrDescription() & " is added to your cart.", "Items Added To Cart", MessageBoxButtons.OK, MessageBoxIcon.Information)
        'strMenu = menuItem(intNumber).GetStrDescription() & vbTab & vbTab & vbTab & menuItem(intNumber).GetDecPrice().ToString("C") & vbTab & vbTab & vbTab & 1
        'AsgFrmCustCart.lstItems.Items.Add(strMenu)
        'btnCart.Enabled = True
        EndConnection()
    End Sub

    Private Sub btnRemoveItem_Click(sender As Object, e As EventArgs) Handles btnRemoveItem.Click
        For intNumber = 0 To cartItem.Length - 1 Step 1
            If sender Is cartItem(intNumber).GetBtnRemove() Then
                Dim MSSqlCommand As New SqlCommand
                Dim strSql As String
                Dim dlgSelection As DialogResult
                dlgSelection = MessageBox.Show(cartItem(intNumber).GetMenuItem().GetStrDescription() & " will be removed from your cart, sure to remove?", "Remove Item Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                If dlgSelection = DialogResult.Yes Then
                    If StartConnection() = True Then
                        strSql = "Delete from CartItem Where Cust_Id=@Cust_Id AND Menu_Id=@Menu_Id"
                        MSSqlCommand = New SqlCommand(strSql, connection)
                        MSSqlCommand.Parameters.AddWithValue("@Cust_Id", intCustNo)
                        MSSqlCommand.Parameters.AddWithValue("@Menu_Id", cartItem(intNumber).GetMenuItem().GetStrMenuId())
                        For intCount = 0 To cartItem.Length - 1 Step 1
                            TableLayoutPanel1.Controls.Remove(cartItem(intCount).GetBtnRemove())
                            TableLayoutPanel1.Controls.Remove(descriptionLabel(intCount))
                            TableLayoutPanel1.Controls.Remove(cartItem(intCount).GetNMQuantity())
                            TableLayoutPanel1.Controls.Remove(priceLabel(intCount))
                        Next intCount
                        MSSqlCommand.ExecuteNonQuery()
                        'MessageBox.Show("Record updated.", "Update Record"

                        EndConnection()
                        AsgFrmCartUpdate.ShowDialog()
                        AsgFrmCustCart_Load(Nothing, Nothing)
                        Exit For
                    Else
                        MessageBox.Show("Error connecting to database server.", "Error", MessageBoxButtons.OK)
                    End If
                End If
            End If
        Next intNumber
    End Sub

    'Private Sub btnClearCart_Click(sender As Object, e As EventArgs) Handles btnClearCart.Click
    '    lstItems.Items.Clear()
    '    AsgFrmCustCart_Load(Nothing, Nothing)
    'End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        AsgFrmCustOrder.Show()
        Me.Close()
        'AsgFrmCustCart_Closed(Nothing, Nothing)
    End Sub

    Private Sub btnProceed_Click(sender As Object, e As EventArgs) Handles btnProceed.Click
        'AsgFrmPayment.AsgFrmPayment_Load(Nothing, Nothing)
        AsgFrmPayment.Show()
        Me.Hide()
    End Sub

    Private Sub NumericUpDown1_ValueChanged(sender As Object, e As EventArgs) Handles NumericUpDown1.ValueChanged
        Dim intQuantity As Integer = 0
        Dim decUpdatedPrice As Decimal = 0D
        Dim decMenuPrice As Decimal = 0D
        Dim MSSqlCommand As New SqlCommand
        Dim strSql As String
        For intIndex = 0 To cartItem.Length - 1 Step 1
            If sender Is cartItem(intIndex).GetNMQuantity() Then
                intQuantity = cartItem(intIndex).GetNMQuantity().Value
                If cartItem(intIndex).GetMenuItem().GetChIsPromotion() = "T" Then
                    If StartConnection() = True Then
                        strSql = "Select M.Discounted_Price From Menu M, CartItem I Where M.Menu_Id = I.Menu_Id AND M.Menu_Id = '" & cartItem(intIndex).GetMenuItem().GetStrMenuId & "'"
                        da = New SqlDataAdapter(strSql, connection)
                        ds.Clear()
                        Try
                            da.Fill(ds, "Menu")
                        Catch ex As Exception
                            'do something
                        End Try
                        If ds.Tables("Menu").Rows.Count > 0 Then
                            decMenuPrice = ds.Tables("Menu").Rows(0).Item("Discounted_Price")
                        End If
                        EndConnection()
                    End If
                Else
                    If StartConnection() = True Then
                        strSql = "Select M.Price From Menu M, CartItem I Where M.Menu_Id = I.Menu_Id AND M.Menu_Id = '" & cartItem(intIndex).GetMenuItem().GetStrMenuId & "'"
                        da = New SqlDataAdapter(strSql, connection)
                        ds.Clear()
                        Try
                            da.Fill(ds, "Menu")
                        Catch ex As Exception
                            'do something
                        End Try
                        If ds.Tables("Menu").Rows.Count > 0 Then
                            decMenuPrice = ds.Tables("Menu").Rows(0).Item("Price")
                        End If
                        EndConnection()
                    End If
                End If

                decUpdatedPrice = decMenuPrice * intQuantity
                    'cartItem(intIndex).SetDecPrice(decUpdatedPrice)
                    If StartConnection() = True Then
                        strSql = "Update CartItem set Quantity = @Quantity, Price = @Price Where Cust_Id=@Cust_Id AND Menu_Id=@Menu_Id"
                        MSSqlCommand = New SqlCommand(strSql, connection)
                        MSSqlCommand.Parameters.AddWithValue("@Quantity", intQuantity)
                        MSSqlCommand.Parameters.AddWithValue("@Price", decUpdatedPrice)
                        MSSqlCommand.Parameters.AddWithValue("@Cust_Id", cartItem(intIndex).GetIntCustNo())
                        MSSqlCommand.Parameters.AddWithValue("@Menu_Id", cartItem(intIndex).GetMenuItem().GetStrMenuId())
                        MSSqlCommand.ExecuteNonQuery()
                        'MessageBox.Show("Record updated.", "Update Record"

                        EndConnection()
                        For intCount = 0 To cartItem.Length - 1 Step 1
                            TableLayoutPanel1.Controls.Remove(cartItem(intCount).GetBtnRemove())
                            TableLayoutPanel1.Controls.Remove(descriptionLabel(intCount))
                            TableLayoutPanel1.Controls.Remove(cartItem(intCount).GetNMQuantity())
                            TableLayoutPanel1.Controls.Remove(priceLabel(intCount))
                        Next intCount
                        AsgFrmCustCart_Load(Nothing, Nothing)
                    Else
                        MessageBox.Show("Error connecting to database server.", "Error", MessageBoxButtons.OK)
                    End If
                    'MessageBox.Show(cartItem(intNumber).GetMenuItem().GetStrDescription() & " is selected")
                End If
        Next intIndex
    End Sub

    Private Sub btnClearCart_Click(sender As Object, e As EventArgs) Handles btnClearCart.Click
        Dim MSSqlCommand As New SqlCommand
        Dim strSql As String
        Dim dlgSelection As DialogResult
        dlgSelection = MessageBox.Show("All items will be removed from your cart, sure to clear cart?", "Clear Cart Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If dlgSelection = DialogResult.Yes Then
            If StartConnection() = True Then
                strSql = "Delete from CartItem Where Cust_Id=@Cust_Id"
                MSSqlCommand = New SqlCommand(strSql, connection)
                MSSqlCommand.Parameters.AddWithValue("@Cust_Id", intCustNo)
                MSSqlCommand.ExecuteNonQuery()
                'MessageBox.Show("Record updated.", "Update Record"

                EndConnection()
                AsgFrmCustCart_Load(Nothing, Nothing)
            Else
                MessageBox.Show("Error connecting to database server.", "Error", MessageBoxButtons.OK)
            End If
        End If

    End Sub

    'Private Sub btnUpdateCart_Click(sender As Object, e As EventArgs) Handles btnUpdateCart.Click
    '    'Dim intCount As Integer = 0
    '    Dim intIndex As Integer
    '    If lstItems.SelectedIndex <> -1 Then
    '        strParts = CStr(lstItems.SelectedItem).Split(CChar(vbTab))
    '        For intCount = 0 To AsgFrmCustOrder.menuItem.Length - 1 Step 1
    '            If AsgFrmCustOrder.menuItem(intCount).GetStrDescription() = strParts(0) Then
    '                AsgFrmCartUpdate.lblDescription.Text = AsgFrmCustOrder.menuItem(intCount).GetStrDescription()
    '                AsgFrmCartUpdate.SetQuantity(strParts(6))
    '                AsgFrmCartUpdate.ShowDialog()
    '                intIndex = lstItems.SelectedIndex
    '                lstItems.Items.Remove(lstItems.SelectedItem)
    '                'lstItems.SelectedItem = 
    '                lstItems.Items.Insert(intIndex, strParts(0) & vbTab & vbTab & vbTab & strParts(3) & vbTab & vbTab & vbTab & strParts(6))
    '            End If
    '            'intCount += 1
    '        Next intCount
    '    Else
    '        MessageBox.Show("Please select an item to be updated", "NO ITEM SELECTED", MessageBoxButtons.OK, MessageBoxIcon.Warning)
    '    End If

    'End Sub

    'Private Sub lstItems_DoubleClick(sender As Object, e As EventArgs)
    '    btnUpdateCart_Click(Nothing, Nothing)
    'End Sub
End Class