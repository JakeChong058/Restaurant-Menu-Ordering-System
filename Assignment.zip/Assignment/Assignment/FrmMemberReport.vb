﻿Imports System.Data.SqlClient
Imports System.Text

Public Class FrmMemberReport
    Private da As SqlDataAdapter
    Private ds As DataSet = New DataSet()
    Private strDate As String
    Private Sub AsgFrmOrderReport_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        FrmMember.Hide()
        Dim strSql As String
        strDate = Date.Now
        If FrmGenerateMemberReport.blnDescending = True Then
            If StartConnection() = True Then
                strSql = "Select Member_Id, Member_Name, Gender, Points From Member Order By Points DESC"
                da = New SqlDataAdapter(strSql, connection)
                ds.Clear()
                Try
                    da.Fill(ds, "Member")
                Catch ex As Exception
                End Try
                DataGridView1.DataSource = ds.Tables("Member")
                If ds.Tables("Member").Rows.Count > 0 Then
                    DataGridView1.Columns(0).HeaderText = "Member ID"
                    DataGridView1.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    DataGridView1.Columns(0).DefaultCellStyle.SelectionBackColor = Color.White
                    DataGridView1.Columns(0).DefaultCellStyle.SelectionForeColor = Color.Black
                    DataGridView1.Columns(1).HeaderText = "Member Name"
                    DataGridView1.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    DataGridView1.Columns(1).DefaultCellStyle.SelectionBackColor = Color.White
                    DataGridView1.Columns(1).DefaultCellStyle.SelectionForeColor = Color.Black
                    DataGridView1.Columns(2).HeaderText = "Gender"
                    DataGridView1.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    DataGridView1.Columns(2).DefaultCellStyle.SelectionBackColor = Color.White
                    DataGridView1.Columns(2).DefaultCellStyle.SelectionForeColor = Color.Black
                    DataGridView1.Columns(3).HeaderText = "Membership Points"
                    DataGridView1.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    DataGridView1.Columns(3).DefaultCellStyle.SelectionBackColor = Color.White
                    DataGridView1.Columns(3).DefaultCellStyle.SelectionForeColor = Color.Black
                    DataGridView1.Columns(0).SortMode = DataGridViewColumnSortMode.NotSortable
                    DataGridView1.Columns(1).SortMode = DataGridViewColumnSortMode.NotSortable
                    DataGridView1.Columns(2).SortMode = DataGridViewColumnSortMode.NotSortable
                    DataGridView1.Columns(3).SortMode = DataGridViewColumnSortMode.NotSortable
                End If
                lblRecords.Text = ds.Tables("Member").Rows.Count.ToString() & " record(s) returned"
                lblCriteria.Text = ""
                EndConnection()
                FrmGenerateMemberReport.blnDescending = False
            End If
        Else
            If StartConnection() = True Then
                strSql = "Select Member_Id, Member_Name, Gender, Points From Member Where Points >= " & FrmGenerateMemberReport.intSelection
                da = New SqlDataAdapter(strSql, connection)
                'da.Pa
                ds.Clear()
                Try
                    da.Fill(ds, "Member")
                Catch ex As Exception
                End Try
                DataGridView1.DataSource = ds.Tables("Member")
                If ds.Tables("Member").Rows.Count > 0 Then
                    DataGridView1.Columns(0).HeaderText = "Member ID"
                    DataGridView1.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    DataGridView1.Columns(0).DefaultCellStyle.SelectionBackColor = Color.White
                    DataGridView1.Columns(0).DefaultCellStyle.SelectionForeColor = Color.Black
                    DataGridView1.Columns(1).HeaderText = "Member Name"
                    DataGridView1.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    DataGridView1.Columns(1).DefaultCellStyle.SelectionBackColor = Color.White
                    DataGridView1.Columns(1).DefaultCellStyle.SelectionForeColor = Color.Black
                    DataGridView1.Columns(2).HeaderText = "Gender"
                    DataGridView1.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    DataGridView1.Columns(2).DefaultCellStyle.SelectionBackColor = Color.White
                    DataGridView1.Columns(2).DefaultCellStyle.SelectionForeColor = Color.Black
                    DataGridView1.Columns(3).HeaderText = "Membership Points"
                    DataGridView1.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    DataGridView1.Columns(3).DefaultCellStyle.SelectionBackColor = Color.White
                    DataGridView1.Columns(3).DefaultCellStyle.SelectionForeColor = Color.Black
                End If
                lblRecords.Text = ds.Tables("Member").Rows.Count.ToString() & " record(s) returned"
                lblCriteria.Text = "WITH MEMBERSHIP POINTS >= " & FrmGenerateMemberReport.intSelection
                EndConnection()
            End If
        End If
    End Sub

    Private Sub mnuFileClose_Click(sender As Object, e As EventArgs) Handles mnuFileClose.Click
        Me.Close()
    End Sub
    'End Sub

    Private Sub AsgFrmOrderReport_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        FrmGenerateMemberReport.Show()
    End Sub

    Private Sub mnuAbout_Click(sender As Object, e As EventArgs) Handles mnuAbout.Click
        MessageBox.Show("Report generated at " & strDate, "About", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub doc_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles doc.PrintPage
        Dim fntHeader As New Font("Calibri", 24, FontStyle.Bold)
        Dim fntSubHeader As New Font("Calibri", 18)
        Dim fntSubHeaderAddress As New Font("Calibri", 14)
        Dim fntBody As New Font("Consolas", 10)
        Dim strHeader As String
        Dim strSubHeader As String
        Dim strSubHeaderAddress As String
        Dim body As New StringBuilder()
        Dim strSql As String
        Dim dataset As DataSet = New DataSet()
        If FrmGenerateMemberReport.lstSelect.SelectedIndex = 0 Then
            strHeader = " CUSTOMER MEMBERSHIP REPORT"
        Else
            strHeader = " CUSTOMER MEMBERSHIP REPORT" & vbNewLine & " WITH MEMBERSHIP POINTS >= " & FrmGenerateMemberReport.intSelection

        End If
        strSubHeader = "   Island Cafe Inc."
        strSubHeaderAddress = "Cyber Centre, KL, Main Campus" & vbNewLine & "  Jalan Genting Kelang Setapak"
        body.AppendLine("MEMBERS:")
        body.AppendLine("-------")
        body.AppendLine()
        body.AppendLine("Member ID      Member Name     Gender Membership Points")
        body.AppendLine("--------- -------------------- ------ -----------------")
        If FrmGenerateMemberReport.lstSelect.SelectedIndex = 0 Then
            If StartConnection() = True Then
                strSql = "Select Member_Id, Member_Name, Gender, Points From Member Order By Points DESC"
                da = New SqlDataAdapter(strSql, connection)
                'da.Pa
                dataset.Clear()
                Try
                    da.Fill(dataset, "Member")
                Catch ex As Exception
                End Try
                If dataset.Tables("Member").Rows.Count > 0 Then
                    For intIndex = 0 To dataset.Tables("Member").Rows.Count - 1 Step 1
                        body.AppendFormat("  {0}           {1}           {2}           {3}" & vbNewLine, dataset.Tables("Member").Rows(intIndex).Item("Member_Id"),
                                         dataset.Tables("Member").Rows(intIndex).Item("Member_Name"), dataset.Tables("Member").Rows(intIndex).Item("Gender"),
                                         dataset.Tables("Member").Rows(intIndex).Item("Points"))
                    Next intIndex
                End If
                EndConnection()
            End If
        Else
            If StartConnection() = True Then
                strSql = "Select Member_Id, Member_Name, Gender, Points From Member Where Points >= " & FrmGenerateMemberReport.intSelection
                da = New SqlDataAdapter(strSql, connection)
                'da.Pa
                dataset.Clear()
                Try
                    da.Fill(dataset, "Member")
                Catch ex As Exception
                End Try
                If dataset.Tables("Member").Rows.Count > 0 Then
                    For intIndex = 0 To dataset.Tables("Member").Rows.Count - 1 Step 1
                        body.AppendFormat("  {0}           {1}           {2}           {3}" & vbNewLine, dataset.Tables("Member").Rows(intIndex).Item("Member_Id"),
                                         dataset.Tables("Member").Rows(intIndex).Item("Member_Name"), dataset.Tables("Member").Rows(intIndex).Item("Gender"),
                                         dataset.Tables("Member").Rows(intIndex).Item("Points"))
                    Next intIndex
                End If
                EndConnection()
            End If
        End If
        body.AppendLine()
        body.AppendLine()
        body.AppendLine()
        body.AppendLine()
        body.AppendLine("**************************************************************************************" & vbNewLine & vbNewLine & vbTab & vbTab & vbTab & vbTab & vbTab & " END OF REPORT" & vbNewLine & vbTab & vbTab & vbTab & "     This is a Computer-Generated Report" & vbNewLine & vbNewLine & "**************************************************************************************")
        With e.Graphics
            .DrawImage(My.Resources.Island_Cafe_Logo, 310, 0, 165, 180)
            .DrawString(strHeader, fntHeader, Brushes.Blue, 150, 270)
            .DrawString(strSubHeader, fntSubHeader, Brushes.Black, 300, 190)
            .DrawString(strSubHeaderAddress, fntSubHeaderAddress, Brushes.Black, 260, 220)
            .DrawString(body.ToString(), fntBody, Brushes.Black, 70, 360)
        End With
    End Sub

    Private Sub mnuFilePrint_Click(sender As Object, e As EventArgs) Handles mnuFilePrint.Click
        dlgPreview.Document = doc
        dlgPreview.ShowDialog(Me)
    End Sub
End Class