﻿Public Class StaffMenuItems
    Private strDescription As String
    Private decPrice As Decimal
    Private btnEdit As Button
    Private btnDelete As Button
    Private Property chIsPromotion As Char
    Private Property strSubCategory As String
    Private Property strImage As String
    Private Property strStatus As String
    Private Property strAvailability As String
    Private Property strMenuId As String
    Private Property intOrderCount As Integer

    Public Sub New(strMenuId As String, strDescription As String, decPrice As Decimal, strCategory As String, chIsPromotion As Char, strSubCategory As String, strImage As String, strStatus As String, strAvailability As String)
        Me.strDescription = strDescription
        Me.decPrice = decPrice
        Me.strMenuId = strMenuId
        Me.chIsPromotion = chIsPromotion
        Me.strSubCategory = strSubCategory
        Me.strImage = strImage

        Me.btnEdit = New Button()
        Me.btnDelete = New Button()
        Me.strStatus = strStatus
        Me.strAvailability = strAvailability
        'btnDelete.Text = "Delete"
        'btnEdit.Text = "Edit"
        btnEdit.BackgroundImage = My.Resources.Pencil
        If Me.strAvailability = "Available" Then
            btnDelete.BackgroundImage = My.Resources.delete_icon
        Else
            btnDelete.BackgroundImage = My.Resources.Available
        End If
        'btnDelete.BackgroundImage = My.Resources.delete_icon
        btnEdit.BackgroundImageLayout = ImageLayout.Zoom
        btnDelete.BackgroundImageLayout = ImageLayout.Zoom

        btnDelete.Dock = DockStyle.Fill
        btnEdit.Dock = DockStyle.Fill
    End Sub

    Public Function GetStrDescription() As String
        Return strDescription
    End Function

    Public Function GetStrStatus() As String
        Return strStatus
    End Function
    Public Function GetStrAvailability() As String
        Return strAvailability
    End Function
    Public Function GetDecPrice() As Decimal
        Return decPrice
    End Function

    Public Function GetEditButton() As Button
        Return btnEdit
    End Function
    Public Function GetDeleteButton() As Button
        Return btnDelete
    End Function
    Public Function GetChIsPromotion() As Char
        Return chIsPromotion
    End Function

    Public Function GetStrSubCategory() As String
        Return strSubCategory
    End Function

    Public Function GetStrImage() As String
        Return strImage
    End Function
    Public Function GetStrMenuId() As String
        Return strMenuId
    End Function
    Friend Function GetIntOrderCount() As Integer
        Return intOrderCount
    End Function
    Friend Sub SetIntOrderCount(intOrderCount As Integer)
        Me.intOrderCount += intOrderCount
    End Sub

End Class