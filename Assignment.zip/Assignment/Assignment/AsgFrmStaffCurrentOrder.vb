﻿Imports System.Data.SqlClient

Public Class AsgFrmStaffCurrentOrder
    'Private intCustNo = 1001
    'Friend strParts() As String
    Private da As SqlDataAdapter
    Private ds As DataSet = New DataSet()
    'Friend order As OrderList
    Friend intOrderNumber As Integer
    'Private orders() As OrderList
    'Private menus() As CustMenuItems
    'The default order number
    'Private intOrderNo As Integer = 1001
    'Private intRowIndex As Integer = -2
    Private viewButtonCol As New DataGridViewButtonColumn
    Private updateButtonCol As New DataGridViewButtonColumn
    Private paymentButtonCol As New DataGridViewButtonColumn
    Private Sub AsgFrmStaffCurrentOrder_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim strSql As String
        Dim intReceiveCount As Integer = 0
        Dim intPrepareCount As Integer = 0
        Dim intReadyCount As Integer = 0
        Dim intCashCount As Integer = 0
        Dim intCreditCount As Integer = 0
        'Dim statusCboCol As DataGridViewComboBoxColumn = New DataGridViewComboBoxColumn
        If StartConnection() = True Then
            strSql = "Select O.Order_No, O.Date, O.Status, O.Payment_Method From Food_Order O, Customer C WHERE O.Cust_No = C.Cust_No AND O.Status <> 'Waiting for Accept' AND O.Status <> 'Completed'"
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            Try
                da.Fill(ds, "Food_Order")
            Catch ex As Exception
                'do something
            End Try
            'ReDim orders(ds.Tables("Food_Order").Rows.Count - 1)
            'ReDim menus(ds.Tables("Food_Order").Rows.Count - 1)
            If ds.Tables("Food_Order").Rows.Count > 0 Then
                DataGridView1.DataSource = ds.Tables("Food_Order")
                DataGridView1.Columns.Insert(4, viewButtonCol)
                DataGridView1.Columns.Insert(5, updateButtonCol)
                DataGridView1.Columns.Insert(6, paymentButtonCol)
                'DataGridView1.ColumnHeadersDefaultCellStyle.BackColor = Color.Black
                'DataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White
                'DataGridView1.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.Black
                'DataGridView1.ColumnHeadersDefaultCellStyle.SelectionForeColor = Color.White
                DataGridView1.Columns(0).HeaderText = "Order ID"
                DataGridView1.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(0).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(0).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(1).HeaderText = "Order Date and Time"
                DataGridView1.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(1).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(1).DefaultCellStyle.SelectionForeColor = Color.Black
                'DataGridView1.Columns(2).HeaderText = "Total Items"
                'DataGridView1.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                'DataGridView1.Columns(2).DefaultCellStyle.SelectionBackColor = Color.White
                'DataGridView1.Columns(2).DefaultCellStyle.SelectionForeColor = Color.Black
                'DataGridView1.Columns(3).HeaderText = "Placed By"
                'DataGridView1.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                'DataGridView1.Columns(3).DefaultCellStyle.SelectionBackColor = Color.White
                'DataGridView1.Columns(3).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(2).HeaderText = "Status"
                DataGridView1.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(2).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(2).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(3).HeaderText = "Payment Method"
                DataGridView1.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(3).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(3).DefaultCellStyle.SelectionForeColor = Color.Black
                viewButtonCol.HeaderText = "View Order List"
                viewButtonCol.Text = "View Order Items"
                updateButtonCol.HeaderText = "Update Order Status"
                updateButtonCol.Text = "Update"
                paymentButtonCol.HeaderText = "Make Order Payment"
                paymentButtonCol.Text = "Make Payment"
                'For intIndex = 0 To ds.Tables("Food_Order").Rows.Count - 1 Step 1
                '    If ds.Tables("Food_Order").Rows(intIndex).Item("Payment_Method") = "Pay by Credit Card" Then
                '        paymentButtonCol.Text = "Paid"
                '        paymentButtonCol.ReadOnly = True
                '    Else
                '        paymentButtonCol.Text = "Make Payment"
                '        paymentButtonCol.ReadOnly = False
                '    End If
                'Next intIndex
                'If 

                'statusCboCol.HeaderText = "Update Order Status"
                'For intCount = 0 To ds.Tables("Food_Order").Rows.Count - 1 Step 1
                '    If ds.Tables("Food_Order").Rows(intCount).Item("Status") = "Received" Then
                '        statusCboCol.Items.Add("Received")
                '        statusCboCol.Items.Add("Preparing")
                '        'AddHandler 
                '    ElseIf ds.Tables("Food_Order").Rows(intCount).Item("Status") = "Preparing" Then
                '        statusCboCol.Items.Add("Received")
                '        statusCboCol.Items.Add("Preparing")
                '        statusCboCol.Items.Add("Ready")
                '    End If
                'Next intCount
                'DataGridView1.Columns.Add(statusCboCol)

                'Console.WriteLine(statusCboCol.Items.Count & vbTab & statusCboCol.Items(0) & vbTab & statusCboCol.Items(1))
                'buttonCol.BackColor = Color.MediumTurquoise
                viewButtonCol.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 10, FontStyle.Bold)
                viewButtonCol.UseColumnTextForButtonValue = True
                viewButtonCol.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                viewButtonCol.FlatStyle = FlatStyle.Popup
                viewButtonCol.DefaultCellStyle.BackColor = Color.MediumTurquoise
                viewButtonCol.DefaultCellStyle.SelectionBackColor = Color.MediumTurquoise
                viewButtonCol.DefaultCellStyle.SelectionForeColor = Color.Black
                updateButtonCol.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 10, FontStyle.Bold)
                updateButtonCol.UseColumnTextForButtonValue = True
                updateButtonCol.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                updateButtonCol.FlatStyle = FlatStyle.Popup
                updateButtonCol.DefaultCellStyle.BackColor = Color.MediumTurquoise
                updateButtonCol.DefaultCellStyle.SelectionBackColor = Color.MediumTurquoise
                updateButtonCol.DefaultCellStyle.SelectionForeColor = Color.Black
                paymentButtonCol.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 10, FontStyle.Bold)
                paymentButtonCol.UseColumnTextForButtonValue = True
                paymentButtonCol.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                paymentButtonCol.FlatStyle = FlatStyle.Popup
                paymentButtonCol.DefaultCellStyle.BackColor = Color.MediumTurquoise
                paymentButtonCol.DefaultCellStyle.SelectionBackColor = Color.MediumTurquoise
                paymentButtonCol.DefaultCellStyle.SelectionForeColor = Color.Black
                lblOrderToday.Text = ds.Tables("Food_Order").Rows.Count.ToString()
                For intIndex = 0 To ds.Tables("Food_Order").Rows.Count - 1 Step 1
                    If ds.Tables("Food_Order").Rows(intIndex).Item("Status") = "Received" Then
                        intReceiveCount += 1
                    ElseIf ds.Tables("Food_Order").Rows(intIndex).Item("Status") = "Preparing" Then
                        intPrepareCount += 1
                    Else
                        intReadyCount += 1
                    End If

                    If ds.Tables("Food_Order").Rows(intIndex).Item("Payment_Method") = "Pay by Cash" Then
                        intCashCount += 1
                    Else
                        intCreditCount += 1
                    End If
                Next intIndex
                lblReceived.Text = intReceiveCount.ToString()
                lblPreparing.Text = intPrepareCount.ToString()
                lblReady.Text = intReadyCount.ToString()
                lblCash.Text = intCashCount.ToString()
                lblCredit.Text = intCreditCount.ToString()
            End If
            EndConnection()
        End If
        'If StartConnection() = True Then
        '    Dim dataSet As DataSet = New DataSet()
        '    strSql = "Select Status From Food_Order WHERE Status = 'Received'"
        '    da = New SqlDataAdapter(strSql, connection)
        '    dataSet.Clear()
        '    Try
        '        da.Fill(dataSet, "Food_Order")
        '    Catch ex As Exception
        '        'do something
        '    End Try
        '    'ReDim orders(ds.Tables("Food_Order").Rows.Count - 1)
        '    'ReDim menus(ds.Tables("Food_Order").Rows.Count - 1)
        '    lblReceived.Text = dataSet.Tables("Food_Order").Rows.Count.ToString()
        '    EndConnection()
        'End If
        'If StartConnection() = True Then
        '    Dim dataSet2 As DataSet = New DataSet()
        '    strSql = "Select Status From Food_Order WHERE Status = 'Preparing'"
        '    da = New SqlDataAdapter(strSql, connection)
        '    dataSet2.Clear()
        '    Try
        '        da.Fill(dataSet2, "Food_Order")
        '    Catch ex As Exception
        '        'do something
        '    End Try
        '    'ReDim orders(ds.Tables("Food_Order").Rows.Count - 1)
        '    'ReDim menus(ds.Tables("Food_Order").Rows.Count - 1)
        '    lblPreparing.Text = dataSet2.Tables("Food_Order").Rows.Count.ToString()
        '    EndConnection()
        'End If
        'If StartConnection() = True Then
        '    Dim dataSet3 As DataSet = New DataSet()
        '    strSql = "Select Status From Food_Order WHERE Status = 'Ready'"
        '    da = New SqlDataAdapter(strSql, connection)
        '    dataSet3.Clear()
        '    Try
        '        da.Fill(dataSet3, "Food_Order")
        '    Catch ex As Exception
        '        'do something
        '    End Try
        '    'ReDim orders(ds.Tables("Food_Order").Rows.Count - 1)
        '    'ReDim menus(ds.Tables("Food_Order").Rows.Count - 1)
        '    lblReady.Text = dataSet3.Tables("Food_Order").Rows.Count.ToString()
        '    EndConnection()
        'End If
        'If StartConnection() = True Then
        '    Dim dataSet4 As DataSet = New DataSet()
        '    strSql = "Select Payment_Method From Food_Order WHERE Payment_Method = 'Pay by Cash'"
        '    da = New SqlDataAdapter(strSql, connection)
        '    ds.Clear()
        '    Try
        '        da.Fill(dataSet4, "Food_Order")
        '    Catch ex As Exception
        '        'do something
        '    End Try
        '    'ReDim orders(ds.Tables("Food_Order").Rows.Count - 1)
        '    'ReDim menus(ds.Tables("Food_Order").Rows.Count - 1)
        '    lblCash.Text = dataSet4.Tables("Food_Order").Rows.Count.ToString()
        '    EndConnection()
        'End If
        'If StartConnection() = True Then
        '    Dim dataSet5 As DataSet = New DataSet()
        '    strSql = "Select Status From Food_Order WHERE Payment_Method = 'Pay by Credit Card'"
        '    da = New SqlDataAdapter(strSql, connection)
        '    dataSet5.Clear()
        '    Try
        '        da.Fill(dataSet5, "Food_Order")
        '    Catch ex As Exception
        '        'do something
        '    End Try
        '    'ReDim orders(ds.Tables("Food_Order").Rows.Count - 1)
        '    'ReDim menus(ds.Tables("Food_Order").Rows.Count - 1)
        '    lblCredit.Text = dataSet5.Tables("Food_Order").Rows.Count.ToString()
        '    EndConnection()
        'End If
    End Sub

    Private Sub RemoveButtonColumns()
        DataGridView1.Columns.Clear()
        DataGridView1.DataSource = ""
        AsgFrmStaffCurrentOrder_Load(Nothing, Nothing)
    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        'Dim strSql As String
        Try
            If DataGridView1.Columns(e.ColumnIndex).HeaderText = "View Order List" Then
                'MessageBox.Show("View Button: " & e.RowIndex & " is clicked")
                intOrderNumber = DataGridView1.Rows(e.RowIndex).Cells(0).Value
                Me.Hide()
                AsgFrmViewOrderList.Show()
            ElseIf DataGridView1.Columns(e.ColumnIndex).HeaderText = "Update Order Status" Then
                intOrderNumber = DataGridView1.Rows(e.RowIndex).Cells(0).Value
                AsgFrmOrderStatusUpdate.ShowDialog()
                RemoveButtonColumns()
                'MessageBox.Show("Update Button of Order [" & intOrderNumber & "] is clicked")
            ElseIf DataGridView1.Columns(e.ColumnIndex).HeaderText = "Make Order Payment" Then
                If DataGridView1.Rows(e.RowIndex).Cells(2).Value <> "Ready" And DataGridView1.Rows(e.RowIndex).Cells(3).Value = "Pay by Cash" Then
                    MessageBox.Show("Cannot make payment for this order." & vbNewLine & "Payment only can be made for the" & vbNewLine & "Order with Status of Ready.", "Cannot Make Payment", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                ElseIf DataGridView1.Rows(e.RowIndex).Cells(3).Value = "Pay by Credit Card" Then
                    MessageBox.Show("Payment of this order has been made by credit card.", "Order Paid", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Else
                    intOrderNumber = DataGridView1.Rows(e.RowIndex).Cells(0).Value
                    'Me.Hide()
                    AsgFrmStaffOrderPayment.ShowDialog()
                    RemoveButtonColumns()
                End If
                'intOrderNumber = DataGridView1.Rows(e.RowIndex).Cells(0).Value
                'MessageBox.Show("Payment of Order [" & intOrderNumber & "] can be made now", "Can Make Payment", MessageBoxButtons.OK, MessageBoxIcon.Information)
                'MessageBox.Show("Payment Button of Order [" & intOrderNumber & "] is clicked")
            End If
        Catch ex As Exception
            'intRowIndex = e.RowIndex
        End Try

    End Sub

    Private Sub mnuUpcomingOrder_Click(sender As Object, e As EventArgs) Handles mnuUpcomingOrder.Click
        Me.Close()
        'AsgFrmStaffOrder.Show()
    End Sub

    Private Sub AsgFrmStaffCurrentOrder_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        AsgFrmStaffUpcomingOrder.Show()
    End Sub

    Private Sub mnuCompleteOrder_Click(sender As Object, e As EventArgs) Handles mnuCompleteOrder.Click
        Me.Hide()
        'AsgFrmStaffCompleteOrder.IsFromCurrent()
        AsgFrmStaffCompleteOrder.Show()
        'Me.Close()
    End Sub

    Private Sub txtSearch_TextChanged(sender As Object, e As EventArgs) Handles txtSearch.TextChanged
        If txtSearch.Text.Trim() = "" Then
            DataGridView1.Columns.Clear()
            DataGridView1.DataSource = ""
            AsgFrmStaffCurrentOrder_Load(Nothing, Nothing)
        Else
            DataGridView1.Columns.Clear()
            DataGridView1.DataSource = ""
            Dim strSql As String
            Dim intReceiveCount As Integer = 0
            Dim intPrepareCount As Integer = 0
            Dim intReadyCount As Integer = 0
            Dim intCashCount As Integer = 0
            Dim intCreditCount As Integer = 0
            'Dim statusCboCol As DataGridViewComboBoxColumn = New DataGridViewComboBoxColumn
            If StartConnection() = True Then
                strSql = "Select O.Order_No, O.Date, O.Status, O.Payment_Method From Food_Order O, Customer C WHERE O.Cust_No = C.Cust_No AND O.Status <> 'Waiting for Accept' AND O.Status <> 'Completed' AND O.Order_No LIKE '%" & txtSearch.Text.Trim() & "%' OR O.Date LIKE '%" & txtSearch.Text.Trim() & "%' OR O.Status LIKE '%" & txtSearch.Text.Trim() & "%' OR O.Payment_Method LIKE '%" & txtSearch.Text.Trim() & "%'"
                da = New SqlDataAdapter(strSql, connection)
                ds.Clear()
                Try
                    da.Fill(ds, "Food_Order")
                Catch ex As Exception
                    'do something
                End Try
                'ReDim orders(ds.Tables("Food_Order").Rows.Count - 1)
                'ReDim menus(ds.Tables("Food_Order").Rows.Count - 1)
                If ds.Tables("Food_Order").Rows.Count > 0 Then
                    DataGridView1.DataSource = ds.Tables("Food_Order")
                    DataGridView1.Columns.Insert(4, viewButtonCol)
                    DataGridView1.Columns.Insert(5, updateButtonCol)
                    DataGridView1.Columns.Insert(6, paymentButtonCol)
                    'DataGridView1.ColumnHeadersDefaultCellStyle.BackColor = Color.Black
                    'DataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White
                    'DataGridView1.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.Black
                    'DataGridView1.ColumnHeadersDefaultCellStyle.SelectionForeColor = Color.White
                    DataGridView1.Columns(0).HeaderText = "Order ID"
                    DataGridView1.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    DataGridView1.Columns(0).DefaultCellStyle.SelectionBackColor = Color.White
                    DataGridView1.Columns(0).DefaultCellStyle.SelectionForeColor = Color.Black
                    DataGridView1.Columns(1).HeaderText = "Order Date and Time"
                    DataGridView1.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    DataGridView1.Columns(1).DefaultCellStyle.SelectionBackColor = Color.White
                    DataGridView1.Columns(1).DefaultCellStyle.SelectionForeColor = Color.Black
                    'DataGridView1.Columns(2).HeaderText = "Total Items"
                    'DataGridView1.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    'DataGridView1.Columns(2).DefaultCellStyle.SelectionBackColor = Color.White
                    'DataGridView1.Columns(2).DefaultCellStyle.SelectionForeColor = Color.Black
                    'DataGridView1.Columns(3).HeaderText = "Placed By"
                    'DataGridView1.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    'DataGridView1.Columns(3).DefaultCellStyle.SelectionBackColor = Color.White
                    'DataGridView1.Columns(3).DefaultCellStyle.SelectionForeColor = Color.Black
                    DataGridView1.Columns(2).HeaderText = "Status"
                    DataGridView1.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    DataGridView1.Columns(2).DefaultCellStyle.SelectionBackColor = Color.White
                    DataGridView1.Columns(2).DefaultCellStyle.SelectionForeColor = Color.Black
                    DataGridView1.Columns(3).HeaderText = "Payment Method"
                    DataGridView1.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    DataGridView1.Columns(3).DefaultCellStyle.SelectionBackColor = Color.White
                    DataGridView1.Columns(3).DefaultCellStyle.SelectionForeColor = Color.Black
                    viewButtonCol.HeaderText = "View Order List"
                    viewButtonCol.Text = "View Order Items"
                    updateButtonCol.HeaderText = "Update Order Status"
                    updateButtonCol.Text = "Update"
                    paymentButtonCol.HeaderText = "Make Order Payment"
                    paymentButtonCol.Text = "Make Payment"
                    'For intIndex = 0 To ds.Tables("Food_Order").Rows.Count - 1 Step 1
                    '    If ds.Tables("Food_Order").Rows(intIndex).Item("Payment_Method") = "Pay by Credit Card" Then
                    '        paymentButtonCol.Text = "Paid"
                    '        paymentButtonCol.ReadOnly = True
                    '    Else
                    '        paymentButtonCol.Text = "Make Payment"
                    '        paymentButtonCol.ReadOnly = False
                    '    End If
                    'Next intIndex
                    'If 

                    'statusCboCol.HeaderText = "Update Order Status"
                    'For intCount = 0 To ds.Tables("Food_Order").Rows.Count - 1 Step 1
                    '    If ds.Tables("Food_Order").Rows(intCount).Item("Status") = "Received" Then
                    '        statusCboCol.Items.Add("Received")
                    '        statusCboCol.Items.Add("Preparing")
                    '        'AddHandler 
                    '    ElseIf ds.Tables("Food_Order").Rows(intCount).Item("Status") = "Preparing" Then
                    '        statusCboCol.Items.Add("Received")
                    '        statusCboCol.Items.Add("Preparing")
                    '        statusCboCol.Items.Add("Ready")
                    '    End If
                    'Next intCount
                    'DataGridView1.Columns.Add(statusCboCol)

                    'Console.WriteLine(statusCboCol.Items.Count & vbTab & statusCboCol.Items(0) & vbTab & statusCboCol.Items(1))
                    'buttonCol.BackColor = Color.MediumTurquoise
                    viewButtonCol.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 10, FontStyle.Bold)
                    viewButtonCol.UseColumnTextForButtonValue = True
                    viewButtonCol.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    viewButtonCol.FlatStyle = FlatStyle.Popup
                    viewButtonCol.DefaultCellStyle.BackColor = Color.MediumTurquoise
                    viewButtonCol.DefaultCellStyle.SelectionBackColor = Color.MediumTurquoise
                    viewButtonCol.DefaultCellStyle.SelectionForeColor = Color.Black
                    updateButtonCol.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 10, FontStyle.Bold)
                    updateButtonCol.UseColumnTextForButtonValue = True
                    updateButtonCol.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    updateButtonCol.FlatStyle = FlatStyle.Popup
                    updateButtonCol.DefaultCellStyle.BackColor = Color.MediumTurquoise
                    updateButtonCol.DefaultCellStyle.SelectionBackColor = Color.MediumTurquoise
                    updateButtonCol.DefaultCellStyle.SelectionForeColor = Color.Black
                    paymentButtonCol.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 10, FontStyle.Bold)
                    paymentButtonCol.UseColumnTextForButtonValue = True
                    paymentButtonCol.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    paymentButtonCol.FlatStyle = FlatStyle.Popup
                    paymentButtonCol.DefaultCellStyle.BackColor = Color.MediumTurquoise
                    paymentButtonCol.DefaultCellStyle.SelectionBackColor = Color.MediumTurquoise
                    paymentButtonCol.DefaultCellStyle.SelectionForeColor = Color.Black
                    lblOrderToday.Text = ds.Tables("Food_Order").Rows.Count.ToString()
                    For intIndex = 0 To ds.Tables("Food_Order").Rows.Count - 1 Step 1
                        If ds.Tables("Food_Order").Rows(intIndex).Item("Status") = "Received" Then
                            intReceiveCount += 1
                        ElseIf ds.Tables("Food_Order").Rows(intIndex).Item("Status") = "Preparing" Then
                            intPrepareCount += 1
                        Else
                            intReadyCount += 1
                        End If

                        If ds.Tables("Food_Order").Rows(intIndex).Item("Payment_Method") = "Pay by Cash" Then
                            intCashCount += 1
                        Else
                            intCreditCount += 1
                        End If
                    Next intIndex
                    lblReceived.Text = intReceiveCount.ToString()
                    lblPreparing.Text = intPrepareCount.ToString()
                    lblReady.Text = intReadyCount.ToString()
                    lblCash.Text = intCashCount.ToString()
                    lblCredit.Text = intCreditCount.ToString()
                End If
                EndConnection()
            End If
        End If
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Close()
        AsgFrmStaffUpcomingOrder.Close()
    End Sub

    'Private Sub cboStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboStatus.SelectedIndexChanged

    'End Sub

    'Private Sub DataGridView1_EditingControlShowing(sender As Object, e As DataGridViewEditingControlShowingEventArgs) Handles DataGridView1.EditingControlShowing
    '    Try
    '        If DataGridView1.CurrentCell.ColumnIndex = 7 Then
    '            Dim combo As ComboBox = CType(e.Control, ComboBox)
    '            If combo IsNot Nothing Then
    '                RemoveHandler combo.Selec
    '            End If
    '        End If
    '    Catch ex As Exception

    '    End Try
    'End Sub
End Class