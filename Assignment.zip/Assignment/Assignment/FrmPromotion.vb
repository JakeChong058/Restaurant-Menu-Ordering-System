﻿Imports System.Data.Common
Imports System.Data.SqlClient
Public Class FrmPromotion
    Private da As SqlDataAdapter
    Private ds As DataSet = New DataSet()


    Friend strSQLAll As String = "Select Menu_Id, Description, Discounted_Price, PromotionRate, Order_Count From Menu Where (IsPromotion = 'T' AND PromotionRate = 0.10 OR PromotionRate = 0.20)"
    Friend strSQL10 As String = "Select Menu_Id, Description, Discounted_Price, PromotionRate, Order_Count From Menu Where (IsPromotion = 'T' AND PromotionRate = 0.10)"
    Friend strSQL20 As String = "Select Menu_Id, Description, Discounted_Price, PromotionRate, Order_Count From Menu Where (IsPromotion = 'T' AND PromotionRate = 0.20)"
    Friend strSQLtxtChanged As String
    Friend blnFilterPromotionAll As Boolean = False
    Friend blnFilterPromotion10 As Boolean = False
    Friend blnFilterPromotion20 As Boolean = False

    Friend strEditMenuId As String
    Friend blnRadCheckNone = False
    Friend blnRadCheck10 = False
    Friend blnRadCheck20 = False

    Private Sub btnBackToMenu_Click(sender As Object, e As EventArgs)
        Me.Close()
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Me.Hide()
        frmAddPromotion.Show()
    End Sub

    Private Sub btnReport_Click(sender As Object, e As EventArgs) Handles btnReport.Click
        Dim strPosition As String = ""
        Dim strQuery As String
        Dim aDs As DataSet = New DataSet()
        If StartConnection() = True Then
            strQuery = "Select Position From Staff Where Staff_Id = " & frmStaffLoginPage.intCurrentStaffID
            da = New SqlDataAdapter(strQuery, connection)
            aDs.Clear()
            Try
                da.Fill(aDs, "Staff")
            Catch ex As Exception

            End Try
            If aDs.Tables("Staff").Rows.Count > 0 Then
                strPosition = aDs.Tables("Staff").Rows(0).Item("Position")
            End If
            EndConnection()
        End If

        If strPosition = "Staff" Then
            MessageBox.Show("You are not authorised to generate promotion report", "Cannot Generate Report", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            frmGeneratePromotionReport.ShowDialog()
        End If
        'Me.Hide()
    End Sub
    Friend Sub PromotionData(strSQL As String)
        Dim editButtonCol As New DataGridViewButtonColumn
        If StartConnection() = True Then
            da = New SqlDataAdapter(strSQL, connection)
            ds.Clear()
            Try
                da.Fill(ds, "Menu")
            Catch ex As Exception
            End Try
            If ds.Tables("Menu").Rows.Count > 0 Then

                DataGridView1.DataSource = ds.Tables("Menu")
                DataGridView1.Columns.Add(editButtonCol)
                DataGridView1.Columns(0).HeaderText = "Menu ID"
                DataGridView1.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(0).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(0).DefaultCellStyle.SelectionForeColor = Color.Black

                DataGridView1.Columns(1).HeaderText = "Description"
                DataGridView1.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(1).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(1).DefaultCellStyle.SelectionForeColor = Color.Black

                DataGridView1.Columns(2).HeaderText = "Discounted Price"
                DataGridView1.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(2).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(2).DefaultCellStyle.SelectionForeColor = Color.Black

                DataGridView1.Columns(3).HeaderText = "Promotion Rate"
                DataGridView1.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(3).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(3).DefaultCellStyle.SelectionForeColor = Color.Black

                DataGridView1.Columns(4).HeaderText = "Order Count"
                DataGridView1.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(4).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(4).DefaultCellStyle.SelectionForeColor = Color.Black

                editButtonCol.HeaderText = "Edit Item"
                editButtonCol.Text = "Edit"
                editButtonCol.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 10, FontStyle.Bold)
                editButtonCol.UseColumnTextForButtonValue = True
                editButtonCol.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                editButtonCol.FlatStyle = FlatStyle.Popup
                editButtonCol.DefaultCellStyle.BackColor = Color.MediumTurquoise
                editButtonCol.DefaultCellStyle.SelectionBackColor = Color.MediumTurquoise
                editButtonCol.DefaultCellStyle.SelectionForeColor = Color.Black
            End If
            EndConnection()
        End If
    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Try
            If DataGridView1.Columns(e.ColumnIndex).HeaderText = "Edit Item" Then
                strEditMenuId = DataGridView1.Rows(e.RowIndex).Cells(0).Value
                If DataGridView1.Rows(e.RowIndex).Cells(3).Value = 0.00 Then
                    blnRadCheckNone = True
                    blnRadCheck10 = False
                    blnRadCheck20 = False
                ElseIf DataGridView1.Rows(e.RowIndex).Cells(3).Value = 0.1 Then
                    blnRadCheckNone = False
                    blnRadCheck10 = True
                    blnRadCheck20 = False
                ElseIf DataGridView1.Rows(e.RowIndex).Cells(3).Value = 0.2 Then
                    blnRadCheckNone = False
                    blnRadCheck10 = False
                    blnRadCheck20 = True
                End If
                ' Me.Hide()
                frmEditPromotion.ShowDialog()
            End If
        Catch ex As Exception
        End Try
    End Sub

    Friend Sub mnuAll_Click(sender As Object, e As EventArgs) Handles mnuAll.Click, MyBase.Load, Me.Shown
        DataGridView1.Columns.Clear()
        DataGridView1.DataSource = ""
        PromotionData(strSQLAll)
        blnFilterPromotionAll = True
        blnFilterPromotion10 = False
        blnFilterPromotion20 = False
    End Sub

    Private Sub mnu10_Click(sender As Object, e As EventArgs) Handles mnu10.Click
        DataGridView1.Columns.Clear()
        DataGridView1.DataSource = ""
        PromotionData(strSQL10)
        blnFilterPromotionAll = False
        blnFilterPromotion10 = True
        blnFilterPromotion20 = False
    End Sub

    Private Sub mnu20_Click(sender As Object, e As EventArgs) Handles mnu20.Click
        DataGridView1.Columns.Clear()
        DataGridView1.DataSource = ""
        PromotionData(strSQL20)
        blnFilterPromotionAll = False
        blnFilterPromotion10 = False
        blnFilterPromotion20 = True
    End Sub

    Private Sub txtSearch_TextChanged(sender As Object, e As EventArgs) Handles txtSearch.TextChanged
        If txtSearch.Text = "" Then
            DataGridView1.Columns.Clear()
            DataGridView1.DataSource = ""
            mnuAll_Click(Nothing, Nothing)
        Else
            DataGridView1.Columns.Clear()
            DataGridView1.DataSource = ""
            If blnFilterPromotionAll = True And blnFilterPromotion10 = False And blnFilterPromotion20 = False Then
                strSQLtxtChanged = "Select Menu_Id, Description, Discounted_Price, PromotionRate, Order_Count From Menu Where (PromotionRate = 0.10 or PromotionRate = 0.20) and (Menu_Id LIKE '%" & txtSearch.Text.Trim() & "%' OR Description LIKE '%" & txtSearch.Text.Trim() & "%' OR Price LIKE '%" & txtSearch.Text.Trim() & "%' OR PromotionRate LIKE '%" & txtSearch.Text.Trim() & "%' OR Order_Count LIKE '%" & txtSearch.Text.Trim() & "%')"
            ElseIf blnFilterPromotionAll = False And blnFilterPromotion10 = True And blnFilterPromotion20 = False Then
                strSQLtxtChanged = "Select Menu_Id, Description, Discounted_Price, PromotionRate, Order_Count From Menu Where (PromotionRate = 0.10) and (Menu_Id LIKE '%" & txtSearch.Text.Trim() & "%' OR Description LIKE '%" & txtSearch.Text.Trim() & "%' OR Price LIKE '%" & txtSearch.Text.Trim() & "%' OR PromotionRate LIKE '%" & txtSearch.Text.Trim() & "%' OR Order_Count LIKE '%" & txtSearch.Text.Trim() & "%')"
            ElseIf blnFilterPromotionAll = False And blnFilterPromotion10 = False And blnFilterPromotion20 = True Then
                strSQLtxtChanged = "Select Menu_Id, Description, Discounted_Price, PromotionRate, Order_Count From Menu Where (PromotionRate = 0.20) and (Menu_Id LIKE '%" & txtSearch.Text.Trim() & "%' OR Description LIKE '%" & txtSearch.Text.Trim() & "%' OR Price LIKE '%" & txtSearch.Text.Trim() & "%' OR PromotionRate LIKE '%" & txtSearch.Text.Trim() & "%' OR Order_Count LIKE '%" & txtSearch.Text.Trim() & "%')"
            End If
            PromotionData(strSQLtxtChanged)
        End If
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Close()
        frmStaffMainPage.Show()
    End Sub

    Private Sub FrmPromotion_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        frmStaffMainPage.Show()
    End Sub
End Class
