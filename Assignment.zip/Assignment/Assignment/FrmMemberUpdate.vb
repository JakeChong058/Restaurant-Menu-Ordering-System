﻿Imports System.Data.SqlClient

Public Class FrmMemberUpdate
    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim connectionString As String = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Daniel Yong\Documents\A Y2 Sem 1\Visual Programming\Practical\Assignment\Assignment\Restaurent.mdf;Integrated Security=True"
        Dim memberIc As String = mskIc.Text
        Dim memberName As String = txtName.Text
        Dim phoneNumber As String = mskPhoneNumber.Text
        Dim email As String = txtEmail.Text

        Dim sql As String = "UPDATE Member SET Member_Name = @MemberName, Member_Phone_Number = @PhoneNumber, Member_Email = @Email WHERE Member_IC = @ic"

        Using connection As New SqlConnection(connectionString)
            Using command As New SqlCommand(sql, connection)
                command.Parameters.AddWithValue("@ic", memberIc)
                command.Parameters.AddWithValue("@MemberName", memberName)
                command.Parameters.AddWithValue("@PhoneNumber", phoneNumber)
                command.Parameters.AddWithValue("@Email", email)

                Try
                    connection.Open()
                    Dim rowsAffected As Integer = command.ExecuteNonQuery()
                    MessageBox.Show("Data Updated Successfully!")
                Catch ex As Exception
                    MessageBox.Show("Error updating data")
                End Try
            End Using
        End Using

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        mskIc.Clear()
        txtName.Clear()
        txtEmail.Clear()
        mskPhoneNumber.Clear()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
        FrmMember.Show()

    End Sub
End Class