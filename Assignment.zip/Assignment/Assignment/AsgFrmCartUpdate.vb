﻿Public Class AsgFrmCartUpdate
    Private strQuantity As String
    Friend intQuantity As Integer
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub AsgFrmCartUpdate_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Dim intQuantity As Integer
        'intQuantity = GetQuantity()
        'nudItemQuantity.Value = intQuantity
    End Sub

    Friend Sub SetQuantity(strQty As String)
        strQuantity = strQty
    End Sub

    Private Function GetQuantity() As Integer
        Return CInt(strQuantity)
    End Function

    'Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
    '    AsgFrmCustCart.strParts(6) = CStr(nudItemQuantity.Value)
    '    MessageBox.Show("Item quantity has been updated", "UPDATE SUCCESSFULLY", MessageBoxButtons.OK, MessageBoxIcon.Information)
    'End Sub
End Class