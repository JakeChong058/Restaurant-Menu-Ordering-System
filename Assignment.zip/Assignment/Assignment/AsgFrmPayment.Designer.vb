﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AsgFrmPayment
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.btnBackCart = New System.Windows.Forms.Button()
        Me.lblCart = New System.Windows.Forms.Label()
        Me.grpPayment = New System.Windows.Forms.GroupBox()
        Me.lblService = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Item = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lblGrand = New System.Windows.Forms.Label()
        Me.lblSST = New System.Windows.Forms.Label()
        Me.lblSubtotal = New System.Windows.Forms.Label()
        Me.lblQty = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblTax = New System.Windows.Forms.Label()
        Me.lblSub = New System.Windows.Forms.Label()
        Me.lblQuantity = New System.Windows.Forms.Label()
        Me.grpPayMenthods = New System.Windows.Forms.GroupBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.dtpExpDate = New System.Windows.Forms.DateTimePicker()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.mskCVV = New System.Windows.Forms.MaskedTextBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.mskCreditCardNo = New System.Windows.Forms.MaskedTextBox()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.radCreditCard = New System.Windows.Forms.RadioButton()
        Me.radCash = New System.Windows.Forms.RadioButton()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.btnPlaceOrder = New System.Windows.Forms.Button()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.errValidation = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.grpPayment.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpPayMenthods.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.errValidation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnBackCart
        '
        Me.btnBackCart.BackColor = System.Drawing.Color.MediumTurquoise
        Me.btnBackCart.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBackCart.Location = New System.Drawing.Point(369, 800)
        Me.btnBackCart.Name = "btnBackCart"
        Me.btnBackCart.Size = New System.Drawing.Size(216, 69)
        Me.btnBackCart.TabIndex = 13
        Me.btnBackCart.Text = "Back &To Cart"
        Me.btnBackCart.UseVisualStyleBackColor = False
        '
        'lblCart
        '
        Me.lblCart.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCart.Location = New System.Drawing.Point(462, 217)
        Me.lblCart.Name = "lblCart"
        Me.lblCart.Size = New System.Drawing.Size(308, 60)
        Me.lblCart.TabIndex = 17
        Me.lblCart.Text = "ORDER CHECKOUT"
        Me.lblCart.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'grpPayment
        '
        Me.grpPayment.Controls.Add(Me.lblService)
        Me.grpPayment.Controls.Add(Me.Label19)
        Me.grpPayment.Controls.Add(Me.DataGridView1)
        Me.grpPayment.Controls.Add(Me.lblGrand)
        Me.grpPayment.Controls.Add(Me.lblSST)
        Me.grpPayment.Controls.Add(Me.lblSubtotal)
        Me.grpPayment.Controls.Add(Me.lblQty)
        Me.grpPayment.Controls.Add(Me.Label1)
        Me.grpPayment.Controls.Add(Me.lblTax)
        Me.grpPayment.Controls.Add(Me.lblSub)
        Me.grpPayment.Controls.Add(Me.lblQuantity)
        Me.grpPayment.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpPayment.Location = New System.Drawing.Point(634, 280)
        Me.grpPayment.Name = "grpPayment"
        Me.grpPayment.Size = New System.Drawing.Size(569, 502)
        Me.grpPayment.TabIndex = 18
        Me.grpPayment.TabStop = False
        Me.grpPayment.Text = "Your Order Payment"
        '
        'lblService
        '
        Me.lblService.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblService.Location = New System.Drawing.Point(207, 420)
        Me.lblService.Name = "lblService"
        Me.lblService.Size = New System.Drawing.Size(345, 26)
        Me.lblService.TabIndex = 11
        Me.lblService.Text = "d"
        '
        'Label19
        '
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(7, 419)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(206, 27)
        Me.Label19.TabIndex = 10
        Me.Label19.Text = "Service Charge: "
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.DataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.White
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.White
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Item})
        Me.DataGridView1.Location = New System.Drawing.Point(14, 50)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.RowHeadersWidth = 62
        Me.DataGridView1.RowTemplate.Height = 28
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(540, 240)
        Me.DataGridView1.TabIndex = 9
        '
        'Item
        '
        Me.Item.HeaderText = "Item"
        Me.Item.MinimumWidth = 8
        Me.Item.Name = "Item"
        Me.Item.ReadOnly = True
        Me.Item.Width = 108
        '
        'lblGrand
        '
        Me.lblGrand.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGrand.Location = New System.Drawing.Point(207, 460)
        Me.lblGrand.Name = "lblGrand"
        Me.lblGrand.Size = New System.Drawing.Size(340, 26)
        Me.lblGrand.TabIndex = 8
        Me.lblGrand.Text = "e"
        '
        'lblSST
        '
        Me.lblSST.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSST.Location = New System.Drawing.Point(207, 385)
        Me.lblSST.Name = "lblSST"
        Me.lblSST.Size = New System.Drawing.Size(345, 26)
        Me.lblSST.TabIndex = 7
        Me.lblSST.Text = "c"
        '
        'lblSubtotal
        '
        Me.lblSubtotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubtotal.Location = New System.Drawing.Point(207, 346)
        Me.lblSubtotal.Name = "lblSubtotal"
        Me.lblSubtotal.Size = New System.Drawing.Size(345, 26)
        Me.lblSubtotal.TabIndex = 6
        Me.lblSubtotal.Text = "b"
        '
        'lblQty
        '
        Me.lblQty.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblQty.Location = New System.Drawing.Point(207, 306)
        Me.lblQty.Name = "lblQty"
        Me.lblQty.Size = New System.Drawing.Size(350, 26)
        Me.lblQty.TabIndex = 5
        Me.lblQty.Text = "a"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(53, 460)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(160, 31)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Grand Total: "
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblTax
        '
        Me.lblTax.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTax.Location = New System.Drawing.Point(58, 386)
        Me.lblTax.Name = "lblTax"
        Me.lblTax.Size = New System.Drawing.Size(155, 27)
        Me.lblTax.TabIndex = 3
        Me.lblTax.Text = "SST: "
        Me.lblTax.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblSub
        '
        Me.lblSub.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSub.Location = New System.Drawing.Point(53, 346)
        Me.lblSub.Name = "lblSub"
        Me.lblSub.Size = New System.Drawing.Size(160, 40)
        Me.lblSub.TabIndex = 2
        Me.lblSub.Text = "Subtotal: "
        Me.lblSub.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblQuantity
        '
        Me.lblQuantity.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblQuantity.Location = New System.Drawing.Point(17, 305)
        Me.lblQuantity.Name = "lblQuantity"
        Me.lblQuantity.Size = New System.Drawing.Size(195, 43)
        Me.lblQuantity.TabIndex = 1
        Me.lblQuantity.Text = "Total Quantity: "
        Me.lblQuantity.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'grpPayMenthods
        '
        Me.grpPayMenthods.Controls.Add(Me.Label18)
        Me.grpPayMenthods.Controls.Add(Me.Label17)
        Me.grpPayMenthods.Controls.Add(Me.Label16)
        Me.grpPayMenthods.Controls.Add(Me.Label15)
        Me.grpPayMenthods.Controls.Add(Me.Label14)
        Me.grpPayMenthods.Controls.Add(Me.dtpExpDate)
        Me.grpPayMenthods.Controls.Add(Me.Label13)
        Me.grpPayMenthods.Controls.Add(Me.mskCVV)
        Me.grpPayMenthods.Controls.Add(Me.PictureBox2)
        Me.grpPayMenthods.Controls.Add(Me.Label8)
        Me.grpPayMenthods.Controls.Add(Me.Label7)
        Me.grpPayMenthods.Controls.Add(Me.mskCreditCardNo)
        Me.grpPayMenthods.Controls.Add(Me.txtName)
        Me.grpPayMenthods.Controls.Add(Me.Label6)
        Me.grpPayMenthods.Controls.Add(Me.Label5)
        Me.grpPayMenthods.Controls.Add(Me.Label12)
        Me.grpPayMenthods.Controls.Add(Me.Label11)
        Me.grpPayMenthods.Controls.Add(Me.radCreditCard)
        Me.grpPayMenthods.Controls.Add(Me.radCash)
        Me.grpPayMenthods.Controls.Add(Me.Label10)
        Me.grpPayMenthods.Controls.Add(Me.Label2)
        Me.grpPayMenthods.Controls.Add(Me.Label3)
        Me.grpPayMenthods.Controls.Add(Me.Label4)
        Me.grpPayMenthods.Controls.Add(Me.Label9)
        Me.grpPayMenthods.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpPayMenthods.Location = New System.Drawing.Point(22, 280)
        Me.grpPayMenthods.Name = "grpPayMenthods"
        Me.grpPayMenthods.Size = New System.Drawing.Size(606, 502)
        Me.grpPayMenthods.TabIndex = 19
        Me.grpPayMenthods.TabStop = False
        Me.grpPayMenthods.Text = "Payment Methods"
        '
        'Label18
        '
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.Red
        Me.Label18.Location = New System.Drawing.Point(210, 457)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(26, 21)
        Me.Label18.TabIndex = 30
        Me.Label18.Text = "*"
        '
        'Label17
        '
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.Red
        Me.Label17.Location = New System.Drawing.Point(211, 380)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(26, 21)
        Me.Label17.TabIndex = 29
        Me.Label17.Text = "*"
        '
        'Label16
        '
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.Red
        Me.Label16.Location = New System.Drawing.Point(211, 301)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(26, 21)
        Me.Label16.TabIndex = 28
        Me.Label16.Text = "*"
        '
        'Label15
        '
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.Red
        Me.Label15.Location = New System.Drawing.Point(212, 243)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(26, 21)
        Me.Label15.TabIndex = 27
        Me.Label15.Text = "*"
        '
        'Label14
        '
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(238, 424)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(301, 30)
        Me.Label14.TabIndex = 26
        Me.Label14.Text = "(3 digits)"
        '
        'dtpExpDate
        '
        Me.dtpExpDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpExpDate.Location = New System.Drawing.Point(242, 457)
        Me.dtpExpDate.Name = "dtpExpDate"
        Me.dtpExpDate.Size = New System.Drawing.Size(315, 26)
        Me.dtpExpDate.TabIndex = 25
        Me.dtpExpDate.Value = New Date(2023, 9, 16, 0, 0, 0, 0)
        '
        'Label13
        '
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(60, 457)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(155, 40)
        Me.Label13.TabIndex = 24
        Me.Label13.Text = "&Expired Date: "
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'mskCVV
        '
        Me.mskCVV.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mskCVV.Location = New System.Drawing.Point(243, 377)
        Me.mskCVV.Mask = "000"
        Me.mskCVV.Name = "mskCVV"
        Me.mskCVV.Size = New System.Drawing.Size(65, 30)
        Me.mskCVV.TabIndex = 23
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.Assignment.My.Resources.Resources.cards
        Me.PictureBox2.Location = New System.Drawing.Point(242, 194)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(296, 44)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 22
        Me.PictureBox2.TabStop = False
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(50, 201)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(192, 37)
        Me.Label8.TabIndex = 21
        Me.Label8.Text = "Accepted Cards: "
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(238, 346)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(319, 28)
        Me.Label7.TabIndex = 20
        Me.Label7.Text = "(eg. 1111-2222-3333-4444)"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'mskCreditCardNo
        '
        Me.mskCreditCardNo.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mskCreditCardNo.Location = New System.Drawing.Point(243, 299)
        Me.mskCreditCardNo.Mask = "0000-0000-0000-0000"
        Me.mskCreditCardNo.Name = "mskCreditCardNo"
        Me.mskCreditCardNo.Size = New System.Drawing.Size(314, 30)
        Me.mskCreditCardNo.TabIndex = 19
        '
        'txtName
        '
        Me.txtName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtName.Location = New System.Drawing.Point(242, 246)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(315, 30)
        Me.txtName.TabIndex = 18
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(50, 246)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(165, 44)
        Me.Label6.TabIndex = 17
        Me.Label6.Text = "&Name on Card:"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(96, 381)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(119, 54)
        Me.Label5.TabIndex = 14
        Me.Label5.Text = "C&VV: "
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label12
        '
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Red
        Me.Label12.Location = New System.Drawing.Point(310, 165)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(247, 33)
        Me.Label12.TabIndex = 13
        Me.Label12.Text = "*Required Information"
        '
        'Label11
        '
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(6, 162)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(298, 29)
        Me.Label11.TabIndex = 12
        Me.Label11.Text = "Credit Card Information: "
        '
        'radCreditCard
        '
        Me.radCreditCard.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radCreditCard.Location = New System.Drawing.Point(74, 117)
        Me.radCreditCard.Name = "radCreditCard"
        Me.radCreditCard.Size = New System.Drawing.Size(344, 42)
        Me.radCreditCard.TabIndex = 11
        Me.radCreditCard.TabStop = True
        Me.radCreditCard.Text = "Pay by credit card"
        Me.radCreditCard.UseVisualStyleBackColor = True
        '
        'radCash
        '
        Me.radCash.Checked = True
        Me.radCash.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radCash.Location = New System.Drawing.Point(74, 69)
        Me.radCash.Name = "radCash"
        Me.radCash.Size = New System.Drawing.Size(344, 42)
        Me.radCash.TabIndex = 10
        Me.radCash.TabStop = True
        Me.radCash.Text = "Pay later at counter by cash"
        Me.radCash.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(12, 39)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(526, 45)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "Please select either one of the payment methods below:"
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(176, 449)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(106, 26)
        Me.Label2.TabIndex = 8
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(176, 406)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(106, 26)
        Me.Label3.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(176, 365)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(106, 26)
        Me.Label4.TabIndex = 6
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(17, 305)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(198, 54)
        Me.Label9.TabIndex = 1
        Me.Label9.Text = "&Credit Card Number:"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'btnPlaceOrder
        '
        Me.btnPlaceOrder.BackColor = System.Drawing.Color.MediumTurquoise
        Me.btnPlaceOrder.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPlaceOrder.Location = New System.Drawing.Point(634, 800)
        Me.btnPlaceOrder.Name = "btnPlaceOrder"
        Me.btnPlaceOrder.Size = New System.Drawing.Size(213, 69)
        Me.btnPlaceOrder.TabIndex = 20
        Me.btnPlaceOrder.Text = "&Place Order"
        Me.btnPlaceOrder.UseVisualStyleBackColor = False
        '
        'Label20
        '
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label20.Location = New System.Drawing.Point(312, 876)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(752, 37)
        Me.Label20.TabIndex = 21
        Me.Label20.Text = "Note: Once an order is placed, no cancellation can be made."
        '
        'errValidation
        '
        Me.errValidation.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink
        Me.errValidation.ContainerControl = Me
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Assignment.My.Resources.Resources.Island_Cafe_Logo
        Me.PictureBox1.Location = New System.Drawing.Point(542, -3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(165, 180)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 10
        Me.PictureBox1.TabStop = False
        '
        'AsgFrmPayment
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1227, 922)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.btnPlaceOrder)
        Me.Controls.Add(Me.grpPayMenthods)
        Me.Controls.Add(Me.grpPayment)
        Me.Controls.Add(Me.lblCart)
        Me.Controls.Add(Me.btnBackCart)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "AsgFrmPayment"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Order Payment"
        Me.grpPayment.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpPayMenthods.ResumeLayout(False)
        Me.grpPayMenthods.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.errValidation, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnBackCart As Button
    Friend WithEvents lblCart As Label
    Friend WithEvents grpPayment As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents lblTax As Label
    Friend WithEvents lblSub As Label
    Friend WithEvents lblQuantity As Label
    Friend WithEvents lblGrand As Label
    Friend WithEvents lblSST As Label
    Friend WithEvents lblSubtotal As Label
    Friend WithEvents lblQty As Label
    Friend WithEvents grpPayMenthods As GroupBox
    Friend WithEvents radCreditCard As RadioButton
    Friend WithEvents radCash As RadioButton
    Friend WithEvents Label10 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents btnPlaceOrder As Button
    Friend WithEvents mskCreditCardNo As MaskedTextBox
    Friend WithEvents txtName As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Label8 As Label
    Friend WithEvents dtpExpDate As DateTimePicker
    Friend WithEvents Label13 As Label
    Friend WithEvents mskCVV As MaskedTextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Item As DataGridViewTextBoxColumn
    Friend WithEvents Label19 As Label
    Friend WithEvents lblService As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents errValidation As ErrorProvider
End Class
