﻿Imports System.Data.Common
Imports System.Data.SqlClient
Imports System.Reflection.Emit

Public Class frmAddPromotion
    Private intCount As Integer = 0
    Private da As SqlDataAdapter
    Private ds As DataSet = New DataSet()
    Private strComboItems() As String
    'Dim checkMenuId() As CustMenuItems
    Private Sub frmAddPromotion_Load(sender As Object, e As EventArgs) Handles MyBase.Load, Me.Shown
        radRate10.Checked = False
        radRate20.Checked = False
        cboItems.Items.Clear()
        Dim strSql As String
        If StartConnection() = True Then
            strSql = "Select * From Menu Where IsPromotion = 'F'"
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            Try
                da.Fill(ds, "Menu")
            Catch ex As Exception

            End Try
            'ReDim checkMenuId(ds.Tables("Menu").Rows.Count - 1)
            If ds.Tables("Menu").Rows.Count > 0 Then
                For intIndex = 0 To ds.Tables("Menu").Rows.Count - 1 Step 1
                    cboItems.Items.Add(ds.Tables("Menu").Rows(intIndex).Item("Menu_Id") & " " & ds.Tables("Menu").Rows(intIndex).Item("Description"))
                Next intIndex
            End If
            EndConnection()
        End If
    End Sub

    'Dim decDiscountPrice As Decimal = ds.Tables("Menu").Rows(intIndex).Item(2) * (1 - ds.Tables("Menu").Rows(intIndex).Item(4))

    '                checkMenuId(intIndex) = New CustMenuItems(ds.Tables("Menu").Rows(intIndex).Item(0),
    '                ds.Tables("Menu").Rows(intIndex).Item(1), decDiscountPrice,
    '                ds.Tables("Menu").Rows(intIndex).Item(3), ds.Tables("Menu").Rows(intIndex).Item(4),
    '                ds.Tables("Menu").Rows(intIndex).Item(5), ds.Tables("Menu").Rows(intIndex).Item(6), ds.Tables("Menu").Rows(intIndex).Item(7))

    'Friend Function checkExist(id As String) As Boolean
    '    For intIndex = 0 To checkMenuId.Length - 1 Step 1
    '        If checkMenuId(intIndex).GetStrMenuId = id Then
    '            'exist
    '            If checkMenuId(intIndex).GetDecPromotionRate = 0 Then
    '                Return True
    '            Else
    '                Return False
    '            End If
    '        End If
    '    Next
    '    Return False
    'End Function
    Friend Function checkRate(rad1 As Boolean, rad2 As Boolean) As Decimal
        If rad1 = True And rad2 = False Then
            Return 0.1
        ElseIf rad1 = False And rad2 = True Then
            Return 0.2
        Else
            Return 0
        End If
    End Function

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim decPrice As Decimal = 0D
        Dim decDiscountPrice As Decimal = 0D
        Dim strErrorMsg = ""
        If cboItems.SelectedIndex = -1 Then
            strErrorMsg += "Please select an item to be added to the promotion." & vbNewLine
        End If

        If radRate10.Checked = False And radRate20.Checked = False Then
            strErrorMsg += "Please choose a promote discount rate."
        End If

        If strErrorMsg <> "" Then
            MessageBox.Show(strErrorMsg, "Cannot Add Item to Promotion", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            Dim strSqlStatement As String
            Dim MSSqlCommand As New SqlCommand
            If StartConnection() = True Then
                strSqlStatement = "Select * From Menu Where Menu_Id = '" & strComboItems(0) & "'"
                da = New SqlDataAdapter(strSqlStatement, connection)
                ds.Clear()
                Try
                    da.Fill(ds, "Menu")
                Catch ex As Exception

                End Try
                'ReDim checkMenuId(ds.Tables("Menu").Rows.Count - 1)
                If ds.Tables("Menu").Rows.Count > 0 Then
                    decPrice = ds.Tables("Menu").Rows(0).Item("Price")
                    decDiscountPrice = decPrice - (decPrice * checkRate(radRate10.Checked, radRate20.Checked))
                End If
                EndConnection()
            End If
            If StartConnection() = True Then
                strSqlStatement = "UPDATE Menu SET IsPromotion = @IsPromotion, PromotionRate = @promotionrate, Discounted_Price = @discount where Menu_Id=@menuid"
                MSSqlCommand = New SqlCommand(strSqlStatement, connection)
                MSSqlCommand.Parameters.AddWithValue("@IsPromotion", "T")
                MSSqlCommand.Parameters.AddWithValue("@menuid", strComboItems(0))
                MSSqlCommand.Parameters.AddWithValue("@promotionrate", checkRate(radRate10.Checked, radRate20.Checked))
                MSSqlCommand.Parameters.AddWithValue("@discount", decDiscountPrice)
                'Console.WriteLine(strComboItems(0))
                MSSqlCommand.ExecuteNonQuery()
                MessageBox.Show("Item Promote Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                'Me.Close()
                EndConnection()
                'cboItems.Items.Clear()
                frmAddPromotion_Load(Nothing, Nothing)
            Else
                MessageBox.Show("Error Connecting Server", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

            End If
        End If
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
        'FrmPromotion.Show()
    End Sub

    Private Sub cboItems_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboItems.SelectedIndexChanged
        Try
            strComboItems = CStr(cboItems.SelectedItem).Split(CChar(" "))
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Clear()
        cboItems.SelectedIndex = -1
        radRate10.Checked = False
        radRate20.Checked = False
    End Sub

    Private Sub frmAddPromotion_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        FrmPromotion.mnuAll_Click(Nothing, Nothing)
        FrmPromotion.Show()
    End Sub
End Class