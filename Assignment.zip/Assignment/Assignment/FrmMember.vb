﻿Imports System.Data.SqlClient

Public Class FrmMember

    Private da As SqlDataAdapter
    Private ds As DataSet = New DataSet()
    Friend intCustNo As Integer = 0
    Private dgvViewButtonCol As New DataGridViewButtonColumn
    Private dgvEditButtonCol As New DataGridViewButtonColumn
    Private dgvRegisterButtonCol As New DataGridViewButtonColumn
    Private Sub btnMembershipReg_Click(sender As Object, e As EventArgs)
        Me.Hide()
        FrmMemberRegistration.Show()
    End Sub

    Private Sub btnMemberDetails_Click(sender As Object, e As EventArgs)
        Me.Hide()
        FrmMemberDetails.Show()
    End Sub

    Friend Sub FrmMember_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Dim dgvViewButtonCol As New DataGridViewButtonColumn
        'Dim dgvEditButtonCol As New DataGridViewButtonColumn
        'Dim dgvRegisterButtonCol As New DataGridViewButtonColumn
        Dim strSql As String
        DataGridView1.Columns.Clear()
        DataGridView1.DataSource = ""
        'Dim connectionString As String = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Daniel Yong\Documents\A Y2 Sem 1\Visual Programming\Practical\Assignment\Assignment\Restaurent.mdf;Integrated Security=True"
        'Dim connection As SqlConnection = New SqlConnection(connectionString)
        If StartConnection() = True Then
            strSql = "Select Cust_No, Phone_Num, Membership From Customer"
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            Try
                da.Fill(ds, "Customer")
            Catch ex As Exception

            End Try
            DataGridView1.DataSource = ds.Tables("Customer")
            If ds.Tables("Customer").Rows.Count > 0 Then
                DataGridView1.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(0).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(0).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(0).HeaderText = "Customer ID"

                DataGridView1.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(1).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(1).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(1).HeaderText = "Phone Number"

                DataGridView1.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(2).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(2).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(2).HeaderText = "Membership"

            End If
            EndConnection()
        End If
        DataGridView1.Columns.Add(dgvViewButtonCol)
        DataGridView1.Columns.Add(dgvRegisterButtonCol)
        DataGridView1.Columns.Add(dgvEditButtonCol)
        dgvEditButtonCol.FlatStyle = FlatStyle.Popup
        dgvRegisterButtonCol.FlatStyle = FlatStyle.Popup
        dgvViewButtonCol.FlatStyle = FlatStyle.Popup

        dgvViewButtonCol.DefaultCellStyle.BackColor = Color.MediumTurquoise
        dgvViewButtonCol.DefaultCellStyle.ForeColor = Color.Black
        dgvViewButtonCol.DefaultCellStyle.SelectionBackColor = Color.MediumTurquoise
        dgvViewButtonCol.DefaultCellStyle.SelectionForeColor = Color.Black
        dgvViewButtonCol.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 10, FontStyle.Bold)
        dgvViewButtonCol.HeaderText = "Membership Details"

        dgvEditButtonCol.DefaultCellStyle.BackColor = Color.MediumTurquoise
        dgvEditButtonCol.DefaultCellStyle.ForeColor = Color.Black
        dgvEditButtonCol.DefaultCellStyle.SelectionBackColor = Color.MediumTurquoise
        dgvEditButtonCol.DefaultCellStyle.SelectionForeColor = Color.Black
        dgvEditButtonCol.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 10, FontStyle.Bold)
        dgvEditButtonCol.HeaderText = "Edit Customer"

        dgvRegisterButtonCol.DefaultCellStyle.BackColor = Color.MediumTurquoise
        dgvRegisterButtonCol.DefaultCellStyle.ForeColor = Color.Black
        dgvRegisterButtonCol.DefaultCellStyle.SelectionBackColor = Color.MediumTurquoise
        dgvRegisterButtonCol.DefaultCellStyle.SelectionForeColor = Color.Black
        dgvRegisterButtonCol.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 10, FontStyle.Bold)
        dgvRegisterButtonCol.HeaderText = "Register Member"

        dgvEditButtonCol.Text = "Edit"
        dgvEditButtonCol.UseColumnTextForButtonValue = True

        dgvViewButtonCol.Text = "View"
        dgvViewButtonCol.UseColumnTextForButtonValue = True

        dgvRegisterButtonCol.Text = "Register"
        dgvRegisterButtonCol.UseColumnTextForButtonValue = True
    End Sub

    Private Sub FrmMember_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        frmStaffMainPage.Show()
    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Dim strPosition As String = ""
        Dim strQuery As String
        Dim oneDs As DataSet = New DataSet()
        If StartConnection() = True Then
            strQuery = "Select Position From Staff Where Staff_Id = " & frmStaffLoginPage.intCurrentStaffID
            da = New SqlDataAdapter(strQuery, connection)
            oneDs.Clear()
            Try
                da.Fill(oneDs, "Staff")
            Catch ex As Exception

            End Try
            If oneDs.Tables("Staff").Rows.Count > 0 Then
                strPosition = oneDs.Tables("Staff").Rows(0).Item("Position")
            End If
            EndConnection()
        End If
        Try
            If DataGridView1.Columns(e.ColumnIndex).HeaderText = "Membership Details" Then
                If DataGridView1.Rows(e.RowIndex).Cells(2).Value = "Not a member" Then
                    MessageBox.Show("This customer is not a member.", "Not A Member", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Else
                    intCustNo = DataGridView1.Rows(e.RowIndex).Cells(0).Value
                    Me.Hide()
                    FrmMemberDetails.Show()
                End If
            ElseIf DataGridView1.Columns(e.ColumnIndex).HeaderText = "Edit Customer" Then
                If strPosition <> "Administrator" Then
                    MessageBox.Show("Admin access only! You are not authorised to edit customer data.", "Forbidden Action", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Else
                    intCustNo = DataGridView1.Rows(e.RowIndex).Cells(0).Value
                    FrmEditCustomer.ShowDialog()
                End If
            ElseIf DataGridView1.Columns(e.ColumnIndex).HeaderText = "Register Member" Then
                If DataGridView1.Rows(e.RowIndex).Cells(2).Value = "Member" Then
                    MessageBox.Show("This customer is already a member.", "Registered", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Else
                    intCustNo = DataGridView1.Rows(e.RowIndex).Cells(0).Value
                    Me.Hide()
                    FrmMemberRegistration.Show()
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub btnMemberReport_Click(sender As Object, e As EventArgs) Handles btnMemberReport.Click
        Dim strPosition As String = ""
        Dim strQuery As String
        Dim secondDs As DataSet = New DataSet()
        If StartConnection() = True Then
            strQuery = "Select Position From Staff Where Staff_Id = " & frmStaffLoginPage.intCurrentStaffID
            da = New SqlDataAdapter(strQuery, connection)
            secondDs.Clear()
            Try
                da.Fill(secondDs, "Staff")
            Catch ex As Exception

            End Try
            If secondDs.Tables("Staff").Rows.Count > 0 Then
                strPosition = secondDs.Tables("Staff").Rows(0).Item("Position")
            End If
            EndConnection()
        End If

        If strPosition = "Staff" Then
            MessageBox.Show("You are not authorised to generate customer report", "Cannot Generate Report", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            FrmGenerateMemberReport.ShowDialog()
        End If
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Close()
    End Sub

    Private Sub mnuAllCustomers_Click(sender As Object, e As EventArgs) Handles mnuAllCustomers.Click
        FrmMember_Load(Nothing, Nothing)
    End Sub

    Private Sub mnuNonMembers_Click(sender As Object, e As EventArgs) Handles mnuNonMembers.Click
        Dim strSql As String
        DataGridView1.Columns.Clear()
        DataGridView1.DataSource = ""
        'Dim connectionString As String = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Daniel Yong\Documents\A Y2 Sem 1\Visual Programming\Practical\Assignment\Assignment\Restaurent.mdf;Integrated Security=True"
        'Dim connection As SqlConnection = New SqlConnection(connectionString)
        If StartConnection() = True Then
            strSql = "Select Cust_No, Phone_Num, Membership From Customer Where Membership = 'Not a member'"
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()

            Try
                da.Fill(ds, "Customer")
            Catch ex As Exception

            End Try
            DataGridView1.DataSource = ds.Tables("Customer")
            If ds.Tables("Customer").Rows.Count > 0 Then
                DataGridView1.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(0).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(0).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(0).HeaderText = "Customer ID"

                DataGridView1.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(1).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(1).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(1).HeaderText = "Phone Number"

                DataGridView1.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(2).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(2).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(2).HeaderText = "Membership"
            End If
            EndConnection()
        End If
        DataGridView1.Columns.Add(dgvViewButtonCol)
        DataGridView1.Columns.Add(dgvRegisterButtonCol)
        DataGridView1.Columns.Add(dgvEditButtonCol)
        dgvEditButtonCol.FlatStyle = FlatStyle.Popup
        dgvRegisterButtonCol.FlatStyle = FlatStyle.Popup
        dgvViewButtonCol.FlatStyle = FlatStyle.Popup

        dgvViewButtonCol.DefaultCellStyle.BackColor = Color.MediumTurquoise
        dgvViewButtonCol.DefaultCellStyle.ForeColor = Color.Black
        dgvViewButtonCol.DefaultCellStyle.SelectionBackColor = Color.MediumTurquoise
        dgvViewButtonCol.DefaultCellStyle.SelectionForeColor = Color.Black
        dgvViewButtonCol.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 10, FontStyle.Bold)
        dgvViewButtonCol.HeaderText = "Membership Details"

        dgvEditButtonCol.DefaultCellStyle.BackColor = Color.MediumTurquoise
        dgvEditButtonCol.DefaultCellStyle.ForeColor = Color.Black
        dgvEditButtonCol.DefaultCellStyle.SelectionBackColor = Color.MediumTurquoise
        dgvEditButtonCol.DefaultCellStyle.SelectionForeColor = Color.Black
        dgvEditButtonCol.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 10, FontStyle.Bold)
        dgvEditButtonCol.HeaderText = "Edit Customer"

        dgvRegisterButtonCol.DefaultCellStyle.BackColor = Color.MediumTurquoise
        dgvRegisterButtonCol.DefaultCellStyle.ForeColor = Color.Black
        dgvRegisterButtonCol.DefaultCellStyle.SelectionBackColor = Color.MediumTurquoise
        dgvRegisterButtonCol.DefaultCellStyle.SelectionForeColor = Color.Black
        dgvRegisterButtonCol.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 10, FontStyle.Bold)
        dgvRegisterButtonCol.HeaderText = "Register Member"

        dgvEditButtonCol.Text = "Edit"
        dgvEditButtonCol.UseColumnTextForButtonValue = True

        dgvViewButtonCol.Text = "View"
        dgvViewButtonCol.UseColumnTextForButtonValue = True

        dgvRegisterButtonCol.Text = "Register"
        dgvRegisterButtonCol.UseColumnTextForButtonValue = True
    End Sub

    Private Sub mnuMembers_Click(sender As Object, e As EventArgs) Handles mnuMembers.Click
        Dim dgvViewButtonCol As New DataGridViewButtonColumn
        Dim dgvEditButtonCol As New DataGridViewButtonColumn
        Dim strSql As String
        DataGridView1.Columns.Clear()
        DataGridView1.DataSource = ""
        'Dim connectionString As String = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Daniel Yong\Documents\A Y2 Sem 1\Visual Programming\Practical\Assignment\Assignment\Restaurent.mdf;Integrated Security=True"
        'Dim connection As SqlConnection = New SqlConnection(connectionString)
        If StartConnection() = True Then
            strSql = "Select Cust_No, Phone_Num, Membership From Customer Where Membership = 'Member'"
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()

            Try
                da.Fill(ds, "Customer")
            Catch ex As Exception

            End Try
            DataGridView1.DataSource = ds.Tables("Customer")
            If ds.Tables("Customer").Rows.Count > 0 Then
                DataGridView1.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(0).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(0).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(0).HeaderText = "Customer ID"

                DataGridView1.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(1).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(1).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(1).HeaderText = "Phone Number"

                DataGridView1.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(2).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(2).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(2).HeaderText = "Membership"
            End If
            EndConnection()
        End If
        DataGridView1.Columns.Add(dgvViewButtonCol)
        DataGridView1.Columns.Add(dgvRegisterButtonCol)
        DataGridView1.Columns.Add(dgvEditButtonCol)
        dgvEditButtonCol.FlatStyle = FlatStyle.Popup
        dgvRegisterButtonCol.FlatStyle = FlatStyle.Popup
        dgvViewButtonCol.FlatStyle = FlatStyle.Popup

        dgvViewButtonCol.DefaultCellStyle.BackColor = Color.MediumTurquoise
        dgvViewButtonCol.DefaultCellStyle.ForeColor = Color.Black
        dgvViewButtonCol.DefaultCellStyle.SelectionBackColor = Color.MediumTurquoise
        dgvViewButtonCol.DefaultCellStyle.SelectionForeColor = Color.Black
        dgvViewButtonCol.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 10, FontStyle.Bold)
        dgvViewButtonCol.HeaderText = "Membership Details"

        dgvEditButtonCol.DefaultCellStyle.BackColor = Color.MediumTurquoise
        dgvEditButtonCol.DefaultCellStyle.ForeColor = Color.Black
        dgvEditButtonCol.DefaultCellStyle.SelectionBackColor = Color.MediumTurquoise
        dgvEditButtonCol.DefaultCellStyle.SelectionForeColor = Color.Black
        dgvEditButtonCol.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 10, FontStyle.Bold)
        dgvEditButtonCol.HeaderText = "Edit Customer"

        dgvRegisterButtonCol.DefaultCellStyle.BackColor = Color.MediumTurquoise
        dgvRegisterButtonCol.DefaultCellStyle.ForeColor = Color.Black
        dgvRegisterButtonCol.DefaultCellStyle.SelectionBackColor = Color.MediumTurquoise
        dgvRegisterButtonCol.DefaultCellStyle.SelectionForeColor = Color.Black
        dgvRegisterButtonCol.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 10, FontStyle.Bold)
        dgvRegisterButtonCol.HeaderText = "Register Member"

        dgvEditButtonCol.Text = "Edit"
        dgvEditButtonCol.UseColumnTextForButtonValue = True

        dgvViewButtonCol.Text = "View"
        dgvViewButtonCol.UseColumnTextForButtonValue = True

        dgvRegisterButtonCol.Text = "Register"
        dgvRegisterButtonCol.UseColumnTextForButtonValue = True
    End Sub

    Private Sub txtSearch_TextChanged(sender As Object, e As EventArgs) Handles txtSearch.TextChanged
        Dim ds As DataSet = New DataSet()
        If txtSearch.Text.Trim() = "" Then
            FrmMember_Load(Nothing, Nothing)
        Else
            Dim strSql As String
            DataGridView1.Columns.Clear()
            DataGridView1.DataSource = ""
            If StartConnection() = True Then
                strSql = "Select Cust_No, Phone_Num, Membership From Customer Where Cust_No LIKE '%" & txtSearch.Text.Trim() & "%' OR Phone_Num LIKE '%" & txtSearch.Text.Trim() & "%' OR Membership LIKE '%" & txtSearch.Text.Trim() & "%'"
                da = New SqlDataAdapter(strSql, connection)
                ds.Clear()

                Try
                    da.Fill(ds, "Customer")
                Catch ex As Exception

                End Try
                DataGridView1.DataSource = ds.Tables("Customer")
                If ds.Tables("Customer").Rows.Count > 0 Then
                    DataGridView1.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    DataGridView1.Columns(0).DefaultCellStyle.SelectionBackColor = Color.White
                    DataGridView1.Columns(0).DefaultCellStyle.SelectionForeColor = Color.Black
                    DataGridView1.Columns(0).HeaderText = "Customer ID"

                    DataGridView1.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    DataGridView1.Columns(1).DefaultCellStyle.SelectionBackColor = Color.White
                    DataGridView1.Columns(1).DefaultCellStyle.SelectionForeColor = Color.Black
                    DataGridView1.Columns(1).HeaderText = "Phone Number"

                    DataGridView1.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    DataGridView1.Columns(2).DefaultCellStyle.SelectionBackColor = Color.White
                    DataGridView1.Columns(2).DefaultCellStyle.SelectionForeColor = Color.Black
                    DataGridView1.Columns(2).HeaderText = "Membership"
                End If
                EndConnection()
            End If
            DataGridView1.Columns.Add(dgvViewButtonCol)
            DataGridView1.Columns.Add(dgvRegisterButtonCol)
            DataGridView1.Columns.Add(dgvEditButtonCol)
            dgvEditButtonCol.FlatStyle = FlatStyle.Popup
            dgvRegisterButtonCol.FlatStyle = FlatStyle.Popup
            dgvViewButtonCol.FlatStyle = FlatStyle.Popup

            dgvViewButtonCol.DefaultCellStyle.BackColor = Color.MediumTurquoise
            dgvViewButtonCol.DefaultCellStyle.ForeColor = Color.Black
            dgvViewButtonCol.DefaultCellStyle.SelectionBackColor = Color.MediumTurquoise
            dgvViewButtonCol.DefaultCellStyle.SelectionForeColor = Color.Black
            dgvViewButtonCol.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 10, FontStyle.Bold)
            dgvViewButtonCol.HeaderText = "Membership Details"

            dgvEditButtonCol.DefaultCellStyle.BackColor = Color.MediumTurquoise
            dgvEditButtonCol.DefaultCellStyle.ForeColor = Color.Black
            dgvEditButtonCol.DefaultCellStyle.SelectionBackColor = Color.MediumTurquoise
            dgvEditButtonCol.DefaultCellStyle.SelectionForeColor = Color.Black
            dgvEditButtonCol.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 10, FontStyle.Bold)
            dgvEditButtonCol.HeaderText = "Edit Customer"

            dgvRegisterButtonCol.DefaultCellStyle.BackColor = Color.MediumTurquoise
            dgvRegisterButtonCol.DefaultCellStyle.ForeColor = Color.Black
            dgvRegisterButtonCol.DefaultCellStyle.SelectionBackColor = Color.MediumTurquoise
            dgvRegisterButtonCol.DefaultCellStyle.SelectionForeColor = Color.Black
            dgvRegisterButtonCol.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 10, FontStyle.Bold)
            dgvRegisterButtonCol.HeaderText = "Register Member"

            dgvEditButtonCol.Text = "Edit"
            dgvEditButtonCol.UseColumnTextForButtonValue = True

            dgvViewButtonCol.Text = "View"
            dgvViewButtonCol.UseColumnTextForButtonValue = True

            dgvRegisterButtonCol.Text = "Register"
            dgvRegisterButtonCol.UseColumnTextForButtonValue = True
        End If
    End Sub
End Class