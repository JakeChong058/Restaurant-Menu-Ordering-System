﻿Imports System.Data.SqlClient

Public Class frmManageStaffAddStaff
    Private intID As Integer
    Private da As SqlDataAdapter
    Private ds As DataSet = New DataSet()
    Private Sub frmManageStaffAddStaff_Load(sender As Object, e As EventArgs) Handles MyBase.Load 'Me.Shown
        Dim strSQLStatement As String
        'StaffData.ConnectServer()
        If StartConnection() = True Then
            strSQLStatement = "Select * From Staff"
            da = New SqlDataAdapter(strSQLStatement, connection)
            ds.Clear()
            Try
                da.Fill(ds, "Staff")
            Catch ex As Exception

            End Try
            If ds.Tables("Staff").Rows.Count > 0 Then
                lblID.Text = (ds.Tables("Staff").Rows(ds.Tables("Staff").Rows.Count - 1).Item("Staff_Id") + 1).ToString()
            End If
            EndConnection()
        End If
        txtConfirmPassword.Enabled = False
    End Sub


    'Private Sub cboStatus_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles cboStatus.Validating
    '    If cboStatus.SelectedIndex = -1 Then
    '        errCheck.SetError(cboStatus, "Please determine the status of the staff")
    '        e.Cancel = True
    '    Else
    '        errCheck.SetError(cboStatus, Nothing)
    '    End If
    'End Sub

    'Private Sub cboPosition_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles cboPosition.Validating
    '    If cboPosition.SelectedIndex = -1 Then
    '        errCheck.SetError(cboPosition, "Please select the position of the staff")
    '        e.Cancel = True
    '    Else
    '        errCheck.SetError(cboStatus, Nothing)
    '    End If
    'End Sub

    'Private Sub cboReason_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles cboReason.Validating
    '    If cboReason.Visible = True Then
    '        If cboReason.SelectedIndex = -1 Then
    '            errCheck.SetError(cboReason, "Please provide the reason of why the staff is not available")
    '            e.Cancel = True
    '        Else
    '            errCheck.SetError(cboReason, Nothing)
    '        End If
    '    End If
    'End Sub

    Private Sub txtName_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtName.Validating
        If txtName.Text.Trim() = "" Then
            errCheck.SetError(txtName, "Please provide the name of the staff")
            e.Cancel = True
        Else
            errCheck.SetError(txtName, Nothing)
        End If
    End Sub

    Private Sub cboPosition_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles cboPosition.Validating
        If cboPosition.SelectedIndex = -1 Then
            errCheck.SetError(cboPosition, "Please select the position of the staff")
            e.Cancel = True
        Else
            errCheck.SetError(cboPosition, Nothing)
        End If
    End Sub

    Private Sub txtPassword_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtPassword.Validating
        If txtPassword.Text.Trim() = "" Then
            errCheck.SetError(txtPassword, "Please give a password for the staff account")
            e.Cancel = True
        Else
            errCheck.SetError(txtPassword, Nothing)
        End If
    End Sub

    Private Sub txtConfirmPassword_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtConfirmPassword.Validating
        If txtConfirmPassword.Text.Trim() = "" Then
            errCheck.SetError(txtConfirmPassword, "Please confirm the password for the staff account")
            e.Cancel = True
        ElseIf txtConfirmPassword.Text.Trim() <> txtPassword.Text.Trim() Then
            errCheck.SetError(txtConfirmPassword, "Confirm Password must be same with the password")
            e.Cancel = True
        Else
            errCheck.SetError(txtConfirmPassword, Nothing)
        End If
    End Sub

    Private Sub btnRegister_Click(sender As Object, e As EventArgs) Handles btnRegister.Click
        Dim strErrorMsg As String = ""
        If Me.ValidateChildren() = False Then
            Return
        Else
            Dim strSQLStatement As String
            Dim MSSqlCommand As New SqlCommand

            If StartConnection() = True Then
                strSQLStatement = "Insert into Staff (Staff_Id, Staff_Name, Position,Password,No_Of_Order,Status) values (@ID, @name,@position, @password,@nooforder,@status);"
                MSSqlCommand = New SqlCommand(strSQLStatement, connection)
                MSSqlCommand.Parameters.AddWithValue("@ID", lblID.Text)
                MSSqlCommand.Parameters.AddWithValue("@name", txtName.Text.Trim())
                MSSqlCommand.Parameters.AddWithValue("@position", cboPosition.SelectedItem)
                MSSqlCommand.Parameters.AddWithValue("@password", txtPassword.Text.Trim())
                MSSqlCommand.Parameters.AddWithValue("@nooforder", 0)
                MSSqlCommand.Parameters.AddWithValue("@status", "Available")
                MSSqlCommand.ExecuteNonQuery()
                'StaffData.ConnectServer()
                MessageBox.Show("New staff [" & lblID.Text & "] " & txtName.Text & " has been registered successfully", "Staff Registered Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information)
                'Me.Close()
                EndConnection()
                frmManageStaff.mnuAll_Click(Nothing, Nothing)
                btnClear_Click(Nothing, Nothing)
            Else
                MessageBox.Show("Error Connecting Server", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click, MyBase.Closed
        Me.Close()
    End Sub

    Private Sub txtPassword_TextChanged(sender As Object, e As EventArgs) Handles txtPassword.TextChanged
        If txtPassword.Text.Trim() = "" Then
            txtConfirmPassword.Enabled = False
        Else
            txtConfirmPassword.Enabled = True
        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtName.Text = ""
        txtPassword.Text = ""
        txtConfirmPassword.Text = ""
        txtConfirmPassword.Enabled = False
        cboPosition.SelectedIndex = -1
        errCheck.Clear()
    End Sub

    'Private Sub frmManageStaffAddStaff_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
    '    frmManageStaff.Show()
    'End Sub
End Class