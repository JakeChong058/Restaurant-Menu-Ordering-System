﻿Imports Microsoft.VisualBasic.ApplicationServices
Imports System.Data.SqlClient

Public Class frmStaffChangePassword
    Private da As SqlDataAdapter
    Private ds As DataSet = New DataSet()
    Private strOldPassword As String
    Private Sub frmStaffChangePassword_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim strSql As String
        StaffData.ConnectServer()
        txtNewPassword.Text = ""
        txtOldPassword.Text = ""
        If StartConnection() = True Then
            strSql = "Select Staff_Id, Staff_Name, Password From Staff Where Staff_Id = " & frmStaffLoginPage.intCurrentStaffID
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            Try
                da.Fill(ds, "Staff")
            Catch ex As Exception
            End Try
            If ds.Tables("Staff").Rows.Count > 0 Then
                lblId.Text = ds.Tables("Staff").Rows(0).Item("Staff_Id")
                txtName.Text = ds.Tables("Staff").Rows(0).Item("Staff_Name")
                strOldPassword = ds.Tables("Staff").Rows(0).Item("Password")
            End If
            EndConnection()
        End If
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        Dim strErrorMsg As String = ""
        If txtName.Text.Trim() = "" Then
            strErrorMsg += "Please provide your name" & vbNewLine
        End If
        If txtOldPassword.Text.Trim() = "" Then
            strErrorMsg += "Please provide your old password" & vbNewLine
        End If
        If txtNewPassword.Text.Trim() = "" Then
            strErrorMsg += "Please provide your new password" & vbNewLine
        End If
        If strErrorMsg <> "" Then
            MessageBox.Show(strErrorMsg, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            If txtOldPassword.Text.Trim() <> strOldPassword Then
                MessageBox.Show("Incorrect old password given", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Else
                Dim strSQLStatement As String
                Dim MSSqlCommand As New SqlCommand

                If StartConnection() = True Then
                    strSQLStatement = "Update Staff set Staff_Name = @StaffName, Password=@Password where Staff_Id=@staffid"
                    MSSqlCommand = New SqlCommand(strSQLStatement, connection)
                    MSSqlCommand.Parameters.AddWithValue("@StaffName", txtName.Text.Trim())
                    MSSqlCommand.Parameters.AddWithValue("@Password", txtNewPassword.Text.Trim())
                    MSSqlCommand.Parameters.AddWithValue("@staffid", lblId.Text)
                    MSSqlCommand.ExecuteNonQuery()
                    EndConnection()
                    MessageBox.Show("Profile has been updated", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    'StaffData.ConnectServer()
                    frmStaffProfile.frmStaffProfile_Load(Nothing, Nothing)
                    Me.Close()
                End If
            End If
        End If
    End Sub

    Private Sub btnChangeSecret_Click(sender As Object, e As EventArgs) Handles btnChangeSecret.Click
        txtName.Clear()
        txtNewPassword.Clear()
        txtOldPassword.Clear()
    End Sub
End Class