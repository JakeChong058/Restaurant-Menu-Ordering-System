﻿Public Class AsgFrmGenerateMenuReport
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub btnGenerate_Click(sender As Object, e As EventArgs) Handles btnGenerate.Click
        If rad5.Checked = False And rad10.Checked = False And rad15.Checked = False Then
            MessageBox.Show("Please select the number of orders for top menu items", "No Option Selected", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        ElseIf rad5.Checked Then
            AsgFrmMenuReport.intNoOfOrders = 5
            AsgFrmMenuReport.Show()
            Me.Hide()
        ElseIf rad10.Checked Then
            AsgFrmMenuReport.intNoOfOrders = 10
            AsgFrmMenuReport.Show()
            Me.Hide()
        Else
            AsgFrmMenuReport.intNoOfOrders = 15
            AsgFrmMenuReport.Show()
            Me.Hide()
        End If

    End Sub

    Private Sub AsgFrmGenerateMenuReport_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        AsgFrmStaffOrder.Show()

    End Sub


End Class