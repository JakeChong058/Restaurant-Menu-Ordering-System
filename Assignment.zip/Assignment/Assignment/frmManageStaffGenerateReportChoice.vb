﻿Public Class frmManageStaffGenerateReportChoice
    Friend blnGenerateReportStaffManager As Boolean = False
    Friend blnGenerateReportStaff As Boolean = False
    Friend blnGenerateReportManager As Boolean = False


    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Close()
        'frmManageStaff.Show()
    End Sub

    Private Sub btnStaffManager_Click(sender As Object, e As EventArgs) Handles btnStaffManager.Click
        blnGenerateReportManager = False
        blnGenerateReportStaff = False
        blnGenerateReportStaffManager = True
        Me.Hide()
        frmManageStaffGenerateReport.Show()
    End Sub

    Private Sub btnManager_Click(sender As Object, e As EventArgs) Handles btnManager.Click
        blnGenerateReportManager = True
        blnGenerateReportStaff = False
        blnGenerateReportStaffManager = False
        Me.Hide()
        frmManageStaffGenerateReport.Show()
    End Sub

    Private Sub btnStaff_Click(sender As Object, e As EventArgs) Handles btnStaff.Click
        blnGenerateReportManager = False
        blnGenerateReportStaff = True
        blnGenerateReportStaffManager = False
        Me.Hide()
        frmManageStaffGenerateReport.Show()
    End Sub

    Private Sub frmManageStaffGenerateReportChoice_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub frmManageStaffGenerateReportChoice_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        frmManageStaff.Show()
    End Sub
End Class