﻿Imports System.Collections.ObjectModel
Imports System.Data.Common
Imports System.Data.SqlClient
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class FrmMemberRegistration
    Private da As SqlDataAdapter
    Private dataset As DataSet = New DataSet()
    Private intMember As Integer

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtName.Clear()
        txtEmail.Clear()
        mskIc.Clear()
        radFemale.Checked = False
        radMale.Checked = False
        err.Clear()
    End Sub

    Private Sub btnRegister_Click(sender As Object, e As EventArgs) Handles btnRegister.Click
        Dim strQuery As String
        Dim MSSqlCommand As New SqlCommand

        If Me.ValidateChildren() = False Then
            Return
        End If

        If StartConnection() = True Then
            strQuery = "Select Member_Id From Member"
            da = New SqlDataAdapter(strQuery, connection)
            dataset.Clear()
            Try
                da.Fill(dataset, "Member")
            Catch ex As Exception

            End Try
            If dataset.Tables("Member").Rows.Count > 0 Then
                intMember = Integer.Parse(dataset.Tables("Member").Rows(dataset.Tables("Member").Rows.Count - 1).Item("Member_Id")) + 1
            Else
                intMember = 1001
            End If
            EndConnection()
        End If

        Dim Gender As String = String.Empty
        If radMale.Checked Then
            Gender = "M"
        ElseIf radFemale.Checked Then
            Gender = "F"
        Else
            MessageBox.Show("Please select member's gender", "No Gender Selected", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If
        Dim validator As New EmailVerification()
        Dim email As String = txtEmail.Text.Trim()
        Dim validEmail As Boolean = validator.IsEmailValid(email)
        Dim userIC As String = mskIc.Text
        Dim day, month, year As Integer

        If userIC.Length = 12 Then
            Dim dayStr As String = userIC.Substring(0, 2)
            Dim monthStr As String = userIC.Substring(2, 2)
            Dim yearStr As String = userIC.Substring(4, 2)

            If validEmail Then
                If Integer.TryParse(dayStr, day) AndAlso Integer.TryParse(monthStr, month) AndAlso Integer.TryParse(yearStr, year) Then

                    If year <= 22 Then
                        year += 2000
                    Else
                        year += 1900
                    End If
                    If StartConnection() = True Then
                        strQuery = "INSERT INTO Member (Member_Id, Member_Name, Member_Ic, Cust_No, Member_Email, Gender, Points) VALUES (@id, @name, @ic, @no, @email, @gender, @points)"
                        MSSqlCommand = New SqlCommand(strQuery, connection)
                        MSSqlCommand.Parameters.AddWithValue("@id", intMember)
                        MSSqlCommand.Parameters.AddWithValue("@name", txtName.Text.Trim())
                        MSSqlCommand.Parameters.AddWithValue("@ic", mskIc.Text)
                        MSSqlCommand.Parameters.AddWithValue("@no", FrmMember.intCustNo)
                        MSSqlCommand.Parameters.AddWithValue("@email", txtEmail.Text.Trim())
                        MSSqlCommand.Parameters.AddWithValue("@gender", Gender)
                        MSSqlCommand.Parameters.AddWithValue("@Points", 50)
                        MSSqlCommand.ExecuteNonQuery()
                        MessageBox.Show("Customer [" & FrmMember.intCustNo.ToString() & "] has been registered as member successfully.", "Member Registered", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        'Me.Close()
                        EndConnection()
                        'FrmMember.Show()
                    End If
                    If StartConnection() = True Then
                        strQuery = "Update Customer Set Membership = @Membership Where Cust_No = @Cust_No"
                        MSSqlCommand = New SqlCommand(strQuery, connection)
                        MSSqlCommand.Parameters.AddWithValue("@Membership", "Member")
                        MSSqlCommand.Parameters.AddWithValue("@Cust_No", FrmMember.intCustNo)
                        MSSqlCommand.ExecuteNonQuery()
                        'MessageBox.Show("Customer [" & FrmMember.intCustNo.ToString() & "] has been registered as member successfully.", "Member Registered", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        EndConnection()
                        Me.Close()
                        'FrmMember.Show()
                    End If
                Else
                    MessageBox.Show("Invalid date of birth.", "Invalid Date", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            Else
                MessageBox.Show("The email Is Not valid.", "Invalid Format", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Else
            MessageBox.Show("IC Number must be exactly 12 characters long.", "Invalid Length", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub mskIc_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles mskIc.Validating
        Dim strIC As String = If(mskIc.MaskCompleted, mskIc.Text, "")

        If strIC = "" Then
            err.SetError(mskIc, "Please provide member's IC Number")
                        e.Cancel = True
        Else
            err.SetError(mskIc, Nothing)
        End If
    End Sub

    Private Sub txtName_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtName.Validating
        If txtName.Text.Trim() = "" Then
            err.SetError(txtName, "Please provide member's name")
            e.Cancel = True
        Else
            err.SetError(txtName, Nothing)
        End If
    End Sub

    Private Sub txtEmail_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles txtEmail.Validating
        If txtEmail.Text.Trim() = "" Then
            err.SetError(txtEmail, "Please provide member's email")
            e.Cancel = True
        Else
            err.SetError(txtEmail, Nothing)
        End If
    End Sub


    Private Sub FrmMemberRegistration_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblCust.Text = "Register Member for Customer [" & FrmMember.intCustNo & "]"
    End Sub

    Private Sub FrmMemberRegistration_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        FrmMember.FrmMember_Load(Nothing, Nothing)
        FrmMember.Show()
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub
End Class