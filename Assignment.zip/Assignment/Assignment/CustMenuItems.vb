﻿Public Class CustMenuItems
    Private Property strMenuId As String
    Private Property strDescription As String
    Private Property decPrice As Decimal
    Private Property strCategory As String
    Private Property chIsPromotion As Char
    Private Property strSubCategory As String
    Private Property strImage As String
    Private Property strStatus As String
    Private Property strAvailability As String
    Private Property btnAdd As Button
    Private Property intOrderCount As Integer
    Private Property decPromotionRate As Decimal

    Private Property decDiscount As Decimal

    Public Sub New(strMenuId As String, strDescription As String, decPrice As Decimal, strCategory As String, chIsPromotion As Char, strSubCategory As String, strImage As String, strStatus As String, strAvailability As String)
        Me.strMenuId = strMenuId
        Me.strDescription = strDescription
        Me.decPrice = decPrice
        Me.chIsPromotion = chIsPromotion
        Me.strSubCategory = strSubCategory
        Me.strImage = strImage
        Me.strStatus = strStatus
        Me.strAvailability = strAvailability
        Me.btnAdd = New Button()
        'Me.btnEdit = New Button()
        'Me.btnDelete = New Button()
        If Me.strStatus = "Selling" Then
            btnAdd.Text = "Add +"
            btnAdd.Enabled = True
        Else
            btnAdd.Text = "Sold Out"
            btnAdd.Enabled = False
        End If

        'btnEdit.BackgroundImage = My.Resources.Pencil
        'btnDelete.BackgroundImage = My.Resources.Dustbin
        'btnEdit.BackgroundImageLayout = ImageLayout.Zoom
        'btnDelete. BackgroundImageLayout = ImageLayout.Zoom
        btnAdd.Font = New Font("Microsoft Sans Serif", 9, FontStyle.Bold)
        btnAdd.Dock = DockStyle.Fill
        btnAdd.BackColor = Color.MediumTurquoise
    End Sub

    Public Sub New(strMenuId As String, strDescription As String, decPrice As Decimal, strCategory As String, chIsPromotion As Char, strSubCategory As String, strImage As String, strStatus As String, strAvailability As String, intOrderCount As Integer, decPromotionRate As Decimal, decDiscount As Decimal)
        Me.strMenuId = strMenuId
        Me.strDescription = strDescription
        Me.decPrice = decPrice
        Me.chIsPromotion = chIsPromotion
        Me.strSubCategory = strSubCategory
        Me.strImage = strImage
        Me.strStatus = strStatus
        Me.strAvailability = strAvailability
        Me.intOrderCount = intOrderCount
        Me.decPromotionRate = decPromotionRate
        Me.decDiscount = decDiscount
        Me.btnAdd = New Button()
        'Me.btnEdit = New Button()
        'Me.btnDelete = New Button()
        If Me.strStatus = "Selling" Then
            btnAdd.Text = "Add +"
            btnAdd.Enabled = True
        Else
            btnAdd.Text = "Sold Out"
            btnAdd.Enabled = False
        End If

        'btnEdit.BackgroundImage = My.Resources.Pencil
        'btnDelete.BackgroundImage = My.Resources.Dustbin
        'btnEdit.BackgroundImageLayout = ImageLayout.Zoom
        'btnDelete. BackgroundImageLayout = ImageLayout.Zoom
        btnAdd.Font = New Font("Microsoft Sans Serif", 9, FontStyle.Bold)
        btnAdd.Dock = DockStyle.Fill
        btnAdd.BackColor = Color.MediumTurquoise
    End Sub

    Public Sub New(strMenuId As String, strDescription As String, decDiscount As Decimal, decPromotionRate As Decimal, intOrderCount As Integer)
        Me.strMenuId = strMenuId
        Me.strDescription = strDescription
        Me.decPromotionRate = decPromotionRate
        Me.intOrderCount = intOrderCount
        Me.decDiscount = decDiscount
    End Sub

    Public Function GetStrMenuId() As String
        Return strMenuId
    End Function

    Public Function GetStrDescription() As String
        Return strDescription
    End Function

    Public Function GetDecPrice() As Decimal
        Return decPrice
    End Function

    Public Function GetStrCategory() As String
        Return strCategory
    End Function

    Public Function GetChIsPromotion() As Char
        Return chIsPromotion
    End Function

    Public Function GetStrSubCategory() As String
        Return strSubCategory
    End Function

    Public Function GetStrImage() As String
        Return strImage
    End Function

    Public Function GetButton() As Button
        Return btnAdd
    End Function

    Public Function GetStrStatus() As String
        Return strStatus
    End Function

    Public Function GetStrAvailability() As String
        Return strAvailability
    End Function

    Public Function GetIntOrderCount() As Integer
        Return intOrderCount
    End Function

    Public Function GetDecPromotionRate() As Decimal
        Return decPromotionRate
    End Function

    Public Function GetDecDiscount() As Decimal
        Return decDiscount
    End Function

    Public Sub SetPrice(decPromotionRate As Decimal)
        Dim decDiscount As Decimal = 0D
        decDiscount = Me.decPrice * decPromotionRate
        Me.decPrice -= decDiscount
    End Sub
End Class
