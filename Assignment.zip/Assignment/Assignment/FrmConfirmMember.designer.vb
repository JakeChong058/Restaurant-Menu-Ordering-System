﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FrmConfirmMember
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.lbltxtPassword = New System.Windows.Forms.Label()
        Me.mskIc = New System.Windows.Forms.MaskedTextBox()
        Me.lblICText = New System.Windows.Forms.Label()
        Me.btnToMemberUpdate = New System.Windows.Forms.Button()
        Me.lbltxtToMember = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Assignment.My.Resources.Resources.Island_Cafe_Logo
        Me.PictureBox1.Location = New System.Drawing.Point(346, 92)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(200, 174)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 4
        Me.PictureBox1.TabStop = False
        '
        'txtPassword
        '
        Me.txtPassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.txtPassword.Location = New System.Drawing.Point(434, 379)
        Me.txtPassword.Margin = New System.Windows.Forms.Padding(2)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPassword.Size = New System.Drawing.Size(139, 26)
        Me.txtPassword.TabIndex = 11
        '
        'lbltxtPassword
        '
        Me.lbltxtPassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.125!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltxtPassword.Location = New System.Drawing.Point(263, 374)
        Me.lbltxtPassword.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lbltxtPassword.Name = "lbltxtPassword"
        Me.lbltxtPassword.Size = New System.Drawing.Size(166, 31)
        Me.lbltxtPassword.TabIndex = 10
        Me.lbltxtPassword.Text = "Password:"
        Me.lbltxtPassword.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'mskIc
        '
        Me.mskIc.Font = New System.Drawing.Font("Microsoft PhagsPa", 8.0!)
        Me.mskIc.Location = New System.Drawing.Point(434, 338)
        Me.mskIc.Margin = New System.Windows.Forms.Padding(2)
        Me.mskIc.Mask = "000000000000"
        Me.mskIc.Name = "mskIc"
        Me.mskIc.Size = New System.Drawing.Size(139, 28)
        Me.mskIc.TabIndex = 13
        Me.mskIc.ValidatingType = GetType(Date)
        '
        'lblICText
        '
        Me.lblICText.AutoSize = True
        Me.lblICText.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.lblICText.Location = New System.Drawing.Point(392, 339)
        Me.lblICText.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblICText.Name = "lblICText"
        Me.lblICText.Size = New System.Drawing.Size(38, 25)
        Me.lblICText.TabIndex = 14
        Me.lblICText.Text = "IC:"
        '
        'btnToMemberUpdate
        '
        Me.btnToMemberUpdate.BackColor = System.Drawing.Color.White
        Me.btnToMemberUpdate.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.875!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnToMemberUpdate.ForeColor = System.Drawing.Color.Blue
        Me.btnToMemberUpdate.Location = New System.Drawing.Point(346, 458)
        Me.btnToMemberUpdate.Margin = New System.Windows.Forms.Padding(2)
        Me.btnToMemberUpdate.Name = "btnToMemberUpdate"
        Me.btnToMemberUpdate.Size = New System.Drawing.Size(220, 31)
        Me.btnToMemberUpdate.TabIndex = 15
        Me.btnToMemberUpdate.Text = "Click on me to continue"
        Me.btnToMemberUpdate.UseVisualStyleBackColor = False
        '
        'lbltxtToMember
        '
        Me.lbltxtToMember.AutoSize = True
        Me.lbltxtToMember.BackColor = System.Drawing.Color.LightGray
        Me.lbltxtToMember.Location = New System.Drawing.Point(279, 288)
        Me.lbltxtToMember.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lbltxtToMember.Name = "lbltxtToMember"
        Me.lbltxtToMember.Size = New System.Drawing.Size(322, 20)
        Me.lbltxtToMember.TabIndex = 16
        Me.lbltxtToMember.Text = "Dear member, please input the details below"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button1.Location = New System.Drawing.Point(396, 530)
        Me.Button1.Margin = New System.Windows.Forms.Padding(2)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(104, 43)
        Me.Button1.TabIndex = 20
        Me.Button1.Text = "Back"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'FrmConfirmMember
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(944, 612)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.lbltxtToMember)
        Me.Controls.Add(Me.btnToMemberUpdate)
        Me.Controls.Add(Me.mskIc)
        Me.Controls.Add(Me.lblICText)
        Me.Controls.Add(Me.txtPassword)
        Me.Controls.Add(Me.lbltxtPassword)
        Me.Controls.Add(Me.PictureBox1)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "FrmConfirmMember"
        Me.Text = "FrmConfirmUser"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents lbltxtPassword As Label
    Friend WithEvents mskIc As MaskedTextBox
    Friend WithEvents lblICText As Label
    Friend WithEvents btnToMemberUpdate As Button
    Friend WithEvents lbltxtToMember As Label
    Friend WithEvents Button1 As Button
End Class
