﻿Imports System.Data.SqlClient

Public Class FrmEditCustomer
    Private da As SqlDataAdapter
    Private ds As DataSet = New DataSet()
    Private Sub FrmEditCustomer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim strSql As String
        lblCustID.Text = FrmMember.intCustNo.ToString()
        If StartConnection() = True Then
            strSql = "Select Phone_Num, Password From Customer Where Cust_No = " & Integer.Parse(lblCustID.Text)
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            Try
                da.Fill(ds, "Customer")
            Catch ex As Exception

            End Try
            If ds.Tables("Customer").Rows.Count > 0 Then
                mskPhone.Text = ds.Tables("Customer").Rows(0).Item("Phone_Num")
                lblPassword.Text = ds.Tables("Customer").Rows(0).Item("Password")
            End If
            EndConnection()
        End If
    End Sub

    Private Sub mskPhone_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles mskPhone.Validating
        Dim strPhoneNumber As String = If(mskPhone.MaskCompleted, mskPhone.Text, "")

        If strPhoneNumber = "" Then
            err.SetError(mskPhone, "Please provide your phone number")
            e.Cancel = True
        Else
            err.SetError(mskPhone, Nothing)
        End If
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim strQuery As String
        Dim MSSqlCommand As New SqlCommand
        If Me.ValidateChildren() = False Then
            Return
        End If

        If StartConnection() = True Then
            strQuery = "Update Customer Set Phone_Num = @Phone_Num, Password = @Password Where Cust_No = @Cust_No"
            MSSqlCommand = New SqlCommand(strQuery, connection)
            MSSqlCommand.Parameters.AddWithValue("@Phone_Num", mskPhone.Text)
            If txtPassword.Text.Trim() = "" Then
                MSSqlCommand.Parameters.AddWithValue("@Password", lblPassword.Text)
            Else
                MSSqlCommand.Parameters.AddWithValue("@Password", txtPassword.Text.Trim())
            End If
            MSSqlCommand.Parameters.AddWithValue("@Cust_No", Integer.Parse(lblCustID.Text))
            MSSqlCommand.ExecuteNonQuery()
            MessageBox.Show("Customer data updated", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            EndConnection()
            FrmMember.FrmMember_Load(Nothing, Nothing)
            Me.Close()
        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        mskPhone.Text = ""
        txtPassword.Clear()
        err.Clear()
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub
End Class