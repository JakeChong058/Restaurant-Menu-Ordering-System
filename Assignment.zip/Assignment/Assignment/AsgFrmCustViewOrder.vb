﻿Imports System.Data.SqlClient

Public Class AsgFrmCustViewOrder
    Private intCustNo = FrmLoginPage.intCustNo
    'Friend strParts() As String
    Private da As SqlDataAdapter
    Private ds As DataSet = New DataSet()
    'Friend order As OrderList
    Friend intOrderNumber As Integer
    'Private orders() As OrderList
    'Private menus() As CustMenuItems
    'The default order number
    'Private intOrderNo As Integer = 1001
    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Close()
        AsgFrmCustOrder.Show()
    End Sub

    Private Sub AsgFrmCustViewOrder_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim strSql As String
        Dim buttonCol As New DataGridViewButtonColumn
        'If StartConnection() = True Then
        '    strSql = "Select M.Menu_Id, M.Description, M.Price, M.Category, M.IsPromotion, M.SubCategory, M.Image From Menu M, Order_List O, Food_Order F, Customer C WHERE F.Cust_No = C.Cust_No AND O.Menu_Id = M.Menu_Id AND O.Order_No = F.Order_No AND F.Cust_No = " & intCustNo
        '    da = New SqlDataAdapter(strSql, connection)
        '    ds.Clear()
        '    da.Fill(ds, "Menu")
        '    ReDim menus(ds.Tables("Menu").Rows.Count - 1)
        '    If ds.Tables("Menu").Rows.Count > 0 Then
        '        For intCount = 0 To menus.Length - 1 Step 1
        '            menus(intCount) = New CustMenuItems(ds.Tables("Menu").Rows(intCount).Item(0),
        '            ds.Tables("Menu").Rows(intCount).Item(1), ds.Tables("Menu").Rows(intCount).Item(2),
        '            ds.Tables("Menu").Rows(intCount).Item(3), ds.Tables("Menu").Rows(intCount).Item(4),
        '            ds.Tables("Menu").Rows(intCount).Item(5), ds.Tables("Menu").Rows(intCount).Item(6))
        '        Next intCount
        '    End If
        '    EndConnection()
        'End If
        lblNone.Visible = False
        If StartConnection() = True Then
            strSql = "Select O.Order_No, O.Date From Food_Order O, Customer C WHERE O.Status <> 'Completed' AND O.Cust_No = C.Cust_No AND O.Cust_No = " & intCustNo '& " AND I.Menu_Id = '" & menuItem(intNumber).GetStrMenuId() & "'"
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            Try
                da.Fill(ds, "Food_Order")
            Catch ex As Exception
                'do something
            End Try
            'ReDim orders(ds.Tables("Food_Order").Rows.Count - 1)
            'ReDim menus(ds.Tables("Food_Order").Rows.Count - 1)
            If ds.Tables("Food_Order").Rows.Count > 0 Then
                DataGridView1.Visible = True
                lblNone.Visible = False
                DataGridView1.DataSource = ds.Tables("Food_Order")
                'ReDim descriptionLabel(ds.Tables("CartItem").Rows.Count - 1)
                'ReDim priceLabel(ds.Tables("CartItem").Rows.Count - 1)
                'lblEmpty.Visible = False
                'TableLayoutPanel1.Visible = True
                'btnClearCart.Enabled = True
                'btnProceed.Enabled = True
                'ReDim orders(ds.Tables("Food_Order").Rows.Count - 1)
                'ReDim decPrice(ds.Tables("CartItem").Rows.Count - 1)
                'ReDim intQuantityEach(ds.Tables("CartItem").Rows.Count - 1)
                'ds.Tables("CartItem").Columns.Add("Item", Type.GetType("System.String"))
                'TableLayoutPanel1.RowCount = ds.Tables("CartItem").Rows.Count + 1
                'TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 41))
                'TableLayoutPanel1.Height = 33 * TableLayoutPanel1.RowCount
                'TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 48))
                'ds.Tables("Food_Order").Columns.Add("Action", Type.GetType("System.Windows.Forms.Button"))
                DataGridView1.Columns.Add(buttonCol)
                DataGridView1.Columns(0).HeaderText = "Order ID"
                DataGridView1.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(0).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(0).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(1).HeaderText = "Order Date and Time"
                DataGridView1.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(1).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(1).DefaultCellStyle.SelectionForeColor = Color.Black
                buttonCol.HeaderText = "View Orders"
                buttonCol.Text = "View Order Details"
                'buttonCol.BackColor = Color.MediumTurquoise
                buttonCol.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 10, FontStyle.Bold)
                buttonCol.UseColumnTextForButtonValue = True
                buttonCol.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                buttonCol.FlatStyle = FlatStyle.Popup
                buttonCol.DefaultCellStyle.BackColor = Color.MediumTurquoise
                buttonCol.DefaultCellStyle.SelectionBackColor = Color.MediumTurquoise
                buttonCol.DefaultCellStyle.SelectionForeColor = Color.Black
                'For intIndex = 0 To orders.Length - 1 Step 1
                '    orders(intIndex) = New OrderList(ds.Tables("Food_Order").Rows(intIndex).Item("Order_No"), menus(intIndex))
                '    'DataGridView1.Item(0, intIndex).Value = menus(intIndex).GetStrDescription()
                '    'DataGridView1.Item("Action", intIndex).Value = orders(intIndex).GetBtnView()
                '    DataGridView1.Controls.Add(orders(intIndex).GetBtnView())
                '    AddHandler orders(intIndex).GetBtnView().Click, AddressOf Button1_Click
                'Next intIndex
                'DataGridView1.C = DataGridViewContentAlignment.MiddleCenter
                'TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 45))
                'lblQty.Text = intQuantity.ToString()
                'lblSubtotal.Text = decSubtotal.ToString("C")
                'lblSST.Text = "6%"
                'lblService.Text = "10%"
                'lblGrand.Text = decGrandTotal.ToString("C")
            Else
                DataGridView1.Visible = False
                lblNone.Visible = True
            End If
            EndConnection()
        End If
    End Sub

    Private Sub AsgFrmCustViewOrder_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        AsgFrmCustOrder.Show()
    End Sub

    'Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
    '    For intIndex = 0 To orders.Length - 1 Step 1
    '        If sender Is orders(intIndex).GetBtnView() Then
    '            MessageBox.Show("Order Number #" & orders(intIndex).GetIntOrderNo().ToString() & " is clicked")
    '            Exit For
    '        End If
    '    Next

    'End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Try
            If DataGridView1.Columns(e.ColumnIndex).HeaderText = "View Orders" Then
                'MessageBox.Show("Button: " & e.RowIndex & " is clicked")
                intOrderNumber = DataGridView1.Rows(e.RowIndex).Cells(0).Value
                Me.Hide()
                AsgFrmCustCurrentOrder.Show()
            End If
        Catch ex As Exception

        End Try

    End Sub
End Class