﻿Imports System.Data.SqlClient

Public Class AsgFrmStaffUpcomingOrder
    'Private intCustNo = 1001
    'Friend strParts() As String
    Private da As SqlDataAdapter
    Private ds As DataSet = New DataSet()
    'Friend order As OrderList
    Friend intOrderNumber As Integer
    'Private orders() As OrderList
    'Private menus() As CustMenuItems
    'The default order number
    'Private intOrderNo As Integer = 1001
    Private Sub AsgFrmStaffOrder_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim strSql As String
        Dim viewButtonCol As New DataGridViewButtonColumn
        Dim acceptButtonCol As New DataGridViewButtonColumn
        If StartConnection() = True Then
            strSql = "Select O.Order_No, O.Date, O.Total_Items, C.Phone_Num, O.Status From Food_Order O, Customer C WHERE O.Cust_No = C.Cust_No AND O.Status = 'Waiting for Accept'"
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            Try
                da.Fill(ds, "Food_Order")
            Catch ex As Exception
                'do something
            End Try
            'ReDim orders(ds.Tables("Food_Order").Rows.Count - 1)
            'ReDim menus(ds.Tables("Food_Order").Rows.Count - 1)
            If ds.Tables("Food_Order").Rows.Count > 0 Then
                DataGridView1.DataSource = ds.Tables("Food_Order")
                DataGridView1.Columns.Add(viewButtonCol)
                DataGridView1.Columns.Add(acceptButtonCol)
                'DataGridView1.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(0).HeaderText = "Order ID"
                DataGridView1.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(0).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(0).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(1).HeaderText = "Order Date and Time"
                DataGridView1.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(1).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(1).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(2).HeaderText = "Total Items"
                DataGridView1.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(2).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(2).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(3).HeaderText = "Placed By"
                DataGridView1.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(3).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(3).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(4).HeaderText = "Status"
                DataGridView1.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(4).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(4).DefaultCellStyle.SelectionForeColor = Color.Black
                viewButtonCol.HeaderText = "View Order List"
                viewButtonCol.Text = "View Order Items"
                acceptButtonCol.HeaderText = "Accept Orders"
                acceptButtonCol.Text = "Accept"
                'buttonCol.BackColor = Color.MediumTurquoise
                viewButtonCol.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 10, FontStyle.Bold)
                viewButtonCol.UseColumnTextForButtonValue = True
                viewButtonCol.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                viewButtonCol.FlatStyle = FlatStyle.Popup
                viewButtonCol.DefaultCellStyle.BackColor = Color.MediumTurquoise
                viewButtonCol.DefaultCellStyle.SelectionBackColor = Color.MediumTurquoise
                viewButtonCol.DefaultCellStyle.SelectionForeColor = Color.Black
                acceptButtonCol.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 10, FontStyle.Bold)
                acceptButtonCol.UseColumnTextForButtonValue = True
                acceptButtonCol.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                acceptButtonCol.FlatStyle = FlatStyle.Popup
                acceptButtonCol.DefaultCellStyle.BackColor = Color.MediumTurquoise
                acceptButtonCol.DefaultCellStyle.SelectionBackColor = Color.MediumTurquoise
                acceptButtonCol.DefaultCellStyle.SelectionForeColor = Color.Black
                lblOrderToday.Text = ds.Tables("Food_Order").Rows.Count.ToString()
            End If
            EndConnection()
        End If
    End Sub
    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Try
            If DataGridView1.Columns(e.ColumnIndex).HeaderText = "View Order List" Then
                'MessageBox.Show("View Button: " & e.RowIndex & " is clicked")
                intOrderNumber = DataGridView1.Rows(e.RowIndex).Cells(0).Value
                Me.Hide()
                AsgFrmViewOrderList.IsFromUpcoming()
                AsgFrmViewOrderList.Show()
            ElseIf DataGridView1.Columns(e.ColumnIndex).HeaderText = "Accept Orders" Then
                Dim strSql As String
                Dim MSSqlCommand As New SqlCommand
                intOrderNumber = DataGridView1.Rows(e.RowIndex).Cells(0).Value
                'MessageBox.Show("Accept Button: " & e.RowIndex & " is clicked")
                If StartConnection() = True Then
                    strSql = "Update Food_Order set Status=@Status Where Order_No = @Order_No"
                    MSSqlCommand = New SqlCommand(strSql, connection)
                    MSSqlCommand.Parameters.AddWithValue("@Status", "Received")
                    MSSqlCommand.Parameters.AddWithValue("@Order_No", intOrderNumber)
                    MSSqlCommand.ExecuteNonQuery()
                    MessageBox.Show("Order [" & intOrderNumber & "] has been accepted." & vbNewLine & "You can monitor this order under Current Order.", "Order Accepted", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    EndConnection()
                    AsgFrmStaffCompleteOrder.Close()
                    AsgFrmStaffCurrentOrder.Close()
                    AsgFrmStaffOrder_Load(Nothing, Nothing)
                End If
            End If
        Catch ex As Exception
        End Try

    End Sub

    Private Sub mnuCurrentOrder_Click(sender As Object, e As EventArgs) Handles mnuCurrentOrder.Click
        Me.Hide()
        AsgFrmStaffCurrentOrder.Show()
    End Sub

    Private Sub mnuCompleteOrder_Click(sender As Object, e As EventArgs) Handles mnuCompleteOrder.Click
        Me.Hide()
        AsgFrmStaffCompleteOrder.Show()
    End Sub

    Private Sub txtSearch_TextChanged(sender As Object, e As EventArgs) Handles txtSearch.TextChanged
        If txtSearch.Text.Trim() = "" Then
            DataGridView1.Columns.Clear()
            'DataGridView1.Rows.Clear()
            DataGridView1.DataSource = ""
            AsgFrmStaffOrder_Load(Nothing, Nothing)
        Else
            DataGridView1.Columns.Clear()
            'DataGridView1.Rows.Clear()
            DataGridView1.DataSource = ""
            Dim strSql As String
            Dim viewButtonCol As New DataGridViewButtonColumn
            Dim acceptButtonCol As New DataGridViewButtonColumn
            If StartConnection() = True Then
                strSql = "Select O.Order_No, O.Date, O.Total_Items, C.Phone_Num, O.Status From Food_Order O, Customer C WHERE O.Cust_No = C.Cust_No AND O.Status = 'Waiting for Accept' AND O.Order_No LIKE '%" & txtSearch.Text.Trim() & "%' OR O.Date LIKE '%" & txtSearch.Text.Trim() & "%' OR O.Total_Items LIKE '%" & txtSearch.Text.Trim() & "%' OR C.Phone_Num LIKE '%" & txtSearch.Text.Trim() & "%'"
                da = New SqlDataAdapter(strSql, connection)
                ds.Clear()
                Try
                    da.Fill(ds, "Food_Order")
                Catch ex As Exception
                    'do something
                End Try
                'ReDim orders(ds.Tables("Food_Order").Rows.Count - 1)
                'ReDim menus(ds.Tables("Food_Order").Rows.Count - 1)
                If ds.Tables("Food_Order").Rows.Count > 0 Then
                    DataGridView1.DataSource = ds.Tables("Food_Order")
                    DataGridView1.Columns.Add(viewButtonCol)
                    DataGridView1.Columns.Add(acceptButtonCol)
                    'DataGridView1.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    DataGridView1.Columns(0).HeaderText = "Order ID"
                    DataGridView1.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    DataGridView1.Columns(0).DefaultCellStyle.SelectionBackColor = Color.White
                    DataGridView1.Columns(0).DefaultCellStyle.SelectionForeColor = Color.Black
                    DataGridView1.Columns(1).HeaderText = "Order Date and Time"
                    DataGridView1.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    DataGridView1.Columns(1).DefaultCellStyle.SelectionBackColor = Color.White
                    DataGridView1.Columns(1).DefaultCellStyle.SelectionForeColor = Color.Black
                    DataGridView1.Columns(2).HeaderText = "Total Items"
                    DataGridView1.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    DataGridView1.Columns(2).DefaultCellStyle.SelectionBackColor = Color.White
                    DataGridView1.Columns(2).DefaultCellStyle.SelectionForeColor = Color.Black
                    DataGridView1.Columns(3).HeaderText = "Placed By"
                    DataGridView1.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    DataGridView1.Columns(3).DefaultCellStyle.SelectionBackColor = Color.White
                    DataGridView1.Columns(3).DefaultCellStyle.SelectionForeColor = Color.Black
                    DataGridView1.Columns(4).HeaderText = "Status"
                    DataGridView1.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    DataGridView1.Columns(4).DefaultCellStyle.SelectionBackColor = Color.White
                    DataGridView1.Columns(4).DefaultCellStyle.SelectionForeColor = Color.Black
                    viewButtonCol.HeaderText = "View Order List"
                    viewButtonCol.Text = "View Order Items"
                    acceptButtonCol.HeaderText = "Accept Orders"
                    acceptButtonCol.Text = "Accept"
                    'buttonCol.BackColor = Color.MediumTurquoise
                    viewButtonCol.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 10, FontStyle.Bold)
                    viewButtonCol.UseColumnTextForButtonValue = True
                    viewButtonCol.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    viewButtonCol.FlatStyle = FlatStyle.Popup
                    viewButtonCol.DefaultCellStyle.BackColor = Color.MediumTurquoise
                    viewButtonCol.DefaultCellStyle.SelectionBackColor = Color.MediumTurquoise
                    viewButtonCol.DefaultCellStyle.SelectionForeColor = Color.Black
                    acceptButtonCol.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 10, FontStyle.Bold)
                    acceptButtonCol.UseColumnTextForButtonValue = True
                    acceptButtonCol.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    acceptButtonCol.FlatStyle = FlatStyle.Popup
                    acceptButtonCol.DefaultCellStyle.BackColor = Color.MediumTurquoise
                    acceptButtonCol.DefaultCellStyle.SelectionBackColor = Color.MediumTurquoise
                    acceptButtonCol.DefaultCellStyle.SelectionForeColor = Color.Black
                    lblOrderToday.Text = ds.Tables("Food_Order").Rows.Count.ToString()
                End If
                EndConnection()
            End If
        End If
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        AsgFrmStaffCurrentOrder.Close()
        AsgFrmStaffCompleteOrder.Close()
        Me.Close()
    End Sub

    Private Sub AsgFrmStaffOrder_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        frmStaffMainPage.Show()
    End Sub
End Class