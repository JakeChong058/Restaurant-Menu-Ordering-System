﻿Imports System.Text.RegularExpressions

Public Class EmailVerification

    Public Function IsEmailValid(email As String) As Boolean

        Dim pattern As String = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"

        Dim regex As New Regex(pattern)
        Dim match As Match = regex.Match(email)

        Return match.Success
    End Function

End Class
