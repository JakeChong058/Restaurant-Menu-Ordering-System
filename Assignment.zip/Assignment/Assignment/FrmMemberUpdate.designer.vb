﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmMemberUpdate
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grpbox1 = New System.Windows.Forms.GroupBox()
        Me.mskIc = New System.Windows.Forms.MaskedTextBox()
        Me.lblICText = New System.Windows.Forms.Label()
        Me.mskPhoneNumber = New System.Windows.Forms.MaskedTextBox()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.lblEmail = New System.Windows.Forms.Label()
        Me.lblPhoneNumber = New System.Windows.Forms.Label()
        Me.lblName = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lbltxtMemberUpdate = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.grpbox1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'grpbox1
        '
        Me.grpbox1.Controls.Add(Me.mskPhoneNumber)
        Me.grpbox1.Controls.Add(Me.btnClear)
        Me.grpbox1.Controls.Add(Me.btnUpdate)
        Me.grpbox1.Controls.Add(Me.txtEmail)
        Me.grpbox1.Controls.Add(Me.txtName)
        Me.grpbox1.Controls.Add(Me.lblEmail)
        Me.grpbox1.Controls.Add(Me.lblPhoneNumber)
        Me.grpbox1.Controls.Add(Me.lblName)
        Me.grpbox1.Location = New System.Drawing.Point(405, 405)
        Me.grpbox1.Name = "grpbox1"
        Me.grpbox1.Size = New System.Drawing.Size(502, 314)
        Me.grpbox1.TabIndex = 10
        Me.grpbox1.TabStop = False
        '
        'mskIc
        '
        Me.mskIc.Font = New System.Drawing.Font("Microsoft PhagsPa", 8.0!)
        Me.mskIc.Location = New System.Drawing.Point(622, 364)
        Me.mskIc.Mask = "000000000000"
        Me.mskIc.Name = "mskIc"
        Me.mskIc.Size = New System.Drawing.Size(184, 35)
        Me.mskIc.TabIndex = 2
        Me.mskIc.ValidatingType = GetType(Date)
        '
        'lblICText
        '
        Me.lblICText.AutoSize = True
        Me.lblICText.Location = New System.Drawing.Point(577, 369)
        Me.lblICText.Name = "lblICText"
        Me.lblICText.Size = New System.Drawing.Size(38, 25)
        Me.lblICText.TabIndex = 12
        Me.lblICText.Text = "IC:"
        '
        'mskPhoneNumber
        '
        Me.mskPhoneNumber.Font = New System.Drawing.Font("Microsoft PhagsPa", 8.0!)
        Me.mskPhoneNumber.Location = New System.Drawing.Point(217, 121)
        Me.mskPhoneNumber.Mask = "0000000000"
        Me.mskPhoneNumber.Name = "mskPhoneNumber"
        Me.mskPhoneNumber.Size = New System.Drawing.Size(184, 35)
        Me.mskPhoneNumber.TabIndex = 3
        Me.mskPhoneNumber.ValidatingType = GetType(Date)
        '
        'btnClear
        '
        Me.btnClear.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnClear.Location = New System.Drawing.Point(109, 234)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(128, 46)
        Me.btnClear.TabIndex = 9
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = False
        '
        'btnUpdate
        '
        Me.btnUpdate.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnUpdate.Location = New System.Drawing.Point(279, 234)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(128, 46)
        Me.btnUpdate.TabIndex = 10
        Me.btnUpdate.Text = "Update"
        Me.btnUpdate.UseVisualStyleBackColor = False
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(217, 164)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(184, 31)
        Me.txtEmail.TabIndex = 4
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(217, 77)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(184, 31)
        Me.txtName.TabIndex = 1
        '
        'lblEmail
        '
        Me.lblEmail.AutoSize = True
        Me.lblEmail.Location = New System.Drawing.Point(139, 165)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(71, 25)
        Me.lblEmail.TabIndex = 2
        Me.lblEmail.Text = "Email:"
        '
        'lblPhoneNumber
        '
        Me.lblPhoneNumber.AutoSize = True
        Me.lblPhoneNumber.Location = New System.Drawing.Point(49, 126)
        Me.lblPhoneNumber.Name = "lblPhoneNumber"
        Me.lblPhoneNumber.Size = New System.Drawing.Size(161, 25)
        Me.lblPhoneNumber.TabIndex = 1
        Me.lblPhoneNumber.Text = "Phone Number:"
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Location = New System.Drawing.Point(136, 80)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(74, 25)
        Me.lblName.TabIndex = 0
        Me.lblName.Text = "Name:"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Assignment.My.Resources.Resources.Island_Cafe_Logo
        Me.PictureBox1.Location = New System.Drawing.Point(505, 25)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(267, 218)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 11
        Me.PictureBox1.TabStop = False
        '
        'lbltxtMemberUpdate
        '
        Me.lbltxtMemberUpdate.AutoSize = True
        Me.lbltxtMemberUpdate.Location = New System.Drawing.Point(428, 290)
        Me.lbltxtMemberUpdate.Name = "lbltxtMemberUpdate"
        Me.lbltxtMemberUpdate.Size = New System.Drawing.Size(429, 25)
        Me.lbltxtMemberUpdate.TabIndex = 13
        Me.lbltxtMemberUpdate.Text = "Input your IC to change the following details"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button1.Location = New System.Drawing.Point(582, 770)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(139, 54)
        Me.Button1.TabIndex = 20
        Me.Button1.Text = "Back"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'FrmMemberUpdate
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(12.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1365, 885)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.lbltxtMemberUpdate)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.grpbox1)
        Me.Controls.Add(Me.mskIc)
        Me.Controls.Add(Me.lblICText)
        Me.Name = "FrmMemberUpdate"
        Me.Text = "FrmMemberUpdate"
        Me.grpbox1.ResumeLayout(False)
        Me.grpbox1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents grpbox1 As GroupBox
    Friend WithEvents mskIc As MaskedTextBox
    Friend WithEvents lblICText As Label
    Friend WithEvents mskPhoneNumber As MaskedTextBox
    Friend WithEvents btnClear As Button
    Friend WithEvents btnUpdate As Button
    Friend WithEvents txtEmail As TextBox
    Friend WithEvents txtName As TextBox
    Friend WithEvents lblEmail As Label
    Friend WithEvents lblPhoneNumber As Label
    Friend WithEvents lblName As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents lbltxtMemberUpdate As Label
    Friend WithEvents Button1 As Button
End Class
