﻿Imports System.Data.SqlClient
Imports System.Text
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class frmViewPromotionReport
    Private da As SqlDataAdapter
    Private ds As DataSet = New DataSet()
    Private intTotal As Integer
    Private decSubtotal As Decimal
    Private intMax As Integer
    Private intMin As Integer
    Private strDate As String
    Private PromotionReport() As CustMenuItems
    Private maxCount As CustMenuItems
    Private minCount As CustMenuItems
    Private currentView As String = ""
    'done
    Friend Sub loadDataGridView(strSql As String)
        'AsgFrmStaffCompleteOrder.Hide()

        strDate = Date.Now

        If StartConnection() = True Then
            ' strSql = frmManageStaff.strSQLAll
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            Try
                da.Fill(ds, "Menu")
            Catch ex As Exception
            End Try

            If ds.Tables("Menu").Rows.Count > 0 Then
                ReDim PromotionReport(ds.Tables("Menu").Rows.Count - 1)
                For intIndex = 0 To PromotionReport.Length - 1 Step 1
                    PromotionReport(intIndex) = New CustMenuItems(ds.Tables("Menu").Rows(intIndex).Item("Menu_Id").ToString(),
                    ds.Tables("Menu").Rows(intIndex).Item("Description").ToString(), ds.Tables("Menu").Rows(intIndex).Item("Discounted_Price"), ds.Tables("Menu").Rows(intIndex).Item("PromotionRate"), ds.Tables("Menu").Rows(intIndex).Item("Order_Count"))
                Next intIndex

                DataGridView1.DataSource = ds.Tables("Menu")
                DataGridView1.Columns(0).HeaderText = "Menu Id"
                DataGridView1.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(0).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(0).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(1).HeaderText = "Description"
                DataGridView1.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(1).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(1).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(2).HeaderText = "Price"
                DataGridView1.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(2).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(2).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(3).HeaderText = "Promotion Rate"
                DataGridView1.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(3).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(3).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(4).HeaderText = "No Of Orders"
                DataGridView1.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(4).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(4).DefaultCellStyle.SelectionForeColor = Color.Black

                intMax = ds.Tables("Menu").Rows(0).Item("Order_Count")
                intMin = ds.Tables("Menu").Rows(ds.Tables("Menu").Rows.Count - 1).Item("Order_Count")
                For intIndex = 0 To ds.Tables("Menu").Rows.Count - 1 Step 1
                    intTotal += ds.Tables("Menu").Rows(intIndex).Item("Order_Count")
                    If ds.Tables("Menu").Rows(intIndex).Item("Order_Count") > intMax Then
                        intMax = ds.Tables("Menu").Rows(intIndex).Item("Order_Count")
                    End If
                    If ds.Tables("Menu").Rows(intIndex).Item("Order_Count") < intMin Then
                        intMin = ds.Tables("Menu").Rows(intIndex).Item("Order_Count")
                    End If
                Next intIndex

                lblCountRecords.Text = ds.Tables("Menu").Rows.Count.ToString() & " item(s)"
                'lblTotalNoOfOrder.Text = intTotal.ToString() & " item(s) ordered"
            End If
            EndConnection()
        End If
        If StartConnection() = True Then
            Dim dataSets As DataSet = New DataSet()
            Dim strSqlMax As String
            strSqlMax = strSql + " AND Order_Count = " & intMax
            da = New SqlDataAdapter(strSqlMax, connection)

            dataSets.Clear()
            Try
                da.Fill(dataSets, "Menu")
            Catch ex As Exception
            End Try
            If dataSets.Tables("Menu").Rows.Count > 0 Then
                maxCount = New CustMenuItems(ds.Tables("Menu").Rows(0).Item("Menu_Id").ToString(),
                    ds.Tables("Menu").Rows(0).Item("Description").ToString(), ds.Tables("Menu").Rows(0).Item("Discounted_Price"), ds.Tables("Menu").Rows(0).Item("PromotionRate"), ds.Tables("Menu").Rows(0).Item("Order_Count"))
                DataGridView2.DataSource = dataSets.Tables("Menu")
                DataGridView2.Columns(0).HeaderText = "Menu ID"
                DataGridView2.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView2.Columns(0).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView2.Columns(0).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView2.Columns(1).HeaderText = "Description"
                DataGridView2.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView2.Columns(1).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView2.Columns(1).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView2.Columns(2).HeaderText = "Price"
                DataGridView2.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView2.Columns(2).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView2.Columns(2).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView2.Columns(3).HeaderText = "Promotion Rate"
                DataGridView2.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView2.Columns(3).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView2.Columns(3).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView2.Columns(4).HeaderText = "No Of Orders"
                DataGridView2.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView2.Columns(4).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView2.Columns(4).DefaultCellStyle.SelectionForeColor = Color.Black
            End If
            EndConnection()
        End If
        If StartConnection() = True Then
            Dim dataSetss As DataSet = New DataSet()
            Dim strSqlMin As String
            strSqlMin = strSql + " AND Order_Count = " & intMin

            da = New SqlDataAdapter(strSqlMin, connection)

            dataSetss.Clear()
            Try
                da.Fill(dataSetss, "Menu")
            Catch ex As Exception
            End Try
            If dataSetss.Tables("Menu").Rows.Count > 0 Then
                minCount = New CustMenuItems(ds.Tables("Menu").Rows(0).Item("Menu_Id").ToString(),
                    ds.Tables("Menu").Rows(0).Item("Description").ToString(), ds.Tables("Menu").Rows(0).Item("Discounted_Price"), ds.Tables("Menu").Rows(0).Item("PromotionRate"), ds.Tables("Menu").Rows(0).Item("Order_Count"))
                DataGridView3.DataSource = dataSetss.Tables("Menu")
                DataGridView3.Columns(0).HeaderText = "Menu ID"
                DataGridView3.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView3.Columns(0).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView3.Columns(0).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView3.Columns(1).HeaderText = "Description"
                DataGridView3.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView3.Columns(1).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView3.Columns(1).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView3.Columns(2).HeaderText = "Price"
                DataGridView3.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView3.Columns(2).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView3.Columns(2).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView3.Columns(3).HeaderText = "Promotion Rate"
                DataGridView3.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView3.Columns(3).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView3.Columns(3).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView3.Columns(4).HeaderText = "No Of Orders"
                DataGridView3.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView3.Columns(4).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView3.Columns(4).DefaultCellStyle.SelectionForeColor = Color.Black
            End If
            EndConnection()
        End If
    End Sub
    'done
    Private Sub mnuFileClose_Click(sender As Object, e As EventArgs) Handles mnuFileClose.Click
        Me.Close()
    End Sub
    'done
    Private Sub AsgFrmOrderReport_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed 'done
        frmGeneratePromotionReport.Show()
        Me.Hide()
    End Sub
    'done
    Private Sub mnuAbout_Click(sender As Object, e As EventArgs) Handles mnuAbout.Click
        MessageBox.Show("Report generated at " & strDate, "About", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Friend Function adjustSpace(mylength As Integer, hislength As Integer)
        Dim strSpace As String = ""
        For intIndex = 1 To hislength - mylength
            strSpace += " "
        Next
        Return strSpace
    End Function
    Private Sub doc_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles doc.PrintPage
        Dim fntHeader As New Font("Calibri", 24, FontStyle.Bold)
        Dim fntSubHeader As New Font("Calibri", 18)
        Dim fntSubHeaderAddress As New Font("Calibri", 14)
        Dim fntBody As New Font("Consolas", 10)
        Dim strHeader As String
        ' (2) Prepare header and sub-header
        If frmGeneratePromotionReport.blnGenerateReport10 = True And frmGeneratePromotionReport.blnGenerateReport20 = False And frmGeneratePromotionReport.blnGenerateReportAll = False Then
            strHeader = " 10% PROMOTION ITEM REPORT" & vbNewLine
        ElseIf frmGeneratePromotionReport.blnGenerateReport10 = False And frmGeneratePromotionReport.blnGenerateReport20 = True And frmGeneratePromotionReport.blnGenerateReportAll = False Then
            strHeader = " 20 % PROMOTION ITEM REPORT" & vbNewLine
        Else
            strHeader = " PROMOTION ITEM REPORT" & vbNewLine
        End If
        Dim strSubHeader As String = " Island Cafe Inc."
        Dim strSubHeaderAddress As String = "Cyber Centre, KL, Main Campus" & vbNewLine & "  Jalan Genting Kelang Setapak"
        ' (3) Prepare body
        Dim body As New StringBuilder()
        body.AppendLine("RECORD:")
        body.AppendLine("------------")
        body.AppendLine()
        body.AppendLine("Menu ID           Description                Price         Promotion Rate    No. Of Orders ")
        body.AppendLine("-------- ------------------------------ -------------- --------------------- -------------")
        'body.AppendLine(8                       30               13              21                   12          )

        For intIndex = 0 To PromotionReport.Length - 1 Step 1
            body.AppendFormat("  {0}   {1}" & adjustSpace(PromotionReport(intIndex).GetStrDescription().ToString().Length(), 30) & adjustSpace(PromotionReport(intIndex).GetDecDiscount().ToString().Length(), 13) & "{2} " & adjustSpace(PromotionReport(intIndex).GetDecPromotionRate(), 16) & "{3} " & adjustSpace(PromotionReport(intIndex).GetIntOrderCount, 12) & "{4}" & vbNewLine, PromotionReport(intIndex).GetStrMenuId.ToString, PromotionReport(intIndex).GetStrDescription.ToString, PromotionReport(intIndex).GetDecDiscount.ToString, PromotionReport(intIndex).GetDecPromotionRate.ToString, PromotionReport(intIndex).GetIntOrderCount.ToString)

        Next intIndex
        body.AppendFormat("{0}", lblCountRecords.Text)
        body.AppendLine()
        body.AppendLine()
        body.AppendLine()
        body.AppendLine()
        body.AppendLine("PROMOTION ITEM WITH THE HIGHEST ORDER COUNT:")
        body.AppendLine("-------------------------------------------")
        body.AppendLine()
        body.AppendLine("Menu ID           Description                Price         Promotion Rate    No. Of Orders ")
        body.AppendLine("-------- ------------------------------ -------------- --------------------- -------------")
        'body.AppendLine(8                       30               13              21                   12          )
        body.AppendFormat("  {0}   {1}" & adjustSpace(maxCount.GetStrDescription().ToString().Length(), 30) & adjustSpace(maxCount.GetDecDiscount().ToString().Length(), 13) & "{2} " & adjustSpace(maxCount.GetDecPromotionRate(), 16) & "{3} " & adjustSpace(maxCount.GetIntOrderCount, 12) & "{4}" & vbNewLine, maxCount.GetStrMenuId.ToString, maxCount.GetStrDescription.ToString, maxCount.GetDecDiscount.ToString, maxCount.GetDecPromotionRate.ToString, maxCount.GetIntOrderCount.ToString)


        body.AppendLine()
        body.AppendLine()
        body.AppendLine()
        body.AppendLine()
        body.AppendLine("PROMOTION ITEM WITH THE LOWEST ORDER COUNT:") 'Order With The Highest Payment Amount
        body.AppendLine("------------------------------------------")
        body.AppendLine()

        body.AppendLine("Menu ID           Description                Price         Promotion Rate    No. Of Orders ")
        body.AppendLine("-------- ------------------------------ -------------- --------------------- -------------")
        'body.AppendLine(8                       30               13              21                   12          )
        body.AppendFormat("  {0}   {1}" & adjustSpace(minCount.GetStrDescription().ToString().Length(), 30) & adjustSpace(minCount.GetDecDiscount().ToString().Length(), 13) & "{2} " & adjustSpace(minCount.GetDecPromotionRate(), 16) & "{3} " & adjustSpace(minCount.GetIntOrderCount, 12) & "{4}" & vbNewLine, minCount.GetStrMenuId.ToString, minCount.GetStrDescription.ToString, minCount.GetDecDiscount.ToString, minCount.GetDecPromotionRate.ToString, minCount.GetIntOrderCount.ToString)



        body.AppendLine()
        body.AppendLine()
        body.AppendLine()
        body.AppendLine()
        body.AppendLine("**************************************************************************************" & vbNewLine & vbNewLine & vbTab & vbTab & vbTab & vbTab & vbTab & " END OF REPORT" & vbNewLine & vbTab & vbTab & vbTab & "     This is a Computer-Generated Report" & vbNewLine & vbNewLine & "**************************************************************************************")
        '-------- --------------------- ----------- ------------------- -------- --------------
        With e.Graphics
            .DrawImage(My.Resources.Island_Cafe_Logo, 250, 0, 165, 180)
            .DrawString(strHeader, fntHeader, Brushes.Blue, 125, 270)
            .DrawString(strSubHeader, fntSubHeader, Brushes.Black, 250, 190)
            .DrawString(strSubHeaderAddress, fntSubHeaderAddress, Brushes.Black, 205, 220)
            .DrawString(body.ToString(), fntBody, Brushes.Black, 0, 360)
        End With
    End Sub
    'done
    Private Sub mnuFilePrint_Click(sender As Object, e As EventArgs) Handles mnuFilePrint.Click
        dlgPreview.Document = doc
        dlgPreview.ShowDialog(Me)
    End Sub

    Private Sub frmManageStaffGenerateReport_Load(sender As Object, e As EventArgs) Handles MyBase.Load, Me.Shown
        FrmPromotion.Hide()
        DataGridView1.Columns.Clear()
        DataGridView1.DataSource = ""
        DataGridView2.Columns.Clear()
        DataGridView2.DataSource = ""
        DataGridView3.Columns.Clear()
        DataGridView3.DataSource = ""
        If frmGeneratePromotionReport.blnGenerateReport10 = True And frmGeneratePromotionReport.blnGenerateReport20 = False And frmGeneratePromotionReport.blnGenerateReportAll = False Then
            currentView = "10"
            lblPromotionReport.Text = "10% PROMOTION REPORT"
            loadDataGridView(FrmPromotion.strSQL10)
        ElseIf frmGeneratePromotionReport.blnGenerateReport10 = False And frmGeneratePromotionReport.blnGenerateReport20 = True And frmGeneratePromotionReport.blnGenerateReportAll = False Then
            currentView = "20"
            lblPromotionReport.Text = "20% PROMOTION REPORT"
            loadDataGridView(FrmPromotion.strSQL20)
        ElseIf frmGeneratePromotionReport.blnGenerateReport10 = False And frmGeneratePromotionReport.blnGenerateReport20 = False And frmGeneratePromotionReport.blnGenerateReportAll = True Then
            currentView = "All"
            lblPromotionReport.Text = "PROMOTION REPORT"
            loadDataGridView(FrmPromotion.strSQLAll)
        End If
    End Sub
End Class