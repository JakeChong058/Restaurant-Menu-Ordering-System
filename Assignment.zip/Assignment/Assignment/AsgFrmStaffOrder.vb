﻿Imports System.Data.SqlClient
Imports System.Security.Cryptography
Imports System.Windows.Forms.VisualStyles.VisualStyleElement.Menu

Public Class AsgFrmStaffOrder
    Private da As SqlDataAdapter
    Private ds As DataSet = New DataSet()

    Friend menuItem() As StaffMenuItems
    'Private button(7) As Button
    Private picture() As PictureBox
    Private labels() As Label
    Private noLabel() As Label
    Private table() As TableLayoutPanel
    Private tables() As TableLayoutPanel
    Private intRecords As Integer
    Friend blnNotFirstVisit As Boolean = False

    Private Sub mnuDessert_Click(sender As Object, e As EventArgs) Handles mnuDesserts.Click
        TableLayoutPanel1.Controls.Clear()
        Dim inCount As Integer = 0
        Dim strSql As String
        lblTitle.Text = "DESSERTS"
        If StartConnection() = True Then
            strSql = "Select * From Menu Where Category = 'Desserts'"
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            da.Fill(ds, "Menu")
            ReDim menuItem(ds.Tables("Menu").Rows.Count - 1)
            ReDim picture(ds.Tables("Menu").Rows.Count - 1)
            ReDim labels(ds.Tables("Menu").Rows.Count - 1)
            ReDim noLabel(ds.Tables("Menu").Rows.Count - 1)
            ReDim table(ds.Tables("Menu").Rows.Count - 1)
            ReDim tables(ds.Tables("Menu").Rows.Count - 1)
            If ds.Tables("Menu").Rows.Count < 4 Then
                TableLayoutPanel1.RowCount = 1
            ElseIf ds.Tables("Menu").Rows.Count Mod 4 <> 0 Then
                TableLayoutPanel1.RowCount = (ds.Tables("Menu").Rows.Count \ 4) + 1
            Else
                TableLayoutPanel1.RowCount = ds.Tables("Menu").Rows.Count \ 4
            End If
            Console.WriteLine(TableLayoutPanel1.RowCount)
            TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 280))
            TableLayoutPanel1.Height = 280 * TableLayoutPanel1.RowCount
            intRecords = ds.Tables("Menu").Rows.Count
            If ds.Tables("Menu").Rows.Count > 0 Then
                CreateControls()
                AddControls()
            End If
            EndConnection()
        Else
            MessageBox.Show("Error in connecting to database server", "Error", MessageBoxButtons.OK)
        End If
    End Sub

    Private Sub mnuFood_Click(sender As Object, e As EventArgs) Handles mnuFood.Click
        TableLayoutPanel1.Controls.Clear()
        Dim inCount As Integer = 0
        Dim strSql As String
        lblTitle.Text = "FOODS"
        If StartConnection() = True Then
            strSql = "Select * From Menu Where Category = 'Food'"
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            da.Fill(ds, "Menu")
            ReDim menuItem(ds.Tables("Menu").Rows.Count - 1)
            ReDim picture(ds.Tables("Menu").Rows.Count - 1)
            ReDim labels(ds.Tables("Menu").Rows.Count - 1)
            ReDim noLabel(ds.Tables("Menu").Rows.Count - 1)
            ReDim table(ds.Tables("Menu").Rows.Count - 1)
            ReDim tables(ds.Tables("Menu").Rows.Count - 1)
            If ds.Tables("Menu").Rows.Count < 4 Then
                TableLayoutPanel1.RowCount = 1
            ElseIf ds.Tables("Menu").Rows.Count Mod 4 <> 0 Then
                TableLayoutPanel1.RowCount = (ds.Tables("Menu").Rows.Count \ 4) + 1
            Else
                TableLayoutPanel1.RowCount = ds.Tables("Menu").Rows.Count \ 4
            End If
            Console.WriteLine(TableLayoutPanel1.RowCount)
            TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 280))
            TableLayoutPanel1.Height = 280 * TableLayoutPanel1.RowCount
            intRecords = ds.Tables("Menu").Rows.Count
            If ds.Tables("Menu").Rows.Count > 0 Then
                CreateControls()
                AddControls()
            End If
            EndConnection()
        Else
            MessageBox.Show("Error in connecting to database server", "Error", MessageBoxButtons.OK)
        End If
    End Sub

    Private Sub mnuFoodWestern_Click(sender As Object, e As EventArgs) Handles mnuFoodWestern.Click
        TableLayoutPanel1.Controls.Clear()
        Dim inCount As Integer = 0
        Dim strSql As String
        lblTitle.Text = "WESTERN"
        If StartConnection() = True Then
            strSql = "Select * From Menu Where SubCategory = 'Western'"
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            da.Fill(ds, "Menu")
            ReDim menuItem(ds.Tables("Menu").Rows.Count - 1)
            ReDim picture(ds.Tables("Menu").Rows.Count - 1)
            ReDim labels(ds.Tables("Menu").Rows.Count - 1)
            ReDim noLabel(ds.Tables("Menu").Rows.Count - 1)
            ReDim table(ds.Tables("Menu").Rows.Count - 1)
            ReDim tables(ds.Tables("Menu").Rows.Count - 1)
            If ds.Tables("Menu").Rows.Count < 4 Then
                TableLayoutPanel1.RowCount = 1
            ElseIf ds.Tables("Menu").Rows.Count Mod 4 <> 0 Then
                TableLayoutPanel1.RowCount = (ds.Tables("Menu").Rows.Count \ 4) + 1
            Else
                TableLayoutPanel1.RowCount = ds.Tables("Menu").Rows.Count \ 4
            End If
            Console.WriteLine(TableLayoutPanel1.RowCount)
            TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 280))
            TableLayoutPanel1.Height = 280 * TableLayoutPanel1.RowCount
            intRecords = ds.Tables("Menu").Rows.Count
            If ds.Tables("Menu").Rows.Count > 0 Then
                CreateControls()
                AddControls()
            End If
            EndConnection()
        Else
            MessageBox.Show("Error in connecting to database server", "Error", MessageBoxButtons.OK)
        End If
    End Sub

    Private Sub mnuFoodChicken_Click(sender As Object, e As EventArgs) Handles mnuFoodChicken.Click
        TableLayoutPanel1.Controls.Clear()
        Dim inCount As Integer = 0
        Dim strSql As String
        lblTitle.Text = "CHICKEN"
        If StartConnection() = True Then
            strSql = "Select * From Menu Where SubCategory = 'Chicken'"
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            da.Fill(ds, "Menu")
            ReDim menuItem(ds.Tables("Menu").Rows.Count - 1)
            ReDim picture(ds.Tables("Menu").Rows.Count - 1)
            ReDim labels(ds.Tables("Menu").Rows.Count - 1)
            ReDim noLabel(ds.Tables("Menu").Rows.Count - 1)
            ReDim table(ds.Tables("Menu").Rows.Count - 1)
            ReDim tables(ds.Tables("Menu").Rows.Count - 1)
            If ds.Tables("Menu").Rows.Count < 4 Then
                TableLayoutPanel1.RowCount = 1
            ElseIf ds.Tables("Menu").Rows.Count Mod 4 <> 0 Then
                TableLayoutPanel1.RowCount = (ds.Tables("Menu").Rows.Count \ 4) + 1
            Else
                TableLayoutPanel1.RowCount = ds.Tables("Menu").Rows.Count \ 4
            End If
            Console.WriteLine(TableLayoutPanel1.RowCount)
            TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 280))
            TableLayoutPanel1.Height = 280 * TableLayoutPanel1.RowCount
            intRecords = ds.Tables("Menu").Rows.Count
            If ds.Tables("Menu").Rows.Count > 0 Then
                CreateControls()
                AddControls()
            End If
            EndConnection()
        Else
            MessageBox.Show("Error in connecting to database server", "Error", MessageBoxButtons.OK)
        End If
    End Sub

    Private Sub mnuFoodSalad_Click(sender As Object, e As EventArgs) Handles mnuFoodSalad.Click
        TableLayoutPanel1.Controls.Clear()
        Dim inCount As Integer = 0
        Dim strSql As String
        lblTitle.Text = "SALAD AND SOUP"
        If StartConnection() = True Then
            strSql = "Select * From Menu Where SubCategory = 'Salad and Soup'"
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            da.Fill(ds, "Menu")
            ReDim menuItem(ds.Tables("Menu").Rows.Count - 1)
            ReDim picture(ds.Tables("Menu").Rows.Count - 1)
            ReDim labels(ds.Tables("Menu").Rows.Count - 1)
            ReDim noLabel(ds.Tables("Menu").Rows.Count - 1)
            ReDim table(ds.Tables("Menu").Rows.Count - 1)
            ReDim tables(ds.Tables("Menu").Rows.Count - 1)
            If ds.Tables("Menu").Rows.Count < 4 Then
                TableLayoutPanel1.RowCount = 1
            ElseIf ds.Tables("Menu").Rows.Count Mod 4 <> 0 Then
                TableLayoutPanel1.RowCount = (ds.Tables("Menu").Rows.Count \ 4) + 1
            Else
                TableLayoutPanel1.RowCount = ds.Tables("Menu").Rows.Count \ 4
            End If
            Console.WriteLine(TableLayoutPanel1.RowCount)
            TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 280))
            TableLayoutPanel1.Height = 280 * TableLayoutPanel1.RowCount
            intRecords = ds.Tables("Menu").Rows.Count
            If ds.Tables("Menu").Rows.Count > 0 Then
                CreateControls()
                AddControls()
            End If
            EndConnection()
        Else
            MessageBox.Show("Error in connecting to database server", "Error", MessageBoxButtons.OK)
        End If
    End Sub

    Private Sub mnuDessertPudding_Click(sender As Object, e As EventArgs) Handles mnuDessertPudding.Click
        TableLayoutPanel1.Controls.Clear()
        Dim inCount As Integer = 0
        Dim strSql As String
        lblTitle.Text = "PUDDING"
        If StartConnection() = True Then
            strSql = "Select * From Menu Where SubCategory = 'Pudding'"
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            da.Fill(ds, "Menu")
            ReDim menuItem(ds.Tables("Menu").Rows.Count - 1)
            ReDim picture(ds.Tables("Menu").Rows.Count - 1)
            ReDim labels(ds.Tables("Menu").Rows.Count - 1)
            ReDim noLabel(ds.Tables("Menu").Rows.Count - 1)
            ReDim table(ds.Tables("Menu").Rows.Count - 1)
            ReDim tables(ds.Tables("Menu").Rows.Count - 1)
            If ds.Tables("Menu").Rows.Count < 4 Then
                TableLayoutPanel1.RowCount = 1
            ElseIf ds.Tables("Menu").Rows.Count Mod 4 <> 0 Then
                TableLayoutPanel1.RowCount = (ds.Tables("Menu").Rows.Count \ 4) + 1
            Else
                TableLayoutPanel1.RowCount = ds.Tables("Menu").Rows.Count \ 4
            End If
            Console.WriteLine(TableLayoutPanel1.RowCount)
            TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 280))
            TableLayoutPanel1.Height = 280 * TableLayoutPanel1.RowCount
            intRecords = ds.Tables("Menu").Rows.Count
            If ds.Tables("Menu").Rows.Count > 0 Then
                CreateControls()
                AddControls()
            End If
            EndConnection()
        Else
            MessageBox.Show("Error in connecting to database server", "Error", MessageBoxButtons.OK)
        End If
    End Sub

    Private Sub mnuDessertIceCream_Click(sender As Object, e As EventArgs) Handles mnuDessertIceCream.Click
        TableLayoutPanel1.Controls.Clear()
        Dim inCount As Integer = 0
        Dim strSql As String
        lblTitle.Text = "ICE CREAM"
        If StartConnection() = True Then
            strSql = "Select * From Menu Where SubCategory = 'Ice Cream'"
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            da.Fill(ds, "Menu")
            ReDim menuItem(ds.Tables("Menu").Rows.Count - 1)
            ReDim picture(ds.Tables("Menu").Rows.Count - 1)
            ReDim labels(ds.Tables("Menu").Rows.Count - 1)
            ReDim noLabel(ds.Tables("Menu").Rows.Count - 1)
            ReDim table(ds.Tables("Menu").Rows.Count - 1)
            ReDim tables(ds.Tables("Menu").Rows.Count - 1)
            If ds.Tables("Menu").Rows.Count < 4 Then
                TableLayoutPanel1.RowCount = 1
            ElseIf ds.Tables("Menu").Rows.Count Mod 4 <> 0 Then
                TableLayoutPanel1.RowCount = (ds.Tables("Menu").Rows.Count \ 4) + 1
            Else
                TableLayoutPanel1.RowCount = ds.Tables("Menu").Rows.Count \ 4
            End If
            Console.WriteLine(TableLayoutPanel1.RowCount)
            TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 280))
            TableLayoutPanel1.Height = 280 * TableLayoutPanel1.RowCount
            intRecords = ds.Tables("Menu").Rows.Count
            If ds.Tables("Menu").Rows.Count > 0 Then
                CreateControls()
                AddControls()
            End If
            EndConnection()
        Else
            MessageBox.Show("Error in connecting to database server", "Error", MessageBoxButtons.OK)
        End If
    End Sub

    Private Sub mnuDessertCake_Click(sender As Object, e As EventArgs) Handles mnuDessertCake.Click
        TableLayoutPanel1.Controls.Clear()
        Dim inCount As Integer = 0
        Dim strSql As String
        lblTitle.Text = "CAKE"
        If StartConnection() = True Then
            strSql = "Select * From Menu Where SubCategory = 'Cake'"
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            da.Fill(ds, "Menu")
            ReDim menuItem(ds.Tables("Menu").Rows.Count - 1)
            ReDim picture(ds.Tables("Menu").Rows.Count - 1)
            ReDim labels(ds.Tables("Menu").Rows.Count - 1)
            ReDim noLabel(ds.Tables("Menu").Rows.Count - 1)
            ReDim table(ds.Tables("Menu").Rows.Count - 1)
            ReDim tables(ds.Tables("Menu").Rows.Count - 1)
            If ds.Tables("Menu").Rows.Count < 4 Then
                TableLayoutPanel1.RowCount = 1
            ElseIf ds.Tables("Menu").Rows.Count Mod 4 <> 0 Then
                TableLayoutPanel1.RowCount = (ds.Tables("Menu").Rows.Count \ 4) + 1
            Else
                TableLayoutPanel1.RowCount = ds.Tables("Menu").Rows.Count \ 4
            End If
            Console.WriteLine(TableLayoutPanel1.RowCount)
            TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 280))
            TableLayoutPanel1.Height = 280 * TableLayoutPanel1.RowCount
            intRecords = ds.Tables("Menu").Rows.Count
            If ds.Tables("Menu").Rows.Count > 0 Then
                CreateControls()
                AddControls()
            End If
            EndConnection()
        Else
            MessageBox.Show("Error in connecting to database server", "Error", MessageBoxButtons.OK)
        End If
    End Sub

    Private Sub mnuBeverages_Click(sender As Object, e As EventArgs) Handles mnuBeverages.Click
        TableLayoutPanel1.Controls.Clear()
        Dim inCount As Integer = 0
        Dim strSql As String
        lblTitle.Text = "BEVERAGES"
        If StartConnection() = True Then
            strSql = "Select * From Menu Where Category = 'Beverages'"
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            da.Fill(ds, "Menu")
            ReDim menuItem(ds.Tables("Menu").Rows.Count - 1)
            ReDim picture(ds.Tables("Menu").Rows.Count - 1)
            ReDim labels(ds.Tables("Menu").Rows.Count - 1)
            ReDim noLabel(ds.Tables("Menu").Rows.Count - 1)
            ReDim table(ds.Tables("Menu").Rows.Count - 1)
            ReDim tables(ds.Tables("Menu").Rows.Count - 1)
            If ds.Tables("Menu").Rows.Count < 4 Then
                TableLayoutPanel1.RowCount = 1
            ElseIf ds.Tables("Menu").Rows.Count Mod 4 <> 0 Then
                TableLayoutPanel1.RowCount = (ds.Tables("Menu").Rows.Count \ 4) + 1
            Else
                TableLayoutPanel1.RowCount = ds.Tables("Menu").Rows.Count \ 4
            End If
            Console.WriteLine(TableLayoutPanel1.RowCount)
            TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 280))
            TableLayoutPanel1.Height = 280 * TableLayoutPanel1.RowCount
            intRecords = ds.Tables("Menu").Rows.Count
            If ds.Tables("Menu").Rows.Count > 0 Then
                CreateControls()
                AddControls()
            End If
            EndConnection()
        Else
            MessageBox.Show("Error in connecting to database server", "Error", MessageBoxButtons.OK)
        End If
    End Sub

    Private Sub mnuBeveragesCoffee_Click(sender As Object, e As EventArgs) Handles mnuBeveragesCoffee.Click
        TableLayoutPanel1.Controls.Clear()
        Dim inCount As Integer = 0
        Dim strSql As String
        lblTitle.Text = "COFFEE"
        If StartConnection() = True Then
            strSql = "Select * From Menu Where SubCategory = 'Coffee'"
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            da.Fill(ds, "Menu")
            ReDim menuItem(ds.Tables("Menu").Rows.Count - 1)
            ReDim picture(ds.Tables("Menu").Rows.Count - 1)
            ReDim labels(ds.Tables("Menu").Rows.Count - 1)
            ReDim noLabel(ds.Tables("Menu").Rows.Count - 1)
            ReDim table(ds.Tables("Menu").Rows.Count - 1)
            ReDim tables(ds.Tables("Menu").Rows.Count - 1)
            If ds.Tables("Menu").Rows.Count < 4 Then
                TableLayoutPanel1.RowCount = 1
            ElseIf ds.Tables("Menu").Rows.Count Mod 4 <> 0 Then
                TableLayoutPanel1.RowCount = (ds.Tables("Menu").Rows.Count \ 4) + 1
            Else
                TableLayoutPanel1.RowCount = ds.Tables("Menu").Rows.Count \ 4
            End If
            Console.WriteLine(TableLayoutPanel1.RowCount)
            TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 280))
            TableLayoutPanel1.Height = 280 * TableLayoutPanel1.RowCount
            intRecords = ds.Tables("Menu").Rows.Count
            If ds.Tables("Menu").Rows.Count > 0 Then
                CreateControls()
                AddControls()
            End If
            EndConnection()
        Else
            MessageBox.Show("Error in connecting to database server", "Error", MessageBoxButtons.OK)
        End If
    End Sub

    Private Sub mnuBeveragesTea_Click(sender As Object, e As EventArgs) Handles mnuBeveragesTea.Click
        TableLayoutPanel1.Controls.Clear()
        Dim inCount As Integer = 0
        Dim strSql As String
        lblTitle.Text = "TEA"
        If StartConnection() = True Then
            strSql = "Select * From Menu Where SubCategory = 'Tea'"
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            da.Fill(ds, "Menu")
            ReDim menuItem(ds.Tables("Menu").Rows.Count - 1)
            ReDim picture(ds.Tables("Menu").Rows.Count - 1)
            ReDim labels(ds.Tables("Menu").Rows.Count - 1)
            ReDim noLabel(ds.Tables("Menu").Rows.Count - 1)
            ReDim table(ds.Tables("Menu").Rows.Count - 1)
            ReDim tables(ds.Tables("Menu").Rows.Count - 1)
            If ds.Tables("Menu").Rows.Count < 4 Then
                TableLayoutPanel1.RowCount = 1
            ElseIf ds.Tables("Menu").Rows.Count Mod 4 <> 0 Then
                TableLayoutPanel1.RowCount = (ds.Tables("Menu").Rows.Count \ 4) + 1
            Else
                TableLayoutPanel1.RowCount = ds.Tables("Menu").Rows.Count \ 4
            End If
            Console.WriteLine(TableLayoutPanel1.RowCount)
            TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 280))
            TableLayoutPanel1.Height = 280 * TableLayoutPanel1.RowCount
            intRecords = ds.Tables("Menu").Rows.Count
            If ds.Tables("Menu").Rows.Count > 0 Then
                CreateControls()
                AddControls()
            End If
            EndConnection()
        Else
            MessageBox.Show("Error in connecting to database server", "Error", MessageBoxButtons.OK)
        End If
    End Sub

    Private Sub mnuBeveragesIced_Click(sender As Object, e As EventArgs) Handles mnuBeveragesIced.Click
        TableLayoutPanel1.Controls.Clear()
        Dim inCount As Integer = 0
        Dim strSql As String
        lblTitle.Text = "ICED BEVERAGES"
        If StartConnection() = True Then
            strSql = "Select * From Menu Where SubCategory = 'Iced'"
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            da.Fill(ds, "Menu")
            ReDim menuItem(ds.Tables("Menu").Rows.Count - 1)
            ReDim picture(ds.Tables("Menu").Rows.Count - 1)
            ReDim labels(ds.Tables("Menu").Rows.Count - 1)
            ReDim noLabel(ds.Tables("Menu").Rows.Count - 1)
            ReDim table(ds.Tables("Menu").Rows.Count - 1)
            ReDim tables(ds.Tables("Menu").Rows.Count - 1)
            If ds.Tables("Menu").Rows.Count < 4 Then
                TableLayoutPanel1.RowCount = 1
            ElseIf ds.Tables("Menu").Rows.Count Mod 4 <> 0 Then
                TableLayoutPanel1.RowCount = (ds.Tables("Menu").Rows.Count \ 4) + 1
            Else
                TableLayoutPanel1.RowCount = ds.Tables("Menu").Rows.Count \ 4
            End If
            Console.WriteLine(TableLayoutPanel1.RowCount)
            TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 280))
            TableLayoutPanel1.Height = 280 * TableLayoutPanel1.RowCount
            intRecords = ds.Tables("Menu").Rows.Count
            If ds.Tables("Menu").Rows.Count > 0 Then
                CreateControls()
                AddControls()
            End If
            EndConnection()
        Else
            MessageBox.Show("Error in connecting to database server", "Error", MessageBoxButtons.OK)
        End If
    End Sub

    Private Sub AddControls()
        Dim intCol As Integer = menuItem.Length
        Dim intCount As Integer = 0
        Do While intCol <> 0
            TableLayoutPanel1.Controls.Add(table(intCount))
            table(intCount).Controls.Add(picture(intCount))
            table(intCount).Controls.Add(labels(intCount))
            table(intCount).Controls.Add(tables(intCount))
            tables(intCount).Controls.Add(menuItem(intCount).GetEditButton())
            tables(intCount).Controls.Add(menuItem(intCount).GetDeleteButton())
            TableLayoutPanel1.Controls.Add(noLabel(intCount))
            intCol -= 1
            intCount += 1
        Loop
    End Sub

    Private Sub CreateControls()
        Dim intIndex As Integer
        For intIndex = 0 To menuItem.Length - 1 Step 1

            'menuItem(intIndex) = New StaffMenuItems("Label " & intIndex + 1, 17.44)
            menuItem(intIndex) = New StaffMenuItems(ds.Tables("Menu").Rows(intIndex).Item(0),
            ds.Tables("Menu").Rows(intIndex).Item(1), ds.Tables("Menu").Rows(intIndex).Item(2),
            ds.Tables("Menu").Rows(intIndex).Item(3), ds.Tables("Menu").Rows(intIndex).Item(4),
            ds.Tables("Menu").Rows(intIndex).Item(5), ds.Tables("Menu").Rows(intIndex).Item(6),
            ds.Tables("Menu").Rows(intIndex).Item(7), ds.Tables("Menu").Rows(intIndex).Item(8))
            AddHandler menuItem(intIndex).GetEditButton().Click, AddressOf btnEdit_Click
            AddHandler menuItem(intIndex).GetDeleteButton().Click, AddressOf btnAvailable_Click
            picture(intIndex) = New PictureBox()
            'picture(intIndex).Width = 150
            'picture(intIndex).Height = 150
            picture(intIndex).Dock = DockStyle.Fill
            picture(intIndex).SizeMode = PictureBoxSizeMode.StretchImage
            labels(intIndex) = New Label()
            'label(intIndex).Text = "Label " & intIndex + 1
            labels(intIndex).Text = menuItem(intIndex).GetStrMenuId() & " " & menuItem(intIndex).GetStrDescription() & vbNewLine & menuItem(intIndex).GetDecPrice().ToString("C")
            labels(intIndex).TextAlign = ContentAlignment.MiddleCenter
            'label(intIndex).Width = 150
            'label(intIndex).Height = 80
            labels(intIndex).Dock = DockStyle.Fill
            labels(intIndex).TextAlign = ContentAlignment.MiddleCenter
            noLabel(intIndex) = New Label()
            picture(intIndex).Image = Image.FromFile("Images\" & menuItem(intIndex).GetStrImage())
            table(intIndex) = New TableLayoutPanel()
            table(intIndex).Width = 274
            table(intIndex).Height = 418
            table(intIndex).ColumnCount = 1
            table(intIndex).RowCount = 3
            table(intIndex).RowStyles.Add(New RowStyle(SizeType.Absolute, 150))
            table(intIndex).RowStyles.Add(New RowStyle(SizeType.Absolute, 80))
            table(intIndex).RowStyles.Add(New RowStyle(SizeType.Absolute, 20))
            tables(intIndex) = New TableLayoutPanel()
            tables(intIndex).RowCount = 1
            tables(intIndex).ColumnCount = 2
            tables(intIndex).Width = 180
            tables(intIndex).Height = 40
            tables(intIndex).ColumnStyles.Add(New ColumnStyle(SizeType.Absolute, 90))
            tables(intIndex).ColumnStyles.Add(New ColumnStyle(SizeType.Absolute, 90))

        Next intIndex
    End Sub

    Friend Sub AsgFrmStaffOrder_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        blnNotFirstVisit = True
        TableLayoutPanel1.Controls.Clear()
        Dim inCount As Integer = 0
        Dim strSql As String
        lblTitle.Text = "ALL ITEMS"
        If StartConnection() = True Then
            strSql = "Select * From Menu"
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            da.Fill(ds, "Menu")
            ReDim menuItem(ds.Tables("Menu").Rows.Count - 1)
            ReDim picture(ds.Tables("Menu").Rows.Count - 1)
            ReDim labels(ds.Tables("Menu").Rows.Count - 1)
            ReDim noLabel(ds.Tables("Menu").Rows.Count - 1)
            ReDim table(ds.Tables("Menu").Rows.Count - 1)
            ReDim tables(ds.Tables("Menu").Rows.Count - 1)
            If ds.Tables("Menu").Rows.Count < 4 Then
                TableLayoutPanel1.RowCount = 1
            ElseIf ds.Tables("Menu").Rows.Count Mod 4 <> 0 Then
                TableLayoutPanel1.RowCount = (ds.Tables("Menu").Rows.Count \ 4) + 1
            Else
                TableLayoutPanel1.RowCount = ds.Tables("Menu").Rows.Count \ 4
            End If
            Console.WriteLine(TableLayoutPanel1.RowCount)
            TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 280))
            TableLayoutPanel1.Height = 280 * TableLayoutPanel1.RowCount
            intRecords = ds.Tables("Menu").Rows.Count
            If ds.Tables("Menu").Rows.Count > 0 Then
                CreateControls()
                AddControls()
            End If
            EndConnection()
        Else
            MessageBox.Show("Error in connecting to database server", "Error", MessageBoxButtons.OK)
        End If
        'blnNotFirstVisit = False
    End Sub

    'Private Sub btnCart_Click(sender As Object, e As EventArgs) Handles btnCart.Click
    '    Me.Hide()
    '    TestCart.TestCart_Load(Nothing, Nothing)
    '    TestCart.Show()
    'End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        Dim intNumber As Integer
        For intNumber = 0 To menuItem.Length - 1 Step 1
            If sender Is menuItem(intNumber).GetEditButton() Then
                AsgFrmUpadate.strMenu = menuItem(intNumber).GetStrMenuId()
                Me.Hide()
                AsgFrmUpadate.Show()
                'MessageBox.Show(menuItem(intNumber).GetStrDescription() & " Edit Button is clicked")
            End If
        Next intNumber
    End Sub

    Private Sub btnAddItem_Click(sender As Object, e As EventArgs) Handles btnAddItem.Click
        Me.Hide()
        AsgFrmUpadate.IsAdd()
        AsgFrmUpadate.Show()
        'AsgFrmCustCart.AsgFrmCustCart_Load(Nothing, Nothing)
        'AsgFrmCustCart.Show()
    End Sub


    Private Sub AsgFrmCustOrder_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        End
    End Sub



    Private Sub btnAvailable_Click(sender As Object, e As EventArgs) Handles btnAvailable.Click
        Dim intNumber As Integer
        Dim strSql As String
        Dim dlgSelection As DialogResult
        Dim MSSqlCommand As New SqlCommand

        For intNumber = 0 To menuItem.Length - 1 Step 1
            'Console.WriteLine(sender)
            If sender Is menuItem(intNumber).GetDeleteButton() Then
                If menuItem(intNumber).GetStrAvailability() = "Available" Then
                    dlgSelection = MessageBox.Show("Set " & menuItem(intNumber).GetStrDescription() & " To Not Available?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    If dlgSelection = DialogResult.Yes Then
                        Me.Hide()
                        AsgFrmStaffUpdate.strMenuId = menuItem(intNumber).GetStrMenuId()
                        AsgFrmStaffUpdate.Show()
                        'If StartConnection() = True Then
                        '    strSql = "Update Menu Set Availability = @Availability Where Menu_Id = @Menu_Id"
                        '    MSSqlCommand = New SqlCommand(strSql, connection)
                        '    MSSqlCommand.Parameters.AddWithValue("@Availability", "Not Available")

                        '    MSSqlCommand.Parameters.AddWithValue("@Menu_Id", menuItem(intNumber).GetStrMenuId())
                        '    MSSqlCommand.ExecuteNonQuery()
                        '    EndConnection()
                        '    'menuItem(intNumber).GetDeleteButton().BackgroundImage = My.Resources.delete_icon
                        '    MessageBox.Show(menuItem(intNumber).GetStrDescription() & " is set to Not Available now.", "Menu Availability Changed", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        '    menuItem(intNumber).GetDeleteButton().BackgroundImage = My.Resources.delete_icon
                        '    TableLayoutPanel1.Controls.Clear()
                        '    TableLayoutPanel1.RowCount = 1
                        '    AsgFrmStaffOrder_Load(Nothing, Nothing)
                        'End If


                    End If
                Else

                    dlgSelection = MessageBox.Show("Set " & menuItem(intNumber).GetStrDescription() & " To Available?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                    If dlgSelection = DialogResult.Yes Then
                        If StartConnection() = True Then
                            strSql = "Update Menu set Reason = @Reason, Availability = @Availability Where Menu_Id = @Menu_Id"
                            MSSqlCommand = New SqlCommand(strSql, connection)
                            MSSqlCommand.Parameters.AddWithValue("@Reason", "")
                            MSSqlCommand.Parameters.AddWithValue("@Availability", "Available")
                            MSSqlCommand.Parameters.AddWithValue("@Menu_Id", menuItem(intNumber).GetStrMenuId)
                            MSSqlCommand.ExecuteNonQuery()
                            EndConnection()
                            '    If StartConnection() = True Then
                            '        strSql = "Update Menu Set Availability = @Availability Where Menu_Id = @Menu_Id"
                            '        MSSqlCommand = New SqlCommand(strSql, connection)
                            '        MSSqlCommand.Parameters.AddWithValue("@Availability", "Available")

                            '        MSSqlCommand.Parameters.AddWithValue("@Menu_Id", menuItem(intNumber).GetStrMenuId())
                            '        MSSqlCommand.ExecuteNonQuery()
                            '        EndConnection()
                            menuItem(intNumber).GetDeleteButton().BackgroundImage = My.Resources.Available
                            MessageBox.Show(menuItem(intNumber).GetStrDescription() & " is set to Available now.", "Menu Availability Changed", MessageBoxButtons.OK, MessageBoxIcon.Information)
                            TableLayoutPanel1.Controls.Clear()
                            TableLayoutPanel1.RowCount = 1
                            AsgFrmStaffOrder_Load(Nothing, Nothing)
                            '    End If
                        End If

                    End If



                End If

                'MessageBox.Show(menuItem(intNumber).GetStrDescription() & " Delete Button is clicked")

            End If
        Next intNumber
    End Sub

    Private Sub txtSearch_TextChanged(sender As Object, e As EventArgs) Handles txtSearch.TextChanged
        If txtSearch.Text.Trim() = "" Then
            AsgFrmStaffOrder_Load(Nothing, Nothing)
        Else
            TableLayoutPanel1.Controls.Clear()
            Dim intCount As Integer = 0
            Dim strSql As String
            'txtSearch.Text = "Search items here..."
            'txtSearch.ForeColor = SystemColors.ControlLight
            If StartConnection() = True Then
                strSql = "Select * From Menu Where Menu_Id LIKE '%" & txtSearch.Text.Trim() & "' OR Description LIKE '%" & txtSearch.Text.Trim() & "%' OR Price LIKE '%" & txtSearch.Text.Trim() & "%' OR Category LIKE '%" & txtSearch.Text.Trim() & "%' OR SubCategory LIKE '%" & txtSearch.Text.Trim() & "%'"
                da = New SqlDataAdapter(strSql, connection)
                ds.Clear()
                da.Fill(ds, "Menu")
                ReDim menuItem(ds.Tables("Menu").Rows.Count - 1)
                ReDim picture(ds.Tables("Menu").Rows.Count - 1)
                ReDim labels(ds.Tables("Menu").Rows.Count - 1)
                ReDim noLabel(ds.Tables("Menu").Rows.Count - 1)
                ReDim table(ds.Tables("Menu").Rows.Count - 1)
                'Console.WriteLine((ds.Tables("Menu").Rows.Count + 1) \ 4)
                If ds.Tables("Menu").Rows.Count < 4 Then
                    TableLayoutPanel1.RowCount = 1
                ElseIf ds.Tables("Menu").Rows.Count Mod 4 <> 0 Then
                    TableLayoutPanel1.RowCount = (ds.Tables("Menu").Rows.Count \ 4) + 1
                Else
                    TableLayoutPanel1.RowCount = ds.Tables("Menu").Rows.Count \ 4
                End If
                'TableLayoutPanel1.RowCount = ds.Tables("Menu").Rows.Count
                'TableLayoutPanel1.Height = 35 * TableLayoutPanel1.RowCount
                TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 280))
                'Next intIndex
                TableLayoutPanel1.Height = 280 * TableLayoutPanel1.RowCount
                'TableLayoutPanel1.RowStyles.Clear()

                intRecords = ds.Tables("Menu").Rows.Count
                'Row.Cells[2].Tag = nm
                If ds.Tables("Menu").Rows.Count > 0 Then
                    CreateControls()
                    AddControls()
                End If
                EndConnection()
            Else
                MessageBox.Show("Error in connecting to database server", "Error", MessageBoxButtons.OK)
            End If
        End If
    End Sub

    Private Sub mnuAll_Click(sender As Object, e As EventArgs) Handles mnuAll.Click
        AsgFrmStaffOrder_Load(Nothing, Nothing)
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Hide()
        frmStaffMainPage.Show()
    End Sub

    'Private Sub AsgFrmStaffOrder_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
    '    frmStaffMainPage.Show()
    'End Sub

    Private Sub mnuReport_Click(sender As Object, e As EventArgs) Handles mnuReport.Click
        Dim strSql As String
        Dim staffDS As DataSet = New DataSet()
        Dim strPosition As String = ""
        If StartConnection() = True Then
            strSql = "Select * From Staff Where Staff_Id = " & frmStaffLoginPage.intCurrentStaffID
            da = New SqlDataAdapter(strSql, connection)
            staffDS.Clear()
            da.Fill(staffDS, "Staff")
            If staffDS.Tables("Staff").Rows.Count > 0 Then
                strPosition = staffDS.Tables("Staff").Rows(0).Item("Position")
            End If
            EndConnection()
        End If
        If strPosition = "Staff" Then
            MessageBox.Show("You are not authorised to generate menu report", "Cannot Generate Report", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            AsgFrmGenerateMenuReport.ShowDialog()
        End If
    End Sub
End Class