﻿Public Class FoodOrder
    Private Property intOrderNo As Integer
    Private Property strDate As String
    Private Property intTotalItems As Integer
    Private Property strPaymentMethod As String
    Private Property decSubTotal As Decimal
    Private Property decFoodAmount As Decimal

    Friend Sub New(intOrderNo As Integer, strDate As String, intTotalItems As Integer, strPaymentMethod As String, decSubTotal As Decimal, decFoodAmount As Decimal)
        Me.intOrderNo = intOrderNo
        Me.strDate = strDate
        Me.intTotalItems = intTotalItems
        Me.strPaymentMethod = strPaymentMethod
        Me.decSubTotal = decSubTotal
        Me.decFoodAmount = decFoodAmount
    End Sub

    Friend Function GetIntOrderNo() As Integer
        Return intOrderNo
    End Function

    Friend Function GetStrDate() As String
        Return strDate
    End Function

    Friend Function GetIntTotalItems() As Integer
        Return intTotalItems
    End Function

    Friend Function GetStrPaymentMethod() As String
        Return strPaymentMethod
    End Function

    Friend Function GetDecSubTotal() As Decimal
        Return decSubTotal
    End Function

    Friend Function GetDecFoodAmount() As Decimal
        Return decFoodAmount
    End Function
End Class
