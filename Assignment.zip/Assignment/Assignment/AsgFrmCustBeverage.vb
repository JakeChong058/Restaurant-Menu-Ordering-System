﻿Imports System.Data.SqlClient

Public Class AsgFrmCustBeverage
    Private da As SqlDataAdapter
    Private ds As DataSet = New DataSet()
    Private intRecords As Integer
    Friend menuItem() As CustMenuItems
    'Private button(7) As Button
    Private picture() As PictureBox
    Private labels() As Label
    Private noLabel() As Label
    Private table() As TableLayoutPanel
    Private cartItem As CartItem
    'Testing
    Private intCustNo As Integer = FrmLoginPage.intCustNo
    Private Sub mnuAll_Click(sender As Object, e As EventArgs) Handles mnuAll.Click
        AsgFrmCustOrder.Show()
        Me.Hide()
    End Sub

    Private Sub mnuFood_Click(sender As Object, e As EventArgs) Handles mnuFood.Click
        AsgFrmCustFoods.Show()
        Me.Hide()
    End Sub

    Private Sub mnuFoodWestern_Click(sender As Object, e As EventArgs) Handles mnuFoodWestern.Click
        AsgFrmCustWestern.Show()
        Me.Hide()
    End Sub

    Private Sub mnuFoodChicken_Click(sender As Object, e As EventArgs) Handles mnuFoodChicken.Click
        AsgFrmCustChicken.Show()
        Me.Hide()
    End Sub

    Private Sub mnuFoodSalad_Click(sender As Object, e As EventArgs) Handles mnuFoodSalad.Click
        AsgFrmCustSalad.Show()
        Me.Hide()
    End Sub

    Private Sub mnuDessertPudding_Click(sender As Object, e As EventArgs) Handles mnuDessertPudding.Click
        AsgFrmCustPudding.Show()
        Me.Hide()
    End Sub

    Private Sub mnuDessertIceCream_Click(sender As Object, e As EventArgs) Handles mnuDessertIceCream.Click
        AsgFrmCustIceCream.Show()
        Me.Hide()
    End Sub

    Private Sub mnuDessertCake_Click(sender As Object, e As EventArgs) Handles mnuDessertCake.Click
        AsgFrmCustCake.Show()
        Me.Hide()
    End Sub

    Private Sub mnuDessert_Click(sender As Object, e As EventArgs) Handles mnuDesserts.Click
        AsgFrmCustDessert.Show()
        Me.Hide()
    End Sub

    Private Sub mnuBeveragesCoffee_Click(sender As Object, e As EventArgs) Handles mnuBeveragesCoffee.Click
        AsgFrmCustCoffee.Show()
        Me.Hide()
    End Sub

    Private Sub mnuBeveragesTea_Click(sender As Object, e As EventArgs) Handles mnuBeveragesTea.Click
        AsgFrmCustTea.Show()
        Me.Hide()
    End Sub

    Private Sub mnuBeveragesIced_Click(sender As Object, e As EventArgs) Handles mnuBeveragesIced.Click
        AsgFrmCustIced.Show()
        Me.Hide()
    End Sub

    Private Sub AsgFrmCustBeverage_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        AsgFrmCustOrder.Show()
    End Sub

    Private Sub AddControls()
        Dim intCol As Integer = menuItem.Length
        Dim intCount As Integer = 0
        Do While intCol <> 0
            TableLayoutPanel1.Controls.Add(table(intCount))
            table(intCount).Controls.Add(picture(intCount))
            table(intCount).Controls.Add(labels(intCount))
            table(intCount).Controls.Add(menuItem(intCount).GetButton())
            TableLayoutPanel1.Controls.Add(noLabel(intCount))
            intCol -= 1
            intCount += 1
        Loop

        'intCol = TableLayoutPanel1.ColumnCount
        ''intCount = 0
        'Do While intCol <> 0
        '    TableLayoutPanel1.Controls.Add(table(intCount))
        '    table(intCount).Controls.Add(picture(intCount))
        '    table(intCount).Controls.Add(label(intCount))
        '    table(intCount).Controls.Add(menuItem(intCount).GetButton())
        '    TableLayoutPanel1.Controls.Add(noLabel(intCount))
        '    intCol -= 2
        '    intCount += 1
        'Loop

        'intCol = TableLayoutPanel1.ColumnCount
        'Do While intCol <> 0
        '    TableLayoutPanel1.Controls.Add(table(intCount))
        '    table(intCount).Controls.Add(picture(intCount))
        '    table(intCount).Controls.Add(label(intCount))
        '    table(intCount).Controls.Add(menuItem(intCount).GetButton())
        '    TableLayoutPanel1.Controls.Add(noLabel(intCount))
        '    intCol -= 2
        '    intCount += 1
        'Loop
    End Sub

    Private Sub CreateControls()
        For intIndex = 0 To menuItem.Length - 1 Step 1
            'Button(intIndex) = New Button()
            'Button(intIndex).Text = "Add +"
            'Button(intIndex).Font = New Font("Microsoft Sans Serif", 9, FontStyle.Bold)
            'Button(intIndex).Dock = DockStyle.Fill
            'Button(intIndex).BackColor = Color.MediumTurquoise
            menuItem(intIndex) = New CustMenuItems(ds.Tables("Menu").Rows(intIndex).Item(0),
            ds.Tables("Menu").Rows(intIndex).Item(1), ds.Tables("Menu").Rows(intIndex).Item(2),
            ds.Tables("Menu").Rows(intIndex).Item(3), ds.Tables("Menu").Rows(intIndex).Item(4),
            ds.Tables("Menu").Rows(intIndex).Item(5), ds.Tables("Menu").Rows(intIndex).Item(6),
            ds.Tables("Menu").Rows(intIndex).Item(7), ds.Tables("Menu").Rows(intIndex).Item(8))
            AddHandler menuItem(intIndex).GetButton().Click, AddressOf Button6_Click
            picture(intIndex) = New PictureBox()
            'picture(intIndex).Width = 150
            'picture(intIndex).Height = 150
            picture(intIndex).Dock = DockStyle.Fill
            picture(intIndex).SizeMode = PictureBoxSizeMode.StretchImage
            labels(intIndex) = New Label()
            'label(intIndex).Text = "Label " & intIndex + 1
            labels(intIndex).Text = menuItem(intIndex).GetStrDescription() & vbNewLine & menuItem(intIndex).GetDecPrice().ToString("C")
            labels(intIndex).TextAlign = ContentAlignment.MiddleCenter
            'label(intIndex).Width = 150
            'label(intIndex).Height = 80
            labels(intIndex).Dock = DockStyle.Fill
            labels(intIndex).TextAlign = ContentAlignment.MiddleCenter
            picture(intIndex).Image = Image.FromFile("Images\" & menuItem(intIndex).GetStrImage())
            noLabel(intIndex) = New Label()
            table(intIndex) = New TableLayoutPanel()
            table(intIndex).Width = 274
            table(intIndex).Height = 418
            table(intIndex).ColumnCount = 1
            table(intIndex).RowCount = 3
            table(intIndex).RowStyles.Add(New RowStyle(SizeType.Absolute, 150))
            table(intIndex).RowStyles.Add(New RowStyle(SizeType.Absolute, 80))
            table(intIndex).RowStyles.Add(New RowStyle(SizeType.Absolute, 20))
        Next intIndex

        'picture(0).Image = My.Resources.apple_juice
        'picture(1).Image = My.Resources.cake
        'picture(2).Image = My.Resources.cheese_cake
        'picture(3).Image = My.Resources.fried_chicken
        'picture(4).Image = My.Resources.ice_choco
        'picture(5).Image = My.Resources.ice_cream
        'picture(6).Image = My.Resources.latte
        'picture(7).Image = My.Resources.lemon_tea
        'picture(8).Image = My.Resources.apple_juice
        'picture(9).Image = My.Resources.Budget
        'picture(10).Image = My.Resources.B_flat
        'picture(11).Image = My.Resources.cake
    End Sub

    Private Sub AsgFrmCustBeverage_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim intCount As Integer = 0
        Dim strSql As String
        TableLayoutPanel1.Controls.Clear()
        If StartConnection() = True Then
            strSql = "Select * From Menu Where Category = 'Beverages' AND Availability = 'Available' AND IsPromotion = 'F'"
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            da.Fill(ds, "Menu")
            ReDim menuItem(ds.Tables("Menu").Rows.Count - 1)
            ReDim picture(ds.Tables("Menu").Rows.Count - 1)
            ReDim labels(ds.Tables("Menu").Rows.Count - 1)
            ReDim noLabel(ds.Tables("Menu").Rows.Count - 1)
            ReDim table(ds.Tables("Menu").Rows.Count - 1)
            If ds.Tables("Menu").Rows.Count < 4 Then
                TableLayoutPanel1.RowCount = 1
            ElseIf ds.Tables("Menu").Rows.Count Mod 4 <> 0 Then
                TableLayoutPanel1.RowCount = (ds.Tables("Menu").Rows.Count \ 4) + 1
            Else
                TableLayoutPanel1.RowCount = ds.Tables("Menu").Rows.Count \ 4
            End If
            'TableLayoutPanel1.RowCount = ds.Tables("Menu").Rows.Count
            'TableLayoutPanel1.Height = 35 * TableLayoutPanel1.RowCount
            TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 280))
            'Next intIndex
            TableLayoutPanel1.Height = 280 * TableLayoutPanel1.RowCount

            intRecords = ds.Tables("Menu").Rows.Count
            'Row.Cells[2].Tag = nm
            If ds.Tables("Menu").Rows.Count > 0 Then
                CreateControls()
                AddControls()
            End If
            EndConnection()
        Else
            MessageBox.Show("Error in connecting to database server", "Error", MessageBoxButtons.OK)
        End If
        'TableLayoutPanel1.RowCount = 2
        'For intIndex = 1 To TableLayoutPanel1.RowCount Step 1
        'TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 280))
        'Next intIndex
        'TableLayoutPanel1.Height = 280 * TableLayoutPanel1.RowCount
    End Sub

    'Private Sub btnCart_Click(sender As Object, e As EventArgs) Handles btnCart.Click
    '    Me.Hide()
    '    TestCart.TestCart_Load(Nothing, Nothing)
    '    TestCart.Show()
    'End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        'Static Dim strMenu As String
        Dim intQuantity As Integer = 0
        Dim strSql As String
        Dim MSSqlCommand As New SqlCommand
        '    For intNumber = 0 To menuItem.Length - 1 Step 1
        '        If sender Is menuItem(intNumber).GetButton() Then
        '            MessageBox.Show(menuItem(intNumber).GetStrDescription() & " is added to your cart.", "Items Added To Cart", MessageBoxButtons.OK, MessageBoxIcon.Information)
        '            strMenu = menuItem(intNumber).GetStrDescription() & vbTab & vbTab & vbTab & menuItem(intNumber).GetDecPrice().ToString("C") & vbTab & vbTab & vbTab & 1
        '            AsgFrmCustCart.lstItems.Items.Add(strMenu)
        '            btnCart.Enabled = True
        '        End If
        '    Next intNumber
        For intNumber = 0 To menuItem.Length - 1 Step 1
            If sender Is menuItem(intNumber).GetButton() Then
                If StartConnection() = True Then
                    strSql = "Select I.Cust_Id, I.Menu_Id, I.Price, I.Quantity From Menu M, CartItem I, Customer C WHERE I.Cust_Id = C.Cust_No AND I.Menu_Id = M.Menu_Id AND I.Cust_Id = " & intCustNo & " AND I.Menu_Id = '" & menuItem(intNumber).GetStrMenuId() & "'"
                    da = New SqlDataAdapter(strSql, connection)
                    ds.Clear()
                    Try
                        da.Fill(ds, "CartItem")
                    Catch ex As Exception
                        'do something
                    End Try

                    If ds.Tables("CartItem").Rows.Count > 0 Then
                        If ds.Tables("CartItem").Rows(0).Item("Quantity") = 10 Then
                            MessageBox.Show("Maximum quantity of " & menuItem(intNumber).GetStrDescription() & " is 10, you cannot add it to cart anymore.", "Cannot Add Item To Cart", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                            EndConnection()
                            Return
                        End If
                        AsgFrmCustCart.IsFromOrder()
                        intQuantity = ds.Tables("CartItem").Rows(0).Item("Quantity") + 1
                        EndConnection()
                        cartItem = New CartItem(intCustNo, menuItem(intNumber))
                        'EndConnection()
                        If StartConnection() = True Then
                            strSql = "Update CartItem set Quantity=@Quantity Where Cust_Id=@Cust_Id AND Menu_Id=@Menu_Id"
                            MSSqlCommand = New SqlCommand(strSql, connection)
                            MSSqlCommand.Parameters.AddWithValue("@Quantity", intQuantity)
                            MSSqlCommand.Parameters.AddWithValue("@Cust_Id", intCustNo)
                            MSSqlCommand.Parameters.AddWithValue("@Menu_Id", cartItem.GetMenuItem().GetStrMenuId())
                            MSSqlCommand.ExecuteNonQuery()

                            MessageBox.Show(menuItem(intNumber).GetStrDescription() & " is added to your cart.", "Items Added To Cart", MessageBoxButtons.OK, MessageBoxIcon.Information)
                            EndConnection()
                            'AsgFrmCustCart.AsgFrmCustCart_Load(Nothing, Nothing)
                        End If
                        Return
                    Else
                        AsgFrmCustCart.IsFromOrder()
                        EndConnection()
                        If StartConnection() = True Then
                            cartItem = New CartItem(intCustNo, menuItem(intNumber))
                            strSql = "Insert Into CartItem(Cust_Id,Menu_Id,Price,Quantity)Values(@Cust_Id,@Menu_Id,@Price,@Quantity)"
                            MSSqlCommand = New SqlCommand(strSql, connection)
                            MSSqlCommand.Parameters.AddWithValue("@Cust_Id", intCustNo)
                            MSSqlCommand.Parameters.AddWithValue("@Menu_Id", cartItem.GetMenuItem().GetStrMenuId())
                            MSSqlCommand.Parameters.AddWithValue("@Price", cartItem.GetMenuItem().GetDecPrice())
                            MSSqlCommand.Parameters.AddWithValue("@Quantity", cartItem.GetNMQuantity().Value)
                            MSSqlCommand.ExecuteNonQuery()
                            MessageBox.Show(menuItem(intNumber).GetStrDescription() & " is added to your cart.", "Items Added To Cart", MessageBoxButtons.OK, MessageBoxIcon.Information)
                            EndConnection()
                            'AsgFrmCustCart.AsgFrmCustCart_Load(Nothing, Nothing)

                        End If

                    End If
                End If
                'MessageBox.Show(menuItem(intNumber).GetStrDescription() & " is added to your cart.", "Items Added To Cart", MessageBoxButtons.OK, MessageBoxIcon.Information)
                'strMenu = menuItem(intNumber).GetStrDescription() & vbTab & vbTab & vbTab & menuItem(intNumber).GetDecPrice().ToString("C") & vbTab & vbTab & vbTab & 1
                'AsgFrmCustCart.lstItems.Items.Add(strMenu)
                'btnCart.Enabled = True
                Exit For
            End If
        Next intNumber
    End Sub

    Private Sub btnCart_Click(sender As Object, e As EventArgs) Handles btnCart.Click
        Me.Hide()
        'AsgFrmCustCart.AsgFrmCustCart_Load(Nothing, Nothing)
        AsgFrmCustCart.Show()
    End Sub

    Private Sub btnViewOrder_Click(sender As Object, e As EventArgs) Handles btnViewOrder.Click
        Me.Hide()
        AsgFrmCustViewOrder.Show()
    End Sub

    Private Sub txtSearch_TextChanged(sender As Object, e As EventArgs) Handles txtSearch.TextChanged
        If txtSearch.Text.Trim() = "" Then
            AsgFrmCustBeverage_Load(Nothing, Nothing)
        Else
            TableLayoutPanel1.Controls.Clear()
            Dim intCount As Integer = 0
            Dim strSql As String
            'txtSearch.Text = "Search items here..."
            'txtSearch.ForeColor = SystemColors.ControlLight
            If StartConnection() = True Then
                strSql = "Select * From Menu Where Availability = 'Available' AND Description LIKE '%" & txtSearch.Text.Trim() & "%' OR Price LIKE '%" & txtSearch.Text.Trim() & "%' OR Category LIKE '%" & txtSearch.Text.Trim() & "%' OR SubCategory LIKE '%" & txtSearch.Text.Trim() & "%'"
                da = New SqlDataAdapter(strSql, connection)
                ds.Clear()
                da.Fill(ds, "Menu")
                ReDim menuItem(ds.Tables("Menu").Rows.Count - 1)
                ReDim picture(ds.Tables("Menu").Rows.Count - 1)
                ReDim labels(ds.Tables("Menu").Rows.Count - 1)
                ReDim noLabel(ds.Tables("Menu").Rows.Count - 1)
                ReDim table(ds.Tables("Menu").Rows.Count - 1)
                'Console.WriteLine((ds.Tables("Menu").Rows.Count + 1) \ 4)
                If ds.Tables("Menu").Rows.Count < 4 Then
                    TableLayoutPanel1.RowCount = 1
                ElseIf ds.Tables("Menu").Rows.Count Mod 4 <> 0 Then
                    TableLayoutPanel1.RowCount = (ds.Tables("Menu").Rows.Count \ 4) + 1
                Else
                    TableLayoutPanel1.RowCount = ds.Tables("Menu").Rows.Count \ 4
                End If
                'TableLayoutPanel1.RowCount = ds.Tables("Menu").Rows.Count
                'TableLayoutPanel1.Height = 35 * TableLayoutPanel1.RowCount
                TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 280))
                'Next intIndex
                TableLayoutPanel1.Height = 280 * TableLayoutPanel1.RowCount
                'TableLayoutPanel1.RowStyles.Clear()

                intRecords = ds.Tables("Menu").Rows.Count
                'Row.Cells[2].Tag = nm
                If ds.Tables("Menu").Rows.Count > 0 Then
                    CreateControls()
                    AddControls()
                End If
                EndConnection()
            Else
                MessageBox.Show("Error in connecting to database server", "Error", MessageBoxButtons.OK)
            End If
        End If
    End Sub

    Private Sub mnuPromotion_Click(sender As Object, e As EventArgs) Handles mnuPromotion.Click
        Me.Hide()
        AsgFrmCustPromotion.Show()
    End Sub

    Friend Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        Me.Close()
        AsgFrmCustOrder.btnLogout_Click(Nothing, Nothing)
    End Sub
End Class