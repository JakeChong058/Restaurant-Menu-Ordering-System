﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AsgFrmStaffOrderPayment
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lblCart = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblID = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblDate = New System.Windows.Forms.Label()
        Me.grpPayment = New System.Windows.Forms.GroupBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.lblService = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.lblGrand = New System.Windows.Forms.Label()
        Me.lblSST = New System.Windows.Forms.Label()
        Me.lblSubtotal = New System.Windows.Forms.Label()
        Me.lblQty = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblTax = New System.Windows.Forms.Label()
        Me.lblSub = New System.Windows.Forms.Label()
        Me.lblQuantity = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtPayment = New System.Windows.Forms.TextBox()
        Me.btnMake = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpPayment.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Assignment.My.Resources.Resources.Island_Cafe_Logo
        Me.PictureBox1.Location = New System.Drawing.Point(446, -3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(165, 180)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 8
        Me.PictureBox1.TabStop = False
        '
        'lblCart
        '
        Me.lblCart.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCart.Location = New System.Drawing.Point(370, 212)
        Me.lblCart.Name = "lblCart"
        Me.lblCart.Size = New System.Drawing.Size(315, 47)
        Me.lblCart.TabIndex = 18
        Me.lblCart.Text = "ORDER PAYMENT"
        Me.lblCart.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(4, 295)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(221, 35)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "Order ID: "
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblID
        '
        Me.lblID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblID.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblID.Location = New System.Drawing.Point(221, 294)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(117, 35)
        Me.lblID.TabIndex = 20
        Me.lblID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(371, 294)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(292, 35)
        Me.Label2.TabIndex = 21
        Me.Label2.Text = "Order Date: "
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblDate
        '
        Me.lblDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDate.Location = New System.Drawing.Point(669, 294)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(214, 35)
        Me.lblDate.TabIndex = 22
        Me.lblDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'grpPayment
        '
        Me.grpPayment.Controls.Add(Me.DataGridView1)
        Me.grpPayment.Controls.Add(Me.lblService)
        Me.grpPayment.Controls.Add(Me.Label19)
        Me.grpPayment.Controls.Add(Me.lblGrand)
        Me.grpPayment.Controls.Add(Me.lblSST)
        Me.grpPayment.Controls.Add(Me.lblSubtotal)
        Me.grpPayment.Controls.Add(Me.lblQty)
        Me.grpPayment.Controls.Add(Me.Label6)
        Me.grpPayment.Controls.Add(Me.lblTax)
        Me.grpPayment.Controls.Add(Me.lblSub)
        Me.grpPayment.Controls.Add(Me.lblQuantity)
        Me.grpPayment.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpPayment.Location = New System.Drawing.Point(164, 356)
        Me.grpPayment.Name = "grpPayment"
        Me.grpPayment.Size = New System.Drawing.Size(719, 421)
        Me.grpPayment.TabIndex = 23
        Me.grpPayment.TabStop = False
        Me.grpPayment.Text = "ORDER SUMMARY"
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.DataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.White
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.White
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(12, 39)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.RowHeadersWidth = 62
        Me.DataGridView1.RowTemplate.Height = 28
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(691, 185)
        Me.DataGridView1.TabIndex = 12
        '
        'lblService
        '
        Me.lblService.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblService.Location = New System.Drawing.Point(359, 347)
        Me.lblService.Name = "lblService"
        Me.lblService.Size = New System.Drawing.Size(345, 26)
        Me.lblService.TabIndex = 11
        Me.lblService.Text = "d"
        '
        'Label19
        '
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(156, 346)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(206, 27)
        Me.Label19.TabIndex = 10
        Me.Label19.Text = "Service Charge: "
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblGrand
        '
        Me.lblGrand.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGrand.Location = New System.Drawing.Point(359, 388)
        Me.lblGrand.Name = "lblGrand"
        Me.lblGrand.Size = New System.Drawing.Size(340, 26)
        Me.lblGrand.TabIndex = 8
        Me.lblGrand.Text = "e"
        '
        'lblSST
        '
        Me.lblSST.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSST.Location = New System.Drawing.Point(359, 313)
        Me.lblSST.Name = "lblSST"
        Me.lblSST.Size = New System.Drawing.Size(345, 26)
        Me.lblSST.TabIndex = 7
        Me.lblSST.Text = "c"
        '
        'lblSubtotal
        '
        Me.lblSubtotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubtotal.Location = New System.Drawing.Point(359, 273)
        Me.lblSubtotal.Name = "lblSubtotal"
        Me.lblSubtotal.Size = New System.Drawing.Size(345, 26)
        Me.lblSubtotal.TabIndex = 6
        Me.lblSubtotal.Text = "b"
        '
        'lblQty
        '
        Me.lblQty.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblQty.Location = New System.Drawing.Point(359, 235)
        Me.lblQty.Name = "lblQty"
        Me.lblQty.Size = New System.Drawing.Size(350, 26)
        Me.lblQty.TabIndex = 5
        Me.lblQty.Text = "a"
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(202, 388)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(160, 31)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "Grand Total: "
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblTax
        '
        Me.lblTax.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTax.Location = New System.Drawing.Point(207, 313)
        Me.lblTax.Name = "lblTax"
        Me.lblTax.Size = New System.Drawing.Size(155, 27)
        Me.lblTax.TabIndex = 3
        Me.lblTax.Text = "SST: "
        Me.lblTax.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblSub
        '
        Me.lblSub.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSub.Location = New System.Drawing.Point(202, 273)
        Me.lblSub.Name = "lblSub"
        Me.lblSub.Size = New System.Drawing.Size(160, 40)
        Me.lblSub.TabIndex = 2
        Me.lblSub.Text = "Subtotal: "
        Me.lblSub.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblQuantity
        '
        Me.lblQuantity.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblQuantity.Location = New System.Drawing.Point(167, 235)
        Me.lblQuantity.Name = "lblQuantity"
        Me.lblQuantity.Size = New System.Drawing.Size(195, 43)
        Me.lblQuantity.TabIndex = 1
        Me.lblQuantity.Text = "Total Quantity: "
        Me.lblQuantity.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(9, 806)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(368, 35)
        Me.Label3.TabIndex = 24
        Me.Label3.Text = "Amount Received (&RM): "
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txtPayment
        '
        Me.txtPayment.Location = New System.Drawing.Point(376, 807)
        Me.txtPayment.MaxLength = 7
        Me.txtPayment.Name = "txtPayment"
        Me.txtPayment.Size = New System.Drawing.Size(115, 26)
        Me.txtPayment.TabIndex = 0
        Me.txtPayment.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'btnMake
        '
        Me.btnMake.BackColor = System.Drawing.Color.MediumTurquoise
        Me.btnMake.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMake.Location = New System.Drawing.Point(497, 789)
        Me.btnMake.Name = "btnMake"
        Me.btnMake.Size = New System.Drawing.Size(228, 60)
        Me.btnMake.TabIndex = 1
        Me.btnMake.Text = "Make &Payment"
        Me.btnMake.UseVisualStyleBackColor = False
        '
        'btnCancel
        '
        Me.btnCancel.BackColor = System.Drawing.Color.MediumTurquoise
        Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.Location = New System.Drawing.Point(731, 789)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(152, 60)
        Me.btnCancel.TabIndex = 2
        Me.btnCancel.Text = "&Cancel"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'AsgFrmStaffOrderPayment
        '
        Me.AcceptButton = Me.btnMake
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.White
        Me.CancelButton = Me.btnCancel
        Me.ClientSize = New System.Drawing.Size(1066, 873)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnMake)
        Me.Controls.Add(Me.txtPayment)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.grpPayment)
        Me.Controls.Add(Me.lblDate)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblID)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblCart)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "AsgFrmStaffOrderPayment"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Point of Sales"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpPayment.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents lblCart As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents lblID As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lblDate As Label
    Friend WithEvents grpPayment As GroupBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents lblService As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents lblGrand As Label
    Friend WithEvents lblSST As Label
    Friend WithEvents lblSubtotal As Label
    Friend WithEvents lblQty As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents lblTax As Label
    Friend WithEvents lblSub As Label
    Friend WithEvents lblQuantity As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txtPayment As TextBox
    Friend WithEvents btnMake As Button
    Friend WithEvents btnCancel As Button
End Class
