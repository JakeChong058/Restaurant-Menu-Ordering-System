﻿Public Class AsgFrmGenerateReport
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub



    Private Sub dtpFrom_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles dtpFrom.Validating
        'Dim strCVV As String = If(mskCVV.MaskCompleted, mskCVV.Text, "")
        Dim dateCurrent As DateTime = Date.Now
        If dateCurrent.ToString("dd/M/yyyy") < dtpFrom.Value Then
            errValidation.SetError(dtpFrom, "Date is not valid.")
            e.Cancel = True ' Indicate the validating event DOES NOT pass (i.e. there is input error)
        ElseIf dtpFrom.Value > dtpTo.Value Then
            errValidation.SetError(dtpFrom, "'To' date cannot be earlier than 'From' date.")
            e.Cancel = True
        Else
            errValidation.SetError(dtpFrom, Nothing) ' Remove the error from the error provider
        End If

        'If strCVV = "" Then
        '    errValidation.SetError(mskCVV, "Please key in complete CVV")
        '    e.Cancel = True ' Indicate the validating event DOES NOT pass (i.e. there is input error)
        'Else
        '    errValidation.SetError(mskCVV, Nothing) ' Remove the error from the error provider
        'End If

        'If date1 > date2 Then
        '    MsgBox("Expired")
        'Else
        '    MsgBox("Not Expired")
        'End If
    End Sub

    Private Sub dtpTo_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles dtpTo.Validating
        'Dim strCVV As String = If(mskCVV.MaskCompleted, mskCVV.Text, "")
        Dim dateCurrent As DateTime = Date.Now
        If dtpFrom.Value > dtpTo.Value Then
            errValidation.SetError(dtpTo, "'To' date cannot be earlier than 'From' date.")
            e.Cancel = True
        Else
            errValidation.SetError(dtpTo, Nothing) ' Remove the error from the error provider
        End If

        'If strCVV = "" Then
        '    errValidation.SetError(mskCVV, "Please key in complete CVV")
        '    e.Cancel = True ' Indicate the validating event DOES NOT pass (i.e. there is input error)
        'Else
        '    errValidation.SetError(mskCVV, Nothing) ' Remove the error from the error provider
        'End If

        'If date1 > date2 Then
        '    MsgBox("Expired")
        'Else
        '    MsgBox("Not Expired")
        'End If
    End Sub

    Private Sub btnGenerate_Click(sender As Object, e As EventArgs) Handles btnGenerate.Click
        If Me.ValidateChildren() = False Then
            MessageBox.Show("Cannot generate report. This might be due to: " & vbNewLine & "1. 'To' date is earlier than 'From' date ." & vbNewLine & "2. From 'date' is not valid.", "Cannot Generate Report", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return ' There are input error --> Stop insertion
        End If
        AsgFrmOrderReport.Show()
        Me.Hide()
    End Sub

    Private Sub AsgFrmGenerateReport_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        AsgFrmStaffCompleteOrder.Show()
    End Sub
End Class