﻿Imports System.Data.SqlClient
Imports Microsoft.VisualBasic.ApplicationServices

Module StaffData
    Friend da As SqlDataAdapter
    Friend ds As DataSet = New DataSet()
    Friend staff() As StaffClass
    Friend currentStaff As StaffClass = Nothing


    Friend Sub ConnectServer()
        Dim strSQLStatement As String
        If StartConnection() = True Then
            strSQLStatement = "Select * From Staff"
            da = New SqlDataAdapter(strSQLStatement, connection)
            ds.Clear()
            da.Fill(ds, "Staff")
            ReDim staff(ds.Tables("Staff").Rows.Count - 1)

            For intIndex = 0 To staff.Length - 1
                staff(intIndex) = New Assignment.StaffClass(ds.Tables("Staff").Rows(intIndex).Item(0), ds.Tables("Staff").Rows(intIndex).Item(1), ds.Tables("Staff").Rows(intIndex).Item(2), ds.Tables("Staff").Rows(intIndex).Item(3), ds.Tables("Staff").Rows(intIndex).Item(4), ds.Tables("Staff").Rows(intIndex).Item(5), ds.Tables("Staff").Rows(intIndex).Item(6).ToString, ds.Tables("Staff").Rows(intIndex).Item(7).ToString) 'tostring() because data is NULL
            Next intIndex

        Else
            MessageBox.Show("Error in connecting to database server", "Error", MessageBoxButtons.OK)
        End If
        EndConnection()
    End Sub
End Module
