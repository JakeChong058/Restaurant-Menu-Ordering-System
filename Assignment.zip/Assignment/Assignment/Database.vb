﻿Module Database
    Friend connection As New System.Data.SqlClient.SqlConnection

    Friend Function StartConnection() As Boolean
        Dim strMSSQLConnectionString As String

        strMSSQLConnectionString = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Restaurant.mdf;Integrated Security=True"
        Try
            connection.ConnectionString = strMSSQLConnectionString
            connection.Open()
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Friend Sub EndConnection()
        connection.Close()
    End Sub
End Module
