﻿Public Class frmStaffProfile

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Close()
    End Sub

    Friend Sub frmStaffProfile_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        StaffData.ConnectServer()
        lblId.Text = currentStaff.GetStaff_Id
        lblName.Text = currentStaff.GetStaff_Name
        lblPosition.Text = currentStaff.GetPosition
        lblStatus.Text = currentStaff.GetStatus

    End Sub

    Private Sub frmStaffProfile_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        frmStaffMainPage.Show()
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        frmStaffChangePassword.ShowDialog()
    End Sub

    Private Sub btnChangeSecret_Click(sender As Object, e As EventArgs) Handles btnChangeSecret.Click
        frmStaffChangeSecretQuestion.ShowDialog()
    End Sub
End Class