﻿Imports System.Data.SqlClient
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class AsgFrmCustCurrentOrder
    Private intCustNo = FrmLoginPage.intCustNo
    'Friend strParts() As String
    Private da As SqlDataAdapter
    Private ds As DataSet = New DataSet()
    Private orderItem() As OrderList
    Private menus() As CustMenuItems
    'The default order number
    Private intOrderNo As Integer = 1001
    Private fromPayment As Boolean = False
    Private Sub btnBackMenu_Click(sender As Object, e As EventArgs) Handles btnBackMenu.Click
        Me.Close()
        AsgFrmCustViewOrder.Close()
        AsgFrmPayment.Close()
        AsgFrmCustCart.Close()
        AsgFrmCustOrder.Show()
        fromPayment = False
    End Sub

    Friend Sub IsFromPayment()
        fromPayment = True
    End Sub

    Private Sub AsgFrmCustCurrentOrder_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If fromPayment = True Then
            intOrderNo = AsgFrmPayment.intOrderNo
        Else
            intOrderNo = AsgFrmCustViewOrder.intOrderNumber
        End If
        Dim strSql As String
        If StartConnection() = True Then
            strSql = "Select M.Menu_Id, M.Description, M.Price, M.Category, M.IsPromotion, M.SubCategory, M.Image, M.Status, M.Availability From Menu M, Food_Order F, Order_List O, Customer C WHERE F.Cust_No = C.Cust_No AND O.Menu_Id = M.Menu_Id AND O.Order_No = F.Order_No AND F.Order_No = " & intOrderNo & " AND F.Cust_No = " & intCustNo
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            da.Fill(ds, "Menu")
            ReDim menus(ds.Tables("Menu").Rows.Count - 1)
            If ds.Tables("Menu").Rows.Count > 0 Then
                For intCount = 0 To menus.Length - 1 Step 1
                    menus(intCount) = New CustMenuItems(ds.Tables("Menu").Rows(intCount).Item(0),
                    ds.Tables("Menu").Rows(intCount).Item(1), ds.Tables("Menu").Rows(intCount).Item(2),
                    ds.Tables("Menu").Rows(intCount).Item(3), ds.Tables("Menu").Rows(intCount).Item(4),
                    ds.Tables("Menu").Rows(intCount).Item(5), ds.Tables("Menu").Rows(intCount).Item(6),
                    ds.Tables("Menu").Rows(intCount).Item(7), ds.Tables("Menu").Rows(intCount).Item(8))
                Next intCount
            End If
            EndConnection()
        End If
        If StartConnection() = True Then
            strSql = "Select O.Quantity, O.Price From Order_List O, Food_Order F WHERE O.Order_No = F.Order_No AND F.Order_No = " & intOrderNo
            'da = New SqlDataAdapter(strSql, connection) 'F.Cust_Id = " & intCustNo '& " And I.Menu_Id = '" & menuItem(intNumber).GetStrMenuId() & "'"
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            Try
                da.Fill(ds, "Order_List")
            Catch ex As Exception
                'do something
            End Try
            If ds.Tables("Order_List").Rows.Count > 0 Then
                DataGridView1.DataSource = ds.Tables("Order_List")
                'DataGridView1.Columns(2).HeaderText = "Price (RM)"
                'ReDim descriptionLabel(ds.Tables("CartItem").Rows.Count - 1)
                'ReDim priceLabel(ds.Tables("CartItem").Rows.Count - 1)
                'lblEmpty.Visible = False
                'TableLayoutPanel1.Visible = True
                'btnClearCart.Enabled = True
                'btnProceed.Enabled = True
                'ReDim orderItem(ds.Tables("Order_List").Rows.Count - 1)
                'ReDim decPrice(ds.Tables("CartItem").Rows.Count - 1)
                'ReDim intQuantityEach(ds.Tables("CartItem").Rows.Count - 1)
                'ds.Tables("CartItem").Columns.Add("Item", Type.GetType("System.String"))
                'TableLayoutPanel1.RowCount = ds.Tables("CartItem").Rows.Count + 1
                'TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 41))
                'TableLayoutPanel1.Height = 33 * TableLayoutPanel1.RowCount
                'TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 48))
                'Console.WriteLine(DataGridView1.DataSource)
                'Console.WriteLine("Quantity" & vbTab & "Price")
                For intIndex = 0 To menus.Length - 1 Step 1
                    'intQuantity += ds.Tables("CartItem").Rows(intIndex).Item("Quantity")
                    'decSubtotal += ds.Tables("CartItem").Rows(intIndex).Item("Price")
                    'decPrice(intIndex) = ds.Tables("CartItem").Rows(intIndex).Item("Price")
                    'intQuantityEach(intIndex) = ds.Tables("CartItem").Rows(intIndex).Item("Quantity")
                    'decGrandTotal = decSubtotal + (decSubtotal * decSST) + (decSubtotal * decSERVICE_CHARGE)
                    'cartItem(intIndex) = New CartItem(ds.Tables("CartItem").Rows(intIndex).Item(0), menus(intIndex))
                    DataGridView1.Item(0, intIndex).Value = menus(intIndex).GetStrDescription()
                    'Console.WriteLine(DataGridView1.Item(0, intIndex).Value & vbTab & DataGridView1.Item(1, intIndex).Value & vbTab & DataGridView1.Item(2, intIndex).Value)
                    'DataGridView1.Item(2, intIndex).Value = DataGridView1.Item(2, intIndex).Value.ToString("C")
                    '    'TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 48))
                    '    'TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 0))
                    '    cartItem(intIndex) = New CartItem(ds.Tables("CartItem").Rows(intIndex).Item(0), menus(intIndex))
                    '    cartItem(intIndex).GetNMQuantity().Value = ds.Tables("CartItem").Rows(intIndex).Item("Quantity")
                    '    cartItem(intIndex).SetDecPrice(ds.Tables("CartItem").Rows(intIndex).Item("Price"))
                    '    descriptionLabel(intIndex) = New Label()
                    '    descriptionLabel(intIndex).Text = cartItem(intIndex).GetMenuItem().GetStrDescription()
                    '    descriptionLabel(intIndex).Dock = DockStyle.Fill
                    '    descriptionLabel(intIndex).TextAlign = ContentAlignment.MiddleCenter
                    '    descriptionLabel(intIndex).Font = New Font("Microsoft Sans Serif", 12)
                    '    'descriptionLabel(intIndex).Height = 44
                    '    priceLabel(intIndex) = New Label()
                    '    priceLabel(intIndex).Text = cartItem(intIndex).GetDecPrice().ToString("C")
                    '    priceLabel(intIndex).Dock = DockStyle.Fill
                    '    priceLabel(intIndex).TextAlign = ContentAlignment.MiddleCenter
                    '    priceLabel(intIndex).Font = New Font("Microsoft Sans Serif", 12)
                    '    'priceLabel(intIndex).Height = 44
                    '    AddHandler cartItem(intIndex).GetBtnRemove().Click, AddressOf btnRemoveItem_Click
                    '    AddHandler cartItem(intIndex).GetNMQuantity().ValueChanged, AddressOf NumericUpDown1_ValueChanged
                    '    TableLayoutPanel1.Controls.Add(cartItem(intIndex).GetBtnRemove())
                    '    TableLayoutPanel1.Controls.Add(descriptionLabel(intIndex))
                    '    TableLayoutPanel1.Controls.Add(cartItem(intIndex).GetNMQuantity())
                    '    TableLayoutPanel1.Controls.Add(priceLabel(intIndex))
                Next intIndex
                DataGridView1.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(0).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(0).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(1).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(1).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(2).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(2).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(1).SortMode = DataGridViewColumnSortMode.NotSortable
                DataGridView1.Columns(2).SortMode = DataGridViewColumnSortMode.NotSortable
                'DataGridView1.C = DataGridViewContentAlignment.MiddleCenter
                'TableLayoutPanel1.RowStyles.Add(New RowStyle(SizeType.Absolute, 45))
            End If
            EndConnection()
        End If
        If StartConnection() = True Then
            Dim dataSet As DataSet = New DataSet()
            strSql = "Select * From Food_Order F, Customer C WHERE F.Cust_No = C.Cust_No AND F.Cust_No = " & intCustNo & " AND F.Order_No = " & intOrderNo
            'da = New SqlDataAdapter(strSql, connection) 'F.Cust_Id = " & intCustNo '& " And I.Menu_Id = '" & menuItem(intNumber).GetStrMenuId() & "'"
            da = New SqlDataAdapter(strSql, connection)
            dataSet.Clear()
            Try
                da.Fill(dataSet, "Food_Order")
            Catch ex As Exception
                'do something
            End Try
            If dataSet.Tables("Food_Order").Rows.Count > 0 Then
                lblID.Text = dataSet.Tables("Food_Order").Rows(0).Item("Order_No").ToString()
                'lblPhone.Text = 
                lblStatus.Text = dataSet.Tables("Food_Order").Rows(0).Item("Status").ToString()
                lblPayment.Text = dataSet.Tables("Food_Order").Rows(0).Item("Payment_Method").ToString()
                lblTime.Text = dataSet.Tables("Food_Order").Rows(0).Item("Date").ToString()
                lblQty.Text = dataSet.Tables("Food_Order").Rows(0).Item("Total_Items").ToString()
                lblSubtotal.Text = "RM" & dataSet.Tables("Food_Order").Rows(0).Item("Subtotal").ToString()
                lblSST.Text = "6%"
                lblService.Text = "10%"
                lblGrand.Text = "RM" & dataSet.Tables("Food_Order").Rows(0).Item("Food_Amount").ToString()
            End If
            EndConnection()
        End If
        If StartConnection() = True Then
            Dim dataSet As DataSet = New DataSet()
            strSql = "Select * From Customer WHERE Cust_No = " & intCustNo
            'da = New SqlDataAdapter(strSql, connection) 'F.Cust_Id = " & intCustNo '& " And I.Menu_Id = '" & menuItem(intNumber).GetStrMenuId() & "'"
            da = New SqlDataAdapter(strSql, connection)
            dataSet.Clear()
            Try
                da.Fill(dataSet, "Customer")
            Catch ex As Exception
                'do something
            End Try
            If dataSet.Tables("Customer").Rows.Count > 0 Then
                lblPhone.Text = dataSet.Tables("Customer").Rows(0).Item("Phone_Num").ToString()
                'lblPhone.Text = 
                'lblQty.Text = ds.Tables("Food_Order").Rows(0).Item("Total_Items").ToString()
                'lblSubtotal.Text = ds.Tables("Food_Order").Rows(0).Item("Subtotal").ToString()
                'lblSST.Text = "6%"
                'lblService.Text = "10%"
                'lblGrand.Text = ds.Tables("Food_Order").Rows(0).Item("Food_Amount").ToString()
            End If
            EndConnection()
        End If
    End Sub

    Private Sub AsgFrmCustCurrentOrder_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        AsgFrmCustViewOrder.Close()
        AsgFrmPayment.Close()
        AsgFrmCustOrder.Show()
        fromPayment = False
    End Sub

    'Private Sub DataGridView1_ColumnHeaderMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles DataGridView1.ColumnHeaderMouseClick
    '    AsgFrmCustCurrentOrder_Load(Nothing, Nothing)
    'End Sub
End Class