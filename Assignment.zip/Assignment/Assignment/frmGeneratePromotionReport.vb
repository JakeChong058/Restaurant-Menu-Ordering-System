﻿Public Class frmGeneratePromotionReport

    Friend blnGenerateReportAll As Boolean = False
    Friend blnGenerateReport10 As Boolean = False
    Friend blnGenerateReport20 As Boolean = False

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
        'FrmPromotion.Show()
    End Sub


    'Private Sub btnBack_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
    '    'Me.Close()
    '    FrmPromotion.Show()
    'End Sub

    Private Sub Promotion20()
        blnGenerateReportAll = False
        blnGenerateReport10 = False
        blnGenerateReport20 = True
        Me.Close()
        frmViewPromotionReport.Show()
    End Sub

    Private Sub PromotionAll()
        blnGenerateReportAll = True
        blnGenerateReport10 = False
        blnGenerateReport20 = False
        Me.Close()
        frmViewPromotionReport.Show()
    End Sub

    Private Sub Promotion10()
        blnGenerateReportAll = False
        blnGenerateReport10 = True
        blnGenerateReport20 = False
        Me.Close()
        frmViewPromotionReport.Show()
    End Sub

    Private Sub btnGenerate_Click(sender As Object, e As EventArgs) Handles btnGenerate.Click
        If cboSelect.SelectedIndex = -1 Then
            MessageBox.Show("Please select a report to generate.", "No Report Selected", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        ElseIf cboSelect.SelectedIndex = 0 Then
            Promotion10()
        ElseIf cboSelect.SelectedIndex = 1 Then
            Promotion20()
        Else
            PromotionAll()
        End If
    End Sub

    Private Sub frmGeneratePromotionReport_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        FrmPromotion.Show()
    End Sub
End Class