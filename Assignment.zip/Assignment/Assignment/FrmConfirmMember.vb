﻿'Imports System.Data.SqlClient

'Public Class FrmConfirmMember
'    Private Sub btnToMemberUpdate_Click(sender As Object, e As EventArgs) Handles btnToMemberUpdate.Click

'        Dim connectionString As String = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Daniel Yong\Documents\A Y2 Sem 1\Visual Programming\Practical\Assignment\Assignment\Restaurent.mdf;Integrated Security=True"
'        Using connection As New SqlConnection(connectionString)
'            connection.Open()
'            Dim query As String = "SELECT Password FROM Member WHERE Member_Ic = @ic"
'            Using cmd As New SqlCommand(query, connection)
'                cmd.Parameters.AddWithValue("@ic", mskIc.Text)
'                Dim dbPassword As String = CStr(cmd.ExecuteScalar())
'                Dim userInputPassword As String = txtPassword.Text
'                If dbPassword = userInputPassword Then
'                    Me.Hide()
'                    FrmMemberUpdate.Show()
'                Else
'                    MessageBox.Show("Member not found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
'                End If

'            End Using
'        End Using

'    End Sub

'    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
'        Me.Hide()
'        FrmMemberUpdate.Show()
'    End Sub

'    Private Sub FrmConfirmMember_Load(sender As Object, e As EventArgs) Handles MyBase.Load

'    End Sub
'End Class