﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AsgFrmGenerateMenuReport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lblUpcomingOrder = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnGenerate = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.rad5 = New System.Windows.Forms.RadioButton()
        Me.rad15 = New System.Windows.Forms.RadioButton()
        Me.rad10 = New System.Windows.Forms.RadioButton()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Assignment.My.Resources.Resources.Island_Cafe_Logo
        Me.PictureBox1.Location = New System.Drawing.Point(313, -1)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(165, 180)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 3
        Me.PictureBox1.TabStop = False
        '
        'lblUpcomingOrder
        '
        Me.lblUpcomingOrder.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUpcomingOrder.Location = New System.Drawing.Point(72, 192)
        Me.lblUpcomingOrder.Name = "lblUpcomingOrder"
        Me.lblUpcomingOrder.Size = New System.Drawing.Size(634, 39)
        Me.lblUpcomingOrder.TabIndex = 23
        Me.lblUpcomingOrder.Text = "GENERATE TOP MENU REPORT"
        Me.lblUpcomingOrder.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(116, 246)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(631, 46)
        Me.Label1.TabIndex = 24
        Me.Label1.Text = "Please select number of orders for menu items for reporting: "
        '
        'btnGenerate
        '
        Me.btnGenerate.BackColor = System.Drawing.Color.MediumTurquoise
        Me.btnGenerate.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGenerate.ForeColor = System.Drawing.Color.Black
        Me.btnGenerate.Location = New System.Drawing.Point(153, 440)
        Me.btnGenerate.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnGenerate.Name = "btnGenerate"
        Me.btnGenerate.Size = New System.Drawing.Size(212, 48)
        Me.btnGenerate.TabIndex = 30
        Me.btnGenerate.Text = "&Generate Report"
        Me.btnGenerate.UseVisualStyleBackColor = False
        '
        'btnCancel
        '
        Me.btnCancel.BackColor = System.Drawing.Color.MediumTurquoise
        Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.ForeColor = System.Drawing.Color.Black
        Me.btnCancel.Location = New System.Drawing.Point(457, 440)
        Me.btnCancel.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(212, 48)
        Me.btnCancel.TabIndex = 31
        Me.btnCancel.Text = "&Cancel"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'rad5
        '
        Me.rad5.Location = New System.Drawing.Point(28, 342)
        Me.rad5.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rad5.Name = "rad5"
        Me.rad5.Size = New System.Drawing.Size(251, 30)
        Me.rad5.TabIndex = 32
        Me.rad5.TabStop = True
        Me.rad5.Text = "Greater than or equals to 5"
        Me.rad5.UseVisualStyleBackColor = True
        '
        'rad15
        '
        Me.rad15.Location = New System.Drawing.Point(546, 342)
        Me.rad15.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rad15.Name = "rad15"
        Me.rad15.Size = New System.Drawing.Size(267, 30)
        Me.rad15.TabIndex = 33
        Me.rad15.TabStop = True
        Me.rad15.Text = "Greater than or equals to 15"
        Me.rad15.UseVisualStyleBackColor = True
        '
        'rad10
        '
        Me.rad10.Location = New System.Drawing.Point(278, 342)
        Me.rad10.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rad10.Name = "rad10"
        Me.rad10.Size = New System.Drawing.Size(262, 30)
        Me.rad10.TabIndex = 34
        Me.rad10.TabStop = True
        Me.rad10.Text = "Greater than or equals to 10"
        Me.rad10.UseVisualStyleBackColor = True
        '
        'AsgFrmGenerateMenuReport
        '
        Me.AcceptButton = Me.btnGenerate
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.CancelButton = Me.btnCancel
        Me.ClientSize = New System.Drawing.Size(800, 539)
        Me.Controls.Add(Me.rad10)
        Me.Controls.Add(Me.rad15)
        Me.Controls.Add(Me.rad5)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnGenerate)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblUpcomingOrder)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MaximizeBox = False
        Me.Name = "AsgFrmGenerateMenuReport"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Generate Menu Report"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents lblUpcomingOrder As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents btnGenerate As Button
    Friend WithEvents btnCancel As Button
    Friend WithEvents rad5 As RadioButton
    Friend WithEvents rad10 As RadioButton
    Friend WithEvents rad15 As RadioButton
End Class
