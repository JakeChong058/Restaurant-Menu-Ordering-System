﻿Imports System.Data.SqlClient
Imports System.Text
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class AsgFrmOrderReport
    'Private intCustNo = 1001
    'Friend strParts() As String
    Private da As SqlDataAdapter
    Private ds As DataSet = New DataSet()
    Private decTotal As Decimal
    Private decSubtotal As Decimal
    Private decMax As Decimal
    Private decMin As Decimal
    Private strDate As String
    Private orders() As FoodOrder
    Private maxOrder As FoodOrder
    Private minOrder As FoodOrder
    'Friend order As OrderList
    'Friend intOrderNumber As Integer
    'Private orders() As OrderList
    'Private menus() As CustMenuItems
    'The default order number
    'Private intOrderNo As Integer = 1001
    'Private intRowIndex As Integer = -2
    'Private viewButtonCol As New DataGridViewButtonColumn
    'Private updateButtonCol As New DataGridViewButtonColumn
    'Private paymentButtonCol As New DataGridViewButtonColumn
    Private Sub AsgFrmOrderReport_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        AsgFrmStaffCompleteOrder.Hide()
        Dim strSql As String
        Dim intReceiveCount As Integer = 0
        Dim intPrepareCount As Integer = 0
        Dim intReadyCount As Integer = 0
        Dim intCashCount As Integer = 0
        Dim intCreditCount As Integer = 0
        Dim MSSqlCommand As SqlCommand
        strDate = Date.Now
        'Dim statusCboCol As DataGridViewComboBoxColumn = New DataGridViewComboBoxColumn
        If StartConnection() = True Then
            strSql = "Select Order_No, Date, Total_Items, Payment_Method, Subtotal, Food_Amount From Food_Order WHERE Status = 'Completed' AND Order_Date BETWEEN @from AND @to"
            MSSqlCommand = New SqlCommand(strSql, connection)
            MSSqlCommand.Parameters.AddWithValue("@from", AsgFrmGenerateReport.dtpFrom.Value)
            MSSqlCommand.Parameters.AddWithValue("@to", AsgFrmGenerateReport.dtpTo.Value)
            'Console.WriteLine(strSql)
            da = New SqlDataAdapter(MSSqlCommand)
            'da.Pa
            ds.Clear()
            Try
                da.Fill(ds, "Food_Order")
            Catch ex As Exception
                'do something
            End Try
            'ReDim orders(ds.Tables("Food_Order").Rows.Count - 1)
            'ReDim menus(ds.Tables("Food_Order").Rows.Count - 1)
            If ds.Tables("Food_Order").Rows.Count > 0 Then
                ReDim orders(ds.Tables("Food_Order").Rows.Count - 1)
                For intIndex = 0 To orders.Length - 1 Step 1
                    orders(intIndex) = New FoodOrder(ds.Tables("Food_Order").Rows(intIndex).Item(0),
                    ds.Tables("Food_Order").Rows(intIndex).Item(1).ToString(), ds.Tables("Food_Order").Rows(intIndex).Item(2),
                    ds.Tables("Food_Order").Rows(intIndex).Item(3), ds.Tables("Food_Order").Rows(intIndex).Item(4),
                    ds.Tables("Food_Order").Rows(intIndex).Item(5))
                Next intIndex
                DataGridView1.DataSource = ds.Tables("Food_Order")
                'DataGridView1.ColumnHeadersDefaultCellStyle.BackColor = Color.Black
                'DataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White
                'DataGridView1.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.Black
                'DataGridView1.ColumnHeadersDefaultCellStyle.SelectionForeColor = Color.White
                DataGridView1.Columns(0).HeaderText = "Order ID"
                DataGridView1.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(0).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(0).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(1).HeaderText = "Order Date and Time"
                DataGridView1.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(1).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(1).DefaultCellStyle.SelectionForeColor = Color.Black
                'DataGridView1.Columns(2).HeaderText = "Total Items"
                'DataGridView1.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                'DataGridView1.Columns(2).DefaultCellStyle.SelectionBackColor = Color.White
                'DataGridView1.Columns(2).DefaultCellStyle.SelectionForeColor = Color.Black
                'DataGridView1.Columns(3).HeaderText = "Placed By"
                'DataGridView1.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                'DataGridView1.Columns(3).DefaultCellStyle.SelectionBackColor = Color.White
                'DataGridView1.Columns(3).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(2).HeaderText = "Total Items"
                DataGridView1.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(2).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(2).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(3).HeaderText = "Payment Method"
                DataGridView1.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(3).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(3).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(4).HeaderText = "Subtotal"
                DataGridView1.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(4).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(4).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(5).HeaderText = "Food Amount"
                DataGridView1.Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(5).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(5).DefaultCellStyle.SelectionForeColor = Color.Black
                decMax = ds.Tables("Food_Order").Rows(0).Item("Food_Amount")
                decMin = ds.Tables("Food_Order").Rows(ds.Tables("Food_Order").Rows.Count - 1).Item("Food_Amount")
                For intIndex = 0 To ds.Tables("Food_Order").Rows.Count - 1 Step 1
                    decSubtotal += ds.Tables("Food_Order").Rows(intIndex).Item("Subtotal")
                    decTotal += ds.Tables("Food_Order").Rows(intIndex).Item("Food_Amount")

                    If ds.Tables("Food_Order").Rows(intIndex).Item("Food_Amount") > decMax Then
                        decMax = ds.Tables("Food_Order").Rows(intIndex).Item("Food_Amount")
                    End If

                    If ds.Tables("Food_Order").Rows(intIndex).Item("Food_Amount") < decMin Then
                        decMin = ds.Tables("Food_Order").Rows(intIndex).Item("Food_Amount")
                    End If
                Next intIndex
                'statusCboCol.HeaderText = "Update Order Status"
                'For intCount = 0 To ds.Tables("Food_Order").Rows.Count - 1 Step 1
                '    If ds.Tables("Food_Order").Rows(intCount).Item("Status") = "Received" Then
                '        statusCboCol.Items.Add("Received")
                '        statusCboCol.Items.Add("Preparing")
                '        'AddHandler 
                '    ElseIf ds.Tables("Food_Order").Rows(intCount).Item("Status") = "Preparing" Then
                '        statusCboCol.Items.Add("Received")
                '        statusCboCol.Items.Add("Preparing")
                '        statusCboCol.Items.Add("Ready")
                '    End If
                'Next intCount
                'DataGridView1.Columns.Add(statusCboCol)

                'Console.WriteLine(statusCboCol.Items.Count & vbTab & statusCboCol.Items(0) & vbTab & statusCboCol.Items(1))
                'buttonCol.BackColor = Color.MediumTurquoise
                lblTransaction.Text = ds.Tables("Food_Order").Rows.Count.ToString() & " transaction(s)"
                lblSubtotal.Text = "RM" & decSubtotal.ToString()
                lblTotal.Text = "RM" & decTotal.ToString()
                lblDate.Text = "FROM " & AsgFrmGenerateReport.dtpFrom.Value & " TO " & AsgFrmGenerateReport.dtpTo.Value                'lblCash.Text = intCashCount.ToString()
                'lblCredit.Text = intCashCount.ToString()
            End If
            EndConnection()
        End If
        If StartConnection() = True Then
            Dim dataSets As DataSet = New DataSet()
            strSql = "Select Order_No, Date, Total_Items, Payment_Method, Subtotal, Food_Amount From Food_Order WHERE Status = 'Completed' AND Food_Amount = " & decMax 'AND Order_Date BETWEEN " & AsgFrmGenerateReport.dtpFrom.Value.Date & " AND " & AsgFrmGenerateReport.dtpTo.Value.Date
            'Console.WriteLine(strSql)
            da = New SqlDataAdapter(strSql, connection)
            'da.Pa
            dataSets.Clear()
            Try
                da.Fill(dataSets, "Food_Order")
            Catch ex As Exception
                'do something
            End Try
            'ReDim orders(ds.Tables("Food_Order").Rows.Count - 1)
            'ReDim menus(ds.Tables("Food_Order").Rows.Count - 1)
            If dataSets.Tables("Food_Order").Rows.Count > 0 Then
                maxOrder = New FoodOrder(dataSets.Tables("Food_Order").Rows(0).Item(0),
                    dataSets.Tables("Food_Order").Rows(0).Item(1).ToString(), dataSets.Tables("Food_Order").Rows(0).Item(2),
                    dataSets.Tables("Food_Order").Rows(0).Item(3), dataSets.Tables("Food_Order").Rows(0).Item(4),
                    dataSets.Tables("Food_Order").Rows(0).Item(5))
                DataGridView2.DataSource = dataSets.Tables("Food_Order")
                'DataGridView1.ColumnHeadersDefaultCellStyle.BackColor = Color.Black
                'DataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White
                'DataGridView1.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.Black
                'DataGridView1.ColumnHeadersDefaultCellStyle.SelectionForeColor = Color.White
                DataGridView2.Columns(0).HeaderText = "Order ID"
                DataGridView2.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView2.Columns(0).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView2.Columns(0).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView2.Columns(1).HeaderText = "Order Date and Time"
                DataGridView2.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView2.Columns(1).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView2.Columns(1).DefaultCellStyle.SelectionForeColor = Color.Black
                'DataGridView1.Columns(2).HeaderText = "Total Items"
                'DataGridView1.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                'DataGridView1.Columns(2).DefaultCellStyle.SelectionBackColor = Color.White
                'DataGridView1.Columns(2).DefaultCellStyle.SelectionForeColor = Color.Black
                'DataGridView1.Columns(3).HeaderText = "Placed By"
                'DataGridView1.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                'DataGridView1.Columns(3).DefaultCellStyle.SelectionBackColor = Color.White
                'DataGridView1.Columns(3).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView2.Columns(2).HeaderText = "Total Items"
                DataGridView2.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView2.Columns(2).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView2.Columns(2).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView2.Columns(3).HeaderText = "Payment Method"
                DataGridView2.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView2.Columns(3).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView2.Columns(3).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView2.Columns(4).HeaderText = "Subtotal"
                DataGridView2.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView2.Columns(4).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView2.Columns(4).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView2.Columns(5).HeaderText = "Food Amount"
                DataGridView2.Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView2.Columns(5).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView2.Columns(5).DefaultCellStyle.SelectionForeColor = Color.Black
            End If
            EndConnection()
        End If
        If StartConnection() = True Then
            Dim dataSetss As DataSet = New DataSet()
            strSql = "Select Order_No, Date, Total_Items, Payment_Method, Subtotal, Food_Amount From Food_Order WHERE Status = 'Completed' AND Food_Amount = " & decMin 'AND Order_Date BETWEEN " & AsgFrmGenerateReport.dtpFrom.Value.Date & " AND " & AsgFrmGenerateReport.dtpTo.Value.Date
            'Console.WriteLine(strSql)
            da = New SqlDataAdapter(strSql, connection)
            'da.Pa
            dataSetss.Clear()
            Try
                da.Fill(dataSetss, "Food_Order")
            Catch ex As Exception
                'do something
            End Try
            'ReDim orders(ds.Tables("Food_Order").Rows.Count - 1)
            'ReDim menus(ds.Tables("Food_Order").Rows.Count - 1)
            If dataSetss.Tables("Food_Order").Rows.Count > 0 Then
                minOrder = New FoodOrder(dataSetss.Tables("Food_Order").Rows(0).Item(0),
                    dataSetss.Tables("Food_Order").Rows(0).Item(1).ToString(), dataSetss.Tables("Food_Order").Rows(0).Item(2),
                    dataSetss.Tables("Food_Order").Rows(0).Item(3), dataSetss.Tables("Food_Order").Rows(0).Item(4),
                    dataSetss.Tables("Food_Order").Rows(0).Item(5))
                DataGridView3.DataSource = dataSetss.Tables("Food_Order")
                'DataGridView1.ColumnHeadersDefaultCellStyle.BackColor = Color.Black
                'DataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White
                'DataGridView1.ColumnHeadersDefaultCellStyle.SelectionBackColor = Color.Black
                'DataGridView1.ColumnHeadersDefaultCellStyle.SelectionForeColor = Color.White
                DataGridView3.Columns(0).HeaderText = "Order ID"
                DataGridView3.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView3.Columns(0).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView3.Columns(0).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView3.Columns(1).HeaderText = "Order Date and Time"
                DataGridView3.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView3.Columns(1).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView3.Columns(1).DefaultCellStyle.SelectionForeColor = Color.Black
                'DataGridView1.Columns(2).HeaderText = "Total Items"
                'DataGridView1.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                'DataGridView1.Columns(2).DefaultCellStyle.SelectionBackColor = Color.White
                'DataGridView1.Columns(2).DefaultCellStyle.SelectionForeColor = Color.Black
                'DataGridView1.Columns(3).HeaderText = "Placed By"
                'DataGridView1.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                'DataGridView1.Columns(3).DefaultCellStyle.SelectionBackColor = Color.White
                'DataGridView1.Columns(3).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView3.Columns(2).HeaderText = "Total Items"
                DataGridView3.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView3.Columns(2).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView3.Columns(2).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView3.Columns(3).HeaderText = "Payment Method"
                DataGridView3.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView3.Columns(3).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView3.Columns(3).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView3.Columns(4).HeaderText = "Subtotal"
                DataGridView3.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView3.Columns(4).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView3.Columns(4).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView3.Columns(5).HeaderText = "Food Amount"
                DataGridView3.Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView3.Columns(5).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView3.Columns(5).DefaultCellStyle.SelectionForeColor = Color.Black
            End If
            EndConnection()
        End If
        'If StartConnection() = True Then
        '    Dim dataSet As DataSet = New DataSet()
        '    strSql = "Select Status From Food_Order WHERE Status = 'Received'"
        '    da = New SqlDataAdapter(strSql, connection)
        '    dataSet.Clear()
        '    Try
        '        da.Fill(dataSet, "Food_Order")
        '    Catch ex As Exception
        '        'do something
        '    End Try
        '    'ReDim orders(ds.Tables("Food_Order").Rows.Count - 1)
        '    'ReDim menus(ds.Tables("Food_Order").Rows.Count - 1)
        '    lblReceived.Text = dataSet.Tables("Food_Order").Rows.Count.ToString()
        '    EndConnection()
        'End If
        'If StartConnection() = True Then
        '    Dim dataSet2 As DataSet = New DataSet()
        '    strSql = "Select Status From Food_Order WHERE Status = 'Preparing'"
        '    da = New SqlDataAdapter(strSql, connection)
        '    dataSet2.Clear()
        '    Try
        '        da.Fill(dataSet2, "Food_Order")
        '    Catch ex As Exception
        '        'do something
        '    End Try
        '    'ReDim orders(ds.Tables("Food_Order").Rows.Count - 1)
        '    'ReDim menus(ds.Tables("Food_Order").Rows.Count - 1)
        '    lblPreparing.Text = dataSet2.Tables("Food_Order").Rows.Count.ToString()
        '    EndConnection()
        'End If
        'If StartConnection() = True Then
        '    Dim dataSet3 As DataSet = New DataSet()
        '    strSql = "Select Status From Food_Order WHERE Status = 'Ready'"
        '    da = New SqlDataAdapter(strSql, connection)
        '    dataSet3.Clear()
        '    Try
        '        da.Fill(dataSet3, "Food_Order")
        '    Catch ex As Exception
        '        'do something
        '    End Try
        '    'ReDim orders(ds.Tables("Food_Order").Rows.Count - 1)
        '    'ReDim menus(ds.Tables("Food_Order").Rows.Count - 1)
        '    lblReady.Text = dataSet3.Tables("Food_Order").Rows.Count.ToString()
        '    EndConnection()
        'End If
        'If StartConnection() = True Then
        '    Dim dataSet4 As DataSet = New DataSet()
        '    strSql = "Select Payment_Method From Food_Order WHERE Payment_Method = 'Pay by Cash'"
        '    da = New SqlDataAdapter(strSql, connection)
        '    ds.Clear()
        '    Try
        '        da.Fill(dataSet4, "Food_Order")
        '    Catch ex As Exception
        '        'do something
        '    End Try
        '    'ReDim orders(ds.Tables("Food_Order").Rows.Count - 1)
        '    'ReDim menus(ds.Tables("Food_Order").Rows.Count - 1)
        '    lblCash.Text = dataSet4.Tables("Food_Order").Rows.Count.ToString()
        '    EndConnection()
        'End If
        'If StartConnection() = True Then
        '    Dim dataSet5 As DataSet = New DataSet()
        '    strSql = "Select Status From Food_Order WHERE Payment_Method = 'Pay by Credit Card'"
        '    da = New SqlDataAdapter(strSql, connection)
        '    dataSet5.Clear()
        '    Try
        '        da.Fill(dataSet5, "Food_Order")
        '    Catch ex As Exception
        '        'do something
        '    End Try
        '    'ReDim orders(ds.Tables("Food_Order").Rows.Count - 1)
        '    'ReDim menus(ds.Tables("Food_Order").Rows.Count - 1)
        '    lblCredit.Text = dataSet5.Tables("Food_Order").Rows.Count.ToString()
        '    EndConnection()
        'End If
    End Sub

    Private Sub mnuFileClose_Click(sender As Object, e As EventArgs) Handles mnuFileClose.Click
        Me.Close()
        'AsgFrmStaffCompleteOrder.Show()
    End Sub
    'End Sub

    Private Sub AsgFrmOrderReport_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        'AsgFrmStaffCompleteOrder.Show()
        AsgFrmGenerateReport.Show()
    End Sub

    Private Sub mnuAbout_Click(sender As Object, e As EventArgs) Handles mnuAbout.Click
        MessageBox.Show("Report generated at " & strDate, "About", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub doc_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles doc.PrintPage
        'e.HasMorePages = True
        Dim fntHeader As New Font("Calibri", 24, FontStyle.Bold)
        Dim fntSubHeader As New Font("Calibri", 18)
        Dim fntSubHeaderAddress As New Font("Calibri", 14)
        'Dim fntEndOfReport As New Font("Calibri", 14)
        Dim fntBody As New Font("Consolas", 10)
        Dim strHeader As String = " ORDER TRANSACTION REPORT" & vbNewLine & "FROM " & AsgFrmGenerateReport.dtpFrom.Value & " TO " & AsgFrmGenerateReport.dtpTo.Value
        'Dim strSubHeader As String = String.Format("Printed on {0:dd-MMMM-yyyy hh:mm:ss tt}" & vbNewLine & "Prepared by SOMEBODY", DateTime.Now)
        Dim strSubHeader As String = " Island Cafe Inc."
        Dim strSubHeaderAddress As String = "Cyber Centre, KL, Main Campus" & vbNewLine & "  Jalan Genting Kelang Setapak"
        'Dim strEndOfReport As String = "*********************************************************************************" & vbNewLine & vbTab & vbTab & vbTab & vbTab & "This is a Computer-Generated Report" & vbNewLine & "*********************************************************************************"
        'Dim strEndOfReport As String = "-------- --------------------- ----------- -------------- -------- --------------"
        Dim body As New StringBuilder()
        body.AppendLine("TRANSACTIONS:")
        body.AppendLine("------------")
        body.AppendLine()
        body.AppendLine("Order ID  Order Date and Time  Total Items   Payment Method    Subtotal Payment Amount")
        body.AppendLine("-------- --------------------- ----------- ------------------- -------- --------------")
        'Dim intCount As Integer = 0
        'Dim strParts() As String
        For intIndex = 0 To orders.Length - 1 Step 1
            'intCount += 1
            'strParts = CStr(item).Split(CChar(vbTab))
            If orders(intIndex).GetStrPaymentMethod() = "Pay by Credit Card" Then
                If orders(intIndex).GetDecSubTotal().ToString().Length = 5 Then
                    body.AppendFormat("  {0}   {1}       {2}       {3} {4}    {5}" & vbNewLine,
                    orders(intIndex).GetIntOrderNo().ToString(), orders(intIndex).GetStrDate(),
                    orders(intIndex).GetIntTotalItems().ToString(), orders(intIndex).GetStrPaymentMethod(),
                    orders(intIndex).GetDecSubTotal().ToString(), orders(intIndex).GetDecFoodAmount().ToString())
                ElseIf orders(intIndex).GetDecSubTotal().ToString().Length = 4 Then
                    body.AppendFormat("  {0}   {1}       {2}       {3} {4}     {5}" & vbNewLine,
                    orders(intIndex).GetIntOrderNo().ToString(), orders(intIndex).GetStrDate(),
                    orders(intIndex).GetIntTotalItems().ToString(), orders(intIndex).GetStrPaymentMethod(),
                    orders(intIndex).GetDecSubTotal().ToString(), orders(intIndex).GetDecFoodAmount().ToString())
                Else
                    body.AppendFormat("  {0}   {1}       {2}       {3} {4}   {5}" & vbNewLine,
                    orders(intIndex).GetIntOrderNo().ToString(), orders(intIndex).GetStrDate(),
                    orders(intIndex).GetIntTotalItems().ToString(), orders(intIndex).GetStrPaymentMethod(),
                    orders(intIndex).GetDecSubTotal().ToString(), orders(intIndex).GetDecFoodAmount().ToString())
                End If
            Else
                If orders(intIndex).GetDecSubTotal().ToString().Length = 5 Then
                    body.AppendFormat("  {0}   {1}       {2}       {3}        {4}    {5}" & vbNewLine,
                    orders(intIndex).GetIntOrderNo().ToString(), orders(intIndex).GetStrDate(),
                    orders(intIndex).GetIntTotalItems().ToString(), orders(intIndex).GetStrPaymentMethod(),
                    orders(intIndex).GetDecSubTotal().ToString(), orders(intIndex).GetDecFoodAmount().ToString())
                ElseIf orders(intIndex).GetDecSubTotal().ToString().Length = 4 Then
                    body.AppendFormat("  {0}   {1}       {2}       {3}        {4}     {5}" & vbNewLine,
                    orders(intIndex).GetIntOrderNo().ToString(), orders(intIndex).GetStrDate(),
                    orders(intIndex).GetIntTotalItems().ToString(), orders(intIndex).GetStrPaymentMethod(),
                    orders(intIndex).GetDecSubTotal().ToString(), orders(intIndex).GetDecFoodAmount().ToString())
                Else
                    body.AppendFormat("  {0}   {1}       {2}       {3}        {4}   {5}" & vbNewLine,
                    orders(intIndex).GetIntOrderNo().ToString(), orders(intIndex).GetStrDate(),
                    orders(intIndex).GetIntTotalItems().ToString(), orders(intIndex).GetStrPaymentMethod(),
                    orders(intIndex).GetDecSubTotal().ToString(), orders(intIndex).GetDecFoodAmount().ToString())
                End If
            End If


        Next intIndex
        body.AppendLine(vbTab & vbTab & vbTab & vbTab & vbTab & vbTab & vbTab & vbTab & "       -------- --------------")
        body.AppendFormat("{0}" & vbTab & vbTab & vbTab & vbTab & vbTab & "    TOTALS: {1} {2}", lblTransaction.Text, lblSubtotal.Text, lblTotal.Text)
        body.AppendLine()
        body.AppendLine()
        body.AppendLine()
        body.AppendLine()
        body.AppendLine("ORDER WITH THE HIGHEST PAYMENT AMOUNT:") 'Order With The Highest Payment Amount
        body.AppendLine("--------------------------------------")
        body.AppendLine()
        body.AppendLine("Order ID  Order Date and Time  Total Items   Payment Method    Subtotal Payment Amount")
        body.AppendLine("-------- --------------------- ----------- ------------------- -------- --------------")
        'Dim intCount As Integer = 0
        'Dim strParts() As String
        'For intIndex = 0 To orders.Length - 1 Step 1
        'intCount += 1
        'strParts = CStr(item).Split(CChar(vbTab))
        If maxOrder.GetStrPaymentMethod() = "Pay by Credit Card" Then
            If maxOrder.GetDecSubTotal().ToString().Length = 5 Then
                body.AppendFormat("  {0}   {1}       {2}       {3} {4}    {5}" & vbNewLine,
                    maxOrder.GetIntOrderNo().ToString(), maxOrder.GetStrDate(),
                    maxOrder.GetIntTotalItems().ToString(), maxOrder.GetStrPaymentMethod(),
                    maxOrder.GetDecSubTotal().ToString(), maxOrder.GetDecFoodAmount().ToString())
            ElseIf maxOrder.GetDecSubTotal().ToString().Length = 4 Then
                body.AppendFormat("  {0}   {1}       {2}       {3} {4}     {5}" & vbNewLine,
                    maxOrder.GetIntOrderNo().ToString(), maxOrder.GetStrDate(),
                    maxOrder.GetIntTotalItems().ToString(), maxOrder.GetStrPaymentMethod(),
                    maxOrder.GetDecSubTotal().ToString(), maxOrder.GetDecFoodAmount().ToString())
            Else
                body.AppendFormat("  {0}   {1}       {2}       {3} {4}   {5}" & vbNewLine,
                    maxOrder.GetIntOrderNo().ToString(), maxOrder.GetStrDate(),
                    maxOrder.GetIntTotalItems().ToString(), maxOrder.GetStrPaymentMethod(),
                    maxOrder.GetDecSubTotal().ToString(), maxOrder.GetDecFoodAmount().ToString())
            End If
        Else
            If maxOrder.GetDecSubTotal().ToString().Length = 5 Then
                body.AppendFormat("  {0}   {1}       {2}       {3}        {4}    {5}" & vbNewLine,
                    maxOrder.GetIntOrderNo().ToString(), maxOrder.GetStrDate(),
                    maxOrder.GetIntTotalItems().ToString(), maxOrder.GetStrPaymentMethod(),
                    maxOrder.GetDecSubTotal().ToString(), maxOrder.GetDecFoodAmount().ToString())
            ElseIf maxOrder.GetDecSubTotal().ToString().Length = 4 Then
                body.AppendFormat("  {0}   {1}       {2}       {3}        {4}     {5}" & vbNewLine,
                    maxOrder.GetIntOrderNo().ToString(), maxOrder.GetStrDate(),
                    maxOrder.GetIntTotalItems().ToString(), maxOrder.GetStrPaymentMethod(),
                    maxOrder.GetDecSubTotal().ToString(), maxOrder.GetDecFoodAmount().ToString())
            Else
                body.AppendFormat("  {0}   {1}       {2}       {3}        {4}   {5}" & vbNewLine,
                    maxOrder.GetIntOrderNo().ToString(), maxOrder.GetStrDate(),
                    maxOrder.GetIntTotalItems().ToString(), maxOrder.GetStrPaymentMethod(),
                    maxOrder.GetDecSubTotal().ToString(), maxOrder.GetDecFoodAmount().ToString())
            End If
        End If

        'Next intIndex
        body.AppendLine()
        body.AppendLine()
        body.AppendLine()
        body.AppendLine()
        body.AppendLine("ORDER WITH THE LOWEST PAYMENT AMOUNT:") 'Order With The Highest Payment Amount
        body.AppendLine("--------------------------------------")
        body.AppendLine()
        body.AppendLine("Order ID  Order Date and Time  Total Items   Payment Method    Subtotal Payment Amount")
        body.AppendLine("-------- --------------------- ----------- ------------------- -------- --------------")
        'Dim intCount As Integer = 0
        'Dim strParts() As String
        'For intIndex = 0 To orders.Length - 1 Step 1
        'intCount += 1
        'strParts = CStr(item).Split(CChar(vbTab))
        If minOrder.GetStrPaymentMethod() = "Pay by Credit Card" Then
            If minOrder.GetDecSubTotal().ToString().Length = 5 Then
                body.AppendFormat("  {0}   {1}       {2}       {3} {4}    {5}" & vbNewLine,
                    minOrder.GetIntOrderNo().ToString(), minOrder.GetStrDate(),
                    minOrder.GetIntTotalItems().ToString(), minOrder.GetStrPaymentMethod(),
                    minOrder.GetDecSubTotal().ToString(), minOrder.GetDecFoodAmount().ToString())
            ElseIf minOrder.GetDecSubTotal().ToString().Length = 4 Then
                body.AppendFormat("  {0}   {1}       {2}       {3} {4}     {5}" & vbNewLine,
                    minOrder.GetIntOrderNo().ToString(), minOrder.GetStrDate(),
                    minOrder.GetIntTotalItems().ToString(), minOrder.GetStrPaymentMethod(),
                    minOrder.GetDecSubTotal().ToString(), minOrder.GetDecFoodAmount().ToString())
            Else
                body.AppendFormat("  {0}   {1}       {2}       {3} {4}   {5}" & vbNewLine,
                    minOrder.GetIntOrderNo().ToString(), minOrder.GetStrDate(),
                    minOrder.GetIntTotalItems().ToString(), minOrder.GetStrPaymentMethod(),
                    minOrder.GetDecSubTotal().ToString(), minOrder.GetDecFoodAmount().ToString())
            End If
        Else
            If minOrder.GetDecSubTotal().ToString().Length = 5 Then
                body.AppendFormat("  {0}   {1}       {2}       {3}        {4}    {5}" & vbNewLine,
                    minOrder.GetIntOrderNo().ToString(), minOrder.GetStrDate(),
                    minOrder.GetIntTotalItems().ToString(), minOrder.GetStrPaymentMethod(),
                    minOrder.GetDecSubTotal().ToString(), minOrder.GetDecFoodAmount().ToString())
            ElseIf minOrder.GetDecSubTotal().ToString().Length = 4 Then
                body.AppendFormat("  {0}   {1}       {2}       {3}        {4}     {5}" & vbNewLine,
                    minOrder.GetIntOrderNo().ToString(), minOrder.GetStrDate(),
                    minOrder.GetIntTotalItems().ToString(), minOrder.GetStrPaymentMethod(),
                    minOrder.GetDecSubTotal().ToString(), minOrder.GetDecFoodAmount().ToString())
            Else
                body.AppendFormat("  {0}   {1}       {2}       {3}        {4}   {5}" & vbNewLine,
                    minOrder.GetIntOrderNo().ToString(), minOrder.GetStrDate(),
                    minOrder.GetIntTotalItems().ToString(), minOrder.GetStrPaymentMethod(),
                    minOrder.GetDecSubTotal().ToString(), minOrder.GetDecFoodAmount().ToString())
            End If
        End If
        body.AppendLine()
        body.AppendLine()
        body.AppendLine()
        body.AppendLine()
        body.AppendLine("**************************************************************************************" & vbNewLine & vbNewLine & vbTab & vbTab & vbTab & vbTab & vbTab & " END OF REPORT" & vbNewLine & vbTab & vbTab & vbTab & "     This is a Computer-Generated Report" & vbNewLine & vbNewLine & "**************************************************************************************")
        '-------- --------------------- ----------- ------------------- -------- --------------
        With e.Graphics
            .DrawImage(My.Resources.Island_Cafe_Logo, 250, 0, 165, 180)
            .DrawString(strHeader, fntHeader, Brushes.Blue, 100, 270)
            .DrawString(strSubHeader, fntSubHeader, Brushes.Black, 250, 190)
            .DrawString(strSubHeaderAddress, fntSubHeaderAddress, Brushes.Black, 205, 220)
            .DrawString(body.ToString(), fntBody, Brushes.Black, 0, 360)
        End With
    End Sub

    Private Sub mnuFilePrint_Click(sender As Object, e As EventArgs) Handles mnuFilePrint.Click
        dlgPreview.Document = doc
        dlgPreview.ShowDialog(Me)
    End Sub
End Class