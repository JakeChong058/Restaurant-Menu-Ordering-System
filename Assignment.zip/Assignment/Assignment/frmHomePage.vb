﻿Public Class frmHomePage
    Private Sub frmHomePage_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblAboutUs.Text = "About Us" & vbNewLine & vbNewLine & "We provide a place where our customers can rest. We wish our customers eat well, drink well, and relax."
    End Sub

    Private Sub lblGetStarted_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub lblStaffLogin_Click(sender As Object, e As EventArgs) Handles lblStaffLogin.Click
        Me.Hide()
        frmStaffLoginPage.Show()
    End Sub

    Private Sub frmHomePage_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        MessageBox.Show("System is terminating...Goodbye", "SYSTEM CLOSE", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub lblClose_Click(sender As Object, e As EventArgs) Handles lblClose.Click
        Me.Close()
    End Sub
End Class
