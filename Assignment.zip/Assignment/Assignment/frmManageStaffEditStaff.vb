﻿Imports System.Data.SqlClient
Imports Microsoft.VisualBasic.ApplicationServices

Public Class frmManageStaffEditStaff
    Private da As SqlDataAdapter
    Private ds As DataSet = New DataSet()
    Private Sub frmManageStaffEditStaff_Load(sender As Object, e As EventArgs) Handles MyBase.Load ', Me.Shown
        Dim strSql As String
        StaffData.ConnectServer()
        lblID.Text = frmManageStaff.strEditStaffID
        lblName.Text = frmManageStaff.strEditStaffName
        cboPosition.SelectedItem = frmManageStaff.strEditStaffPosition
        cboStatus.SelectedItem = frmManageStaff.strEditStaffStatus
        If cboStatus.SelectedItem = "Available" Then
            lblReason.Visible = False
            cboReason.Visible = False
            cboReason.SelectedItem = ""
        Else
            lblReason.Visible = True
            cboReason.Visible = True
            If StartConnection() = True Then
                strSql = "Select Reason From Staff Where Staff_Id='" & lblID.Text & "'"
                da = New SqlDataAdapter(strSql, connection)
                ds.Clear()
                Try
                    da.Fill(ds, "Staff")
                Catch ex As Exception
                End Try
                If ds.Tables("Staff").Rows.Count > 0 Then
                    cboReason.SelectedItem = ds.Tables("Staff").Rows(0).Item("Reason")
                End If
                EndConnection()
            End If
        End If
    End Sub

    'Private Sub frmManageStaffEditStaff_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
    '    frmManageStaff.Show()
    'End Sub
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click, MyBase.Closed
        Me.Close()
    End Sub

    Private Sub cboStatus_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles cboStatus.Validating
        If cboStatus.SelectedIndex = -1 Then
            errCheck.SetError(cboStatus, "Please determine the status of the staff")
            e.Cancel = True
        Else
            errCheck.SetError(cboStatus, Nothing)
        End If
    End Sub

    Private Sub cboPosition_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles cboPosition.Validating
        If cboPosition.SelectedIndex = -1 Then
            errCheck.SetError(cboPosition, "Please select the position of the staff")
            e.Cancel = True
        Else
            errCheck.SetError(cboPosition, Nothing)
        End If
    End Sub

    Private Sub cboReason_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles cboReason.Validating
        If cboReason.Visible = True Then
            If cboReason.SelectedIndex = -1 Then
                errCheck.SetError(cboReason, "Please provide the reason of why the staff is not available")
                e.Cancel = True
            Else
                errCheck.SetError(cboReason, Nothing)
            End If
        End If
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        'Dim strErrorMsg As String = ""
        If Me.ValidateChildren() = False Then
            Return
        Else
            Dim strSQLStatement As String
            Dim MSSqlCommand As New SqlCommand

            If cboStatus.SelectedItem = "Available" Then
                If StartConnection() = True Then
                    strSQLStatement = "Update Staff set Position=@position, Status=@status where Staff_Id=@ID"
                    MSSqlCommand = New SqlCommand(strSQLStatement, connection)
                    MSSqlCommand.Parameters.AddWithValue("@ID", lblID.Text)
                    MSSqlCommand.Parameters.AddWithValue("@position", cboPosition.SelectedItem)
                    MSSqlCommand.Parameters.AddWithValue("@status", cboStatus.SelectedItem)
                    MSSqlCommand.ExecuteNonQuery()
                    EndConnection()
                    MessageBox.Show("Staff record of [" & lblID.Text & "] " & lblName.Text & " has been updated", "Staff Update Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    frmManageStaff.mnuAll_Click(Nothing, Nothing)
                    Me.Close()
                End If
            Else
                If StartConnection() = True Then
                    strSQLStatement = "Update Staff set Position=@position, Status=@status, Reason=@reason where Staff_Id=@ID"
                    MSSqlCommand = New SqlCommand(strSQLStatement, connection)
                    MSSqlCommand.Parameters.AddWithValue("@ID", lblID.Text)
                    MSSqlCommand.Parameters.AddWithValue("@position", cboPosition.SelectedItem)
                    MSSqlCommand.Parameters.AddWithValue("@status", cboStatus.SelectedItem)
                    MSSqlCommand.Parameters.AddWithValue("@reason", cboReason.SelectedItem)
                    MSSqlCommand.ExecuteNonQuery()
                    EndConnection()
                    MessageBox.Show("Staff record of [" & lblID.Text & "] " & lblName.Text & " has been updated", "Staff Update Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    frmManageStaff.mnuAll_Click(Nothing, Nothing)
                    Me.Close()
                End If
            End If

        End If
    End Sub

    Private Sub cboStatus_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboStatus.SelectedIndexChanged
        Dim strSql As String
        If cboStatus.SelectedItem = "Available" Then
            lblReason.Visible = False
            cboReason.Visible = False
            cboReason.SelectedItem = ""
        Else
            lblReason.Visible = True
            cboReason.Visible = True
            If StartConnection() = True Then
                strSql = "Select Reason From Staff Where Staff_Id='" & lblID.Text & "'"
                da = New SqlDataAdapter(strSql, connection)
                ds.Clear()
                Try
                    da.Fill(ds, "Staff")
                Catch ex As Exception
                End Try
                If ds.Tables("Staff").Rows.Count > 0 Then
                    cboReason.SelectedItem = ds.Tables("Staff").Rows(0).Item("Reason")
                End If
                EndConnection()
            End If
        End If
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        cboPosition.SelectedIndex = 0
        cboStatus.SelectedIndex = 0
        If cboReason.Visible = True Then
            cboReason.SelectedIndex = 0
        End If
        errCheck.Clear()
    End Sub
End Class