﻿Imports System.Data.SqlClient

Public Class AsgFrmStaffCompleteOrder
    Friend intOrderNumber As Integer
    'Private intCustNo = 1001
    'Friend strParts() As String
    Private da As SqlDataAdapter
    Private ds As DataSet = New DataSet()
    'Private strMethod() As String
    'Private blnIsFromCurrent As Boolean = False
    'Friend order As OrderList
    'Private orders() As OrderList
    'Private menus() As CustMenuItems
    'The default order number
    'Private intOrderNo As Integer = 1001

    'Friend Sub IsFromCurrent()
    '    blnIsFromCurrent = True
    'End Sub
    Friend Sub AsgFrmStaffCompleteOrder_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim strSql As String
        'Dim viewButtonCol As New DataGridViewButtonColumn
        Dim receiptButtonCol As New DataGridViewButtonColumn
        DataGridView1.Columns.Clear()
        DataGridView1.DataSource = ""
        If StartConnection() = True Then
            strSql = "Select O.Order_No, O.Date, O.Total_Items, S.Staff_Name, O.Status, O.Payment_Method From Food_Order O, Customer C, Staff S WHERE O.Cust_No = C.Cust_No AND O.Staff_Id = S.Staff_Id AND O.Status = 'Completed'"
            da = New SqlDataAdapter(strSql, connection)
            ds.Clear()
            Try
                da.Fill(ds, "Food_Order")
            Catch ex As Exception
                'do something
            End Try
            'ReDim orders(ds.Tables("Food_Order").Rows.Count - 1)
            'ReDim menus(ds.Tables("Food_Order").Rows.Count - 1)
            If ds.Tables("Food_Order").Rows.Count > 0 Then
                DataGridView1.DataSource = ds.Tables("Food_Order")
                'DataGridView1.Columns.Add(viewButtonCol)
                DataGridView1.Columns.Add(receiptButtonCol)
                'DataGridView1.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(0).HeaderText = "Order ID"
                DataGridView1.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(0).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(0).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(1).HeaderText = "Order Date and Time"
                DataGridView1.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(1).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(1).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(2).HeaderText = "Total Items"
                DataGridView1.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(2).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(2).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(3).HeaderText = "Handled By"
                DataGridView1.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(3).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(3).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(4).HeaderText = "Status"
                DataGridView1.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(4).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(4).DefaultCellStyle.SelectionForeColor = Color.Black
                DataGridView1.Columns(5).HeaderText = "Payment Method"
                DataGridView1.Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                DataGridView1.Columns(5).DefaultCellStyle.SelectionBackColor = Color.White
                DataGridView1.Columns(5).DefaultCellStyle.SelectionForeColor = Color.Black
                'viewButtonCol.HeaderText = "View Order List"
                'viewButtonCol.Text = "View Order Items"
                receiptButtonCol.HeaderText = "Receipt"
                receiptButtonCol.Text = "View Receipt"
                'buttonCol.BackColor = Color.MediumTurquoise
                'viewButtonCol.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 10, FontStyle.Bold)
                'viewButtonCol.UseColumnTextForButtonValue = True
                'viewButtonCol.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                'viewButtonCol.FlatStyle = FlatStyle.Popup
                'viewButtonCol.DefaultCellStyle.BackColor = Color.MediumTurquoise
                'viewButtonCol.DefaultCellStyle.SelectionBackColor = Color.MediumTurquoise
                'viewButtonCol.DefaultCellStyle.SelectionForeColor = Color.Black
                receiptButtonCol.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 10, FontStyle.Bold)
                receiptButtonCol.UseColumnTextForButtonValue = True
                receiptButtonCol.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                receiptButtonCol.FlatStyle = FlatStyle.Popup
                receiptButtonCol.DefaultCellStyle.BackColor = Color.MediumTurquoise
                receiptButtonCol.DefaultCellStyle.SelectionBackColor = Color.MediumTurquoise
                receiptButtonCol.DefaultCellStyle.SelectionForeColor = Color.Black
                'lblOrderToday.Text = ds.Tables("Food_Order").Rows.Count.ToString()
            End If
            EndConnection()
        End If
    End Sub

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        Try
            If DataGridView1.Columns(e.ColumnIndex).HeaderText = "Receipt" Then
                'For intIndex = 0 To DataGridView1.RowCount - 1 Step 1
                'intOrderNumber = DataGridView1.Rows(e.RowIndex).Cells(0).Value
                If DataGridView1.Rows(e.RowIndex).Cells(5).Value = "Pay by Credit Card" Then
                    intOrderNumber = DataGridView1.Rows(e.RowIndex).Cells(0).Value
                    AsgFrmCreditReceipt.ShowDialog()
                Else
                    intOrderNumber = DataGridView1.Rows(e.RowIndex).Cells(0).Value
                    AsgFrmReceipt.ShowDialog()
                End If
                'Next intIndex
            End If
        Catch ex As Exception
        End Try

    End Sub

    Private Sub mnuUpcomingOrder_Click(sender As Object, e As EventArgs) Handles mnuUpcomingOrder.Click
        Me.Close()
        'AsgFrmStaffOrder.Show()
    End Sub

    Private Sub mnuCurrentOrder_Click(sender As Object, e As EventArgs) Handles mnuCurrentOrder.Click
        Me.Hide()
        AsgFrmStaffCurrentOrder.Show()
    End Sub

    Private Sub AsgFrmStaffCompleteOrder_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        'If blnIsFromCurrent = True Then
        '    blnIsFromCurrent = False
        'Else
        '    blnIsFromCurrent = False
        AsgFrmStaffUpcomingOrder.Show()
        'End If
    End Sub

    Private Sub btnReport_Click(sender As Object, e As EventArgs) Handles btnReport.Click
        Dim strSql As String
        Dim newDataSet As DataSet = New DataSet()
        If StartConnection() = True Then
            strSql = "Select * From Staff Where Staff_Id = " & frmStaffLoginPage.intCurrentStaffID
            da = New SqlDataAdapter(strSql, connection)
            newDataSet.Clear()
            da.Fill(newDataSet, "Staff")
            If newDataSet.Tables("Staff").Rows.Count > 0 Then
                If newDataSet.Tables("Staff").Rows(0).Item("Position") = "Staff" Then
                    MessageBox.Show("You are not authorised to generate order transaction report.", "Cannot Generate Report", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Else
                    EndConnection()
                    AsgFrmGenerateReport.ShowDialog()
                    Return
                End If
            End If
            EndConnection()
        End If
    End Sub

    Private Sub txtSearch_TextChanged(sender As Object, e As EventArgs) Handles txtSearch.TextChanged
        If txtSearch.Text.Trim() = "" Then
            DataGridView1.Columns.Clear()
            DataGridView1.DataSource = ""
            AsgFrmStaffCompleteOrder_Load(Nothing, Nothing)
        Else
            DataGridView1.Columns.Clear()
            DataGridView1.DataSource = ""
            Dim strSql As String
            Dim viewButtonCol As New DataGridViewButtonColumn
            Dim receiptButtonCol As New DataGridViewButtonColumn
            If StartConnection() = True Then
                strSql = "Select O.Order_No, O.Date, O.Total_Items, S.Staff_Name, O.Status, O.Payment_Method From Food_Order O, Customer C, Staff S WHERE O.Cust_No = C.Cust_No AND O.Staff_Id = S.Staff_Id AND O.Status = 'Completed' AND O.Order_No LIKE '%" & txtSearch.Text.Trim() & "%' OR O.Date LIKE '%" & txtSearch.Text.Trim() & "%' OR O.Total_Items LIKE '%" & txtSearch.Text.Trim() & "%' OR S.Staff_Name LIKE '%" & txtSearch.Text.Trim() & "%' OR O.Status LIKE '%" & txtSearch.Text.Trim() & "%' OR O.Payment_Method LIKE '%" & txtSearch.Text.Trim() & "%'"
                da = New SqlDataAdapter(strSql, connection)
                ds.Clear()
                Try
                    da.Fill(ds, "Food_Order")
                Catch ex As Exception
                    'do something
                End Try
                'ReDim orders(ds.Tables("Food_Order").Rows.Count - 1)
                'ReDim menus(ds.Tables("Food_Order").Rows.Count - 1)
                If ds.Tables("Food_Order").Rows.Count > 0 Then
                    DataGridView1.DataSource = ds.Tables("Food_Order")
                    DataGridView1.Columns.Add(viewButtonCol)
                    DataGridView1.Columns.Add(receiptButtonCol)
                    'DataGridView1.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    DataGridView1.Columns(0).HeaderText = "Order ID"
                    DataGridView1.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    DataGridView1.Columns(0).DefaultCellStyle.SelectionBackColor = Color.White
                    DataGridView1.Columns(0).DefaultCellStyle.SelectionForeColor = Color.Black
                    DataGridView1.Columns(1).HeaderText = "Order Date and Time"
                    DataGridView1.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    DataGridView1.Columns(1).DefaultCellStyle.SelectionBackColor = Color.White
                    DataGridView1.Columns(1).DefaultCellStyle.SelectionForeColor = Color.Black
                    DataGridView1.Columns(2).HeaderText = "Total Items"
                    DataGridView1.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    DataGridView1.Columns(2).DefaultCellStyle.SelectionBackColor = Color.White
                    DataGridView1.Columns(2).DefaultCellStyle.SelectionForeColor = Color.Black
                    DataGridView1.Columns(3).HeaderText = "Handled By"
                    DataGridView1.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    DataGridView1.Columns(3).DefaultCellStyle.SelectionBackColor = Color.White
                    DataGridView1.Columns(3).DefaultCellStyle.SelectionForeColor = Color.Black
                    DataGridView1.Columns(4).HeaderText = "Status"
                    DataGridView1.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    DataGridView1.Columns(4).DefaultCellStyle.SelectionBackColor = Color.White
                    DataGridView1.Columns(4).DefaultCellStyle.SelectionForeColor = Color.Black
                    DataGridView1.Columns(5).HeaderText = "Payment Method"
                    DataGridView1.Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    DataGridView1.Columns(5).DefaultCellStyle.SelectionBackColor = Color.White
                    DataGridView1.Columns(5).DefaultCellStyle.SelectionForeColor = Color.Black
                    viewButtonCol.HeaderText = "View Order List"
                    viewButtonCol.Text = "View Order Items"
                    receiptButtonCol.HeaderText = "Receipt"
                    receiptButtonCol.Text = "View Receipt"
                    'buttonCol.BackColor = Color.MediumTurquoise
                    viewButtonCol.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 10, FontStyle.Bold)
                    viewButtonCol.UseColumnTextForButtonValue = True
                    viewButtonCol.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    viewButtonCol.FlatStyle = FlatStyle.Popup
                    viewButtonCol.DefaultCellStyle.BackColor = Color.MediumTurquoise
                    viewButtonCol.DefaultCellStyle.SelectionBackColor = Color.MediumTurquoise
                    viewButtonCol.DefaultCellStyle.SelectionForeColor = Color.Black
                    receiptButtonCol.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 10, FontStyle.Bold)
                    receiptButtonCol.UseColumnTextForButtonValue = True
                    receiptButtonCol.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    receiptButtonCol.FlatStyle = FlatStyle.Popup
                    receiptButtonCol.DefaultCellStyle.BackColor = Color.MediumTurquoise
                    receiptButtonCol.DefaultCellStyle.SelectionBackColor = Color.MediumTurquoise
                    receiptButtonCol.DefaultCellStyle.SelectionForeColor = Color.Black
                    'lblOrderToday.Text = ds.Tables("Food_Order").Rows.Count.ToString()
                End If
                EndConnection()
            End If
        End If
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Close()
        AsgFrmStaffUpcomingOrder.Close()
    End Sub
End Class