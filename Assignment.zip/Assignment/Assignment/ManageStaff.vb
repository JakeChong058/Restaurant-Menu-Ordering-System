'Imports System.Data.Common
'Imports System.Data.SqlClient

'Public Class frmManageStaff
'    'Private da As SqlDataAdapter
'    'Private ds As DataSet = New DataSet()

'    'Friend strSQLAll As String = "Select Staff_Id, Staff_Name, Position, No_Of_Order, Status From Staff"
'    'Friend strSQLStaff As String = "Select Staff_Id, Staff_Name, Position, No_Of_Order, Status From Staff Where Position = 'Staff'"
'    'Friend strSQLManager As String = "Select Staff_Id, Staff_Name, Position, No_Of_Order, Status From Staff Where Position = 'Manager'"
'    'Friend strSQLtxtChanged As String
'    'Friend blnFilterManageStaffAll As Boolean = False
'    'Friend blnFilterManageStaffStaff As Boolean = False
'    'Friend blnFilterManageStaffManager As Boolean = False

'    'Friend strEditStaffID As Integer
'    'Friend strEditStaffName As String
'    'Friend strEditStaffPosition As String
'    'Friend strEditStaffStatus As String

'    'Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
'    '    Me.Hide()
'    '    currentStaff = Nothing
'    '    frmStaffLoginPage.Show()
'    'End Sub

'    'Private Sub btnBackToMenu_Click(sender As Object, e As EventArgs) Handles btnBackToMenu.Click
'    '    frmStaffMainPage.Show()
'    '    Me.Hide()
'    'End Sub

'    'Friend Sub ManageStaff(strSQL As String)
'    '    Dim editButtonCol As New DataGridViewButtonColumn
'    '    If Connection.StartConnection() = True Then
'    '        da = New SqlDataAdapter(strSQL, Connection.connection)
'    '        ds.Clear()
'    '        Try
'    '            da.Fill(ds, "Staff")
'    '        Catch ex As Exception
'    '        End Try
'    '        If ds.Tables("Staff").Rows.Count > 0 Then
'    '            DataGridView1.DataSource = ds.Tables("Staff")
'    '            DataGridView1.Columns.Add(editButtonCol)
'    '            DataGridView1.Columns(0).HeaderText = "Staff ID"
'    '            DataGridView1.Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
'    '            DataGridView1.Columns(0).DefaultCellStyle.SelectionBackColor = Color.White
'    '            DataGridView1.Columns(0).DefaultCellStyle.SelectionForeColor = Color.Black

'    '            DataGridView1.Columns(1).HeaderText = "Staff Name"
'    '            DataGridView1.Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
'    '            DataGridView1.Columns(1).DefaultCellStyle.SelectionBackColor = Color.White
'    '            DataGridView1.Columns(1).DefaultCellStyle.SelectionForeColor = Color.Black

'    '            DataGridView1.Columns(2).HeaderText = "Staff Position"
'    '            DataGridView1.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
'    '            DataGridView1.Columns(2).DefaultCellStyle.SelectionBackColor = Color.White
'    '            DataGridView1.Columns(2).DefaultCellStyle.SelectionForeColor = Color.Black

'    '            DataGridView1.Columns(3).HeaderText = "No of Order Completed"
'    '            DataGridView1.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
'    '            DataGridView1.Columns(3).DefaultCellStyle.SelectionBackColor = Color.White
'    '            DataGridView1.Columns(3).DefaultCellStyle.SelectionForeColor = Color.Black

'    '            DataGridView1.Columns(4).HeaderText = "Staff Status"
'    '            DataGridView1.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
'    '            DataGridView1.Columns(4).DefaultCellStyle.SelectionBackColor = Color.White
'    '            DataGridView1.Columns(4).DefaultCellStyle.SelectionForeColor = Color.Black

'    '            editButtonCol.HeaderText = "Edit Staff"
'    '            editButtonCol.Text = "Edit"
'    '            editButtonCol.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 10, FontStyle.Bold)
'    '            editButtonCol.UseColumnTextForButtonValue = True
'    '            editButtonCol.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
'    '            editButtonCol.FlatStyle = FlatStyle.Popup
'    '            editButtonCol.DefaultCellStyle.BackColor = Color.MediumTurquoise
'    '            editButtonCol.DefaultCellStyle.SelectionBackColor = Color.MediumTurquoise
'    '            editButtonCol.DefaultCellStyle.SelectionForeColor = Color.Black
'    '        End If
'    '        EndConnection()
'    '    End If
'    'End Sub

'    'Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
'    '    Try
'    '        If DataGridView1.Columns(e.ColumnIndex).HeaderText = "Edit Staff" Then
'    '            strEditStaffID = DataGridView1.Rows(e.RowIndex).Cells(0).Value
'    '            strEditStaffName = DataGridView1.Rows(e.RowIndex).Cells(1).Value
'    '            strEditStaffPosition = DataGridView1.Rows(e.RowIndex).Cells(2).Value
'    '            strEditStaffStatus = DataGridView1.Rows(e.RowIndex).Cells(4).Value
'    '            ' Me.Hide()
'    '            frmManageStaffEditStaff.ShowDialog()
'    '        End If
'    '    Catch ex As Exception
'    '    End Try
'    'End Sub

'    'Private Sub mnuAll_Click(sender As Object, e As EventArgs) Handles mnuAll.Click, MyBase.Load, Me.Shown
'    '    ManageStaff(strSQLAll)
'    '    blnFilterManageStaffAll = True
'    '    blnFilterManageStaffStaff = False
'    '    blnFilterManageStaffManager = False
'    'End Sub

'    'Private Sub mnuStaff_Click(sender As Object, e As EventArgs) Handles mnuStaff.Click
'    '    ManageStaff(strSQLStaff)
'    '    blnFilterManageStaffAll = False
'    '    blnFilterManageStaffStaff = True
'    '    blnFilterManageStaffManager = False
'    'End Sub

'    'Private Sub mnuManager_Click(sender As Object, e As EventArgs) Handles mnuManager.Click
'    '    ManageStaff(strSQLManager)
'    '    blnFilterManageStaffAll = False
'    '    blnFilterManageStaffStaff = False
'    '    blnFilterManageStaffManager = True
'    'End Sub

'    'Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
'    '    frmManageStaffAddStaff.ShowDialog()
'    'End Sub

'    'Private Sub btnGenerateReport_Click(sender As Object, e As EventArgs) Handles btnGenerateReport.Click
'    '    Me.Hide()
'    '    frmManageStaffGenerateReport.Show()
'    'End Sub

'    'Private Sub txtSearch_TextChanged(sender As Object, e As EventArgs) Handles txtSearch.TextChanged
'    '    If txtSearch.Text = "" Then
'    '        DataGridView1.Columns.Clear()
'    '        DataGridView1.DataSource = ""
'    '        mnuAll_Click(Nothing, Nothing)
'    '    Else
'    '        DataGridView1.Columns.Clear()
'    '        DataGridView1.DataSource = ""
'    '        If blnFilterManageStaffAll = True And blnFilterManageStaffManager = False And blnFilterManageStaffStaff = False Then
'    '            strSQLtxtChanged = "Select Staff_Id, Staff_Name, Position, No_Of_Order, Status From Staff Where  Staff_Id LIKE '%" & txtSearch.Text & "%' OR Staff_Name LIKE '%" & txtSearch.Text & "%' OR Position LIKE '%" & txtSearch.Text & "%' OR No_Of_Order LIKE '%" & txtSearch.Text & "%' OR Status LIKE '%" & txtSearch.Text & "%'"
'    '        ElseIf blnFilterManageStaffAll = False And blnFilterManageStaffManager = True And blnFilterManageStaffStaff = False Then
'    '            strSQLtxtChanged = "Select Staff_Id, Staff_Name, Position, No_Of_Order, Status From Staff Where Position = 'Manager' AND (  Staff_Id LIKE '%" & txtSearch.Text & "%' OR Staff_Name LIKE '%" & txtSearch.Text & "%' OR Position LIKE '%" & txtSearch.Text & "%' OR No_Of_Order LIKE '%" & txtSearch.Text & "%' OR Status LIKE '%" & txtSearch.Text & "%')"
'    '        ElseIf blnFilterManageStaffAll = False And blnFilterManageStaffManager = False And blnFilterManageStaffStaff = True Then
'    '            strSQLtxtChanged = "Select Staff_Id, Staff_Name, Position, No_Of_Order, Status From Staff Where Position = 'Staff' AND (  Staff_Id LIKE '%" & txtSearch.Text & "%' OR Staff_Name LIKE '%" & txtSearch.Text & "%' OR Position LIKE '%" & txtSearch.Text & "%' OR No_Of_Order LIKE '%" & txtSearch.Text & "%' OR Status LIKE '%" & txtSearch.Text & "%')"
'    '        End If
'    '        ManageStaff(strSQLtxtChanged)
'    '    End If
'    'End Sub
'End Class