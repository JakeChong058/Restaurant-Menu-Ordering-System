﻿Imports System.Data.SqlClient
Imports Microsoft.VisualBasic.ApplicationServices
Public Class frmEditPromotion
    Private Sub frmEdit_Load(sender As Object, e As EventArgs) Handles MyBase.Load, Me.Shown
        lblId.Text = FrmPromotion.strEditMenuId
        radRateNone.Checked = FrmPromotion.blnRadCheckNone
        radRate10.Checked = FrmPromotion.blnRadCheck10
        radRate20.Checked = FrmPromotion.blnRadCheck20
    End Sub
    Friend Function checkRate(rad1 As Boolean, rad2 As Boolean, rad3 As Boolean) As Decimal
        If rad1 = True And rad2 = False And rad3 = False Then
            Return 0.1
        ElseIf rad1 = False And rad2 = True And rad3 = False Then
            Return 0.2
        ElseIf rad1 = False And rad2 = False And rad3 = True Then
            Return 0
        Else
            Return 0
        End If
    End Function
    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click, MyBase.Closed
        Me.Close()
        'FrmPromotion.Show()
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim strErrorMsg As String = ""
        If radRateNone.Checked = False And radRate10.Checked = False And radRate20.Checked = False Then
            strErrorMsg += "Please choose a promote discount rate"
        End If
        If strErrorMsg <> "" Then
            MessageBox.Show(strErrorMsg, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            Dim strSQLStatement As String
            Dim MSSqlCommand As New SqlCommand
            If radRateNone.Checked = True Then
                If StartConnection() = True Then
                    strSQLStatement = "Update Menu SET IsPromotion = @IsPromotion, PromotionRate = @promotionrate where Menu_Id=@menuid"
                    MSSqlCommand = New SqlCommand(strSQLStatement, connection)
                    MSSqlCommand.Parameters.AddWithValue("@IsPromotion", "F")
                    MSSqlCommand.Parameters.AddWithValue("@promotionrate", checkRate(radRate10.Checked, radRate20.Checked, radRateNone.Checked))
                    MSSqlCommand.Parameters.AddWithValue("@menuid", lblId.Text)
                    MSSqlCommand.ExecuteNonQuery()
                    MessageBox.Show("Item Edit Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    EndConnection()
                    Me.Close()
                Else
                    MessageBox.Show("Error Connecting Server", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            Else
                If StartConnection() = True Then
                    strSQLStatement = "Update Menu SET PromotionRate = @promotionrate where Menu_Id=@menuid"
                    MSSqlCommand = New SqlCommand(strSQLStatement, connection)
                    MSSqlCommand.Parameters.AddWithValue("@menuid", lblId.Text)
                    MSSqlCommand.Parameters.AddWithValue("@promotionrate", checkRate(radRate10.Checked, radRate20.Checked, radRateNone.Checked))
                    MSSqlCommand.ExecuteNonQuery()
                    MessageBox.Show("Item Edit Successfully", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    EndConnection()
                    Me.Close()
                Else
                    MessageBox.Show("Error Connecting Server", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            End If
        End If
    End Sub

    Private Sub frmEdit_Closed(sender As Object, e As EventArgs) Handles MyBase.Closed
        FrmPromotion.mnuAll_Click(Nothing, Nothing)
        FrmPromotion.Show()
    End Sub
End Class