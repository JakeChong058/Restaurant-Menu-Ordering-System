﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEditPromotion
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.radRate20 = New System.Windows.Forms.RadioButton()
        Me.radRate10 = New System.Windows.Forms.RadioButton()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.radRateNone = New System.Windows.Forms.RadioButton()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblId = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'radRate20
        '
        Me.radRate20.AutoSize = True
        Me.radRate20.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radRate20.Location = New System.Drawing.Point(861, 399)
        Me.radRate20.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.radRate20.Name = "radRate20"
        Me.radRate20.Size = New System.Drawing.Size(86, 33)
        Me.radRate20.TabIndex = 88
        Me.radRate20.TabStop = True
        Me.radRate20.Text = "20%"
        Me.radRate20.UseVisualStyleBackColor = True
        '
        'radRate10
        '
        Me.radRate10.AutoSize = True
        Me.radRate10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radRate10.Location = New System.Drawing.Point(769, 399)
        Me.radRate10.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.radRate10.Name = "radRate10"
        Me.radRate10.Size = New System.Drawing.Size(86, 33)
        Me.radRate10.TabIndex = 87
        Me.radRate10.TabStop = True
        Me.radRate10.Text = "10%"
        Me.radRate10.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(10, 399)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(650, 36)
        Me.Label2.TabIndex = 86
        Me.Label2.Text = "Choose a promotion discount rate for the selected item:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 17.0!, System.Drawing.FontStyle.Bold)
        Me.Label6.Location = New System.Drawing.Point(223, 200)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(549, 86)
        Me.Label6.TabIndex = 85
        Me.Label6.Text = "Edit Promotion Discount Rate"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnUpdate
        '
        Me.btnUpdate.BackColor = System.Drawing.Color.MediumTurquoise
        Me.btnUpdate.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUpdate.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnUpdate.Location = New System.Drawing.Point(260, 512)
        Me.btnUpdate.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(154, 48)
        Me.btnUpdate.TabIndex = 83
        Me.btnUpdate.Text = "&Update"
        Me.btnUpdate.UseVisualStyleBackColor = False
        '
        'btnCancel
        '
        Me.btnCancel.BackColor = System.Drawing.Color.MediumTurquoise
        Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.ForeColor = System.Drawing.Color.Black
        Me.btnCancel.Location = New System.Drawing.Point(543, 512)
        Me.btnCancel.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(154, 48)
        Me.btnCancel.TabIndex = 82
        Me.btnCancel.Text = "&Cancel"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Assignment.My.Resources.Resources.Island_Cafe_Logo
        Me.PictureBox1.Location = New System.Drawing.Point(416, -1)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(165, 180)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 89
        Me.PictureBox1.TabStop = False
        '
        'radRateNone
        '
        Me.radRateNone.AutoSize = True
        Me.radRateNone.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radRateNone.Location = New System.Drawing.Point(666, 399)
        Me.radRateNone.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.radRateNone.Name = "radRateNone"
        Me.radRateNone.Size = New System.Drawing.Size(97, 33)
        Me.radRateNone.TabIndex = 90
        Me.radRateNone.TabStop = True
        Me.radRateNone.Text = "None"
        Me.radRateNone.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(12, 324)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(506, 36)
        Me.Label3.TabIndex = 91
        Me.Label3.Text = "Selected Item: "
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblId
        '
        Me.lblId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblId.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblId.Location = New System.Drawing.Point(524, 314)
        Me.lblId.Name = "lblId"
        Me.lblId.Size = New System.Drawing.Size(150, 49)
        Me.lblId.TabIndex = 92
        Me.lblId.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frmEditPromotion
        '
        Me.AcceptButton = Me.btnUpdate
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.CancelButton = Me.btnCancel
        Me.ClientSize = New System.Drawing.Size(968, 596)
        Me.Controls.Add(Me.lblId)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.radRateNone)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.radRate20)
        Me.Controls.Add(Me.radRate10)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.btnCancel)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MaximizeBox = False
        Me.Name = "frmEditPromotion"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Edit Promotion"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents radRate20 As RadioButton
    Friend WithEvents radRate10 As RadioButton
    Friend WithEvents Label2 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents btnUpdate As Button
    Friend WithEvents btnCancel As Button
    Friend WithEvents radRateNone As RadioButton
    Friend WithEvents Label3 As Label
    Friend WithEvents lblId As Label
End Class
