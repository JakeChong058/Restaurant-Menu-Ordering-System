﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class AsgFrmUpadate
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblImageName = New System.Windows.Forms.Label()
        Me.btnBrowse = New System.Windows.Forms.Button()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.txtMenuDescription = New System.Windows.Forms.TextBox()
        Me.lblMenuDescription = New System.Windows.Forms.Label()
        Me.txtPrice = New System.Windows.Forms.TextBox()
        Me.lblMenuPrice = New System.Windows.Forms.Label()
        Me.pictureBox1 = New System.Windows.Forms.PictureBox()
        Me.picImage = New System.Windows.Forms.PictureBox()
        Me.lblSelected = New System.Windows.Forms.Label()
        Me.lblItem = New System.Windows.Forms.Label()
        Me.btnAddNewItem = New System.Windows.Forms.Button()
        Me.errValidation = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.lblCategory = New System.Windows.Forms.Label()
        Me.cboCategory = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cboSubCategory = New System.Windows.Forms.ComboBox()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.cboStatus = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picImage, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.errValidation, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblImageName
        '
        Me.lblImageName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblImageName.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblImageName.Location = New System.Drawing.Point(786, 618)
        Me.lblImageName.Name = "lblImageName"
        Me.lblImageName.Size = New System.Drawing.Size(348, 51)
        Me.lblImageName.TabIndex = 1
        Me.lblImageName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnBrowse
        '
        Me.btnBrowse.BackColor = System.Drawing.Color.MediumTurquoise
        Me.btnBrowse.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBrowse.Location = New System.Drawing.Point(615, 618)
        Me.btnBrowse.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnBrowse.Name = "btnBrowse"
        Me.btnBrowse.Size = New System.Drawing.Size(165, 55)
        Me.btnBrowse.TabIndex = 2
        Me.btnBrowse.Text = "&Browse"
        Me.btnBrowse.UseVisualStyleBackColor = False
        '
        'lblTitle
        '
        Me.lblTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(231, 198)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(780, 61)
        Me.lblTitle.TabIndex = 9
        Me.lblTitle.Text = "EDIT MENU ITEM"
        Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtMenuDescription
        '
        Me.txtMenuDescription.BackColor = System.Drawing.Color.White
        Me.txtMenuDescription.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMenuDescription.Location = New System.Drawing.Point(272, 354)
        Me.txtMenuDescription.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtMenuDescription.MaxLength = 50
        Me.txtMenuDescription.Name = "txtMenuDescription"
        Me.txtMenuDescription.Size = New System.Drawing.Size(369, 39)
        Me.txtMenuDescription.TabIndex = 10
        '
        'lblMenuDescription
        '
        Me.lblMenuDescription.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMenuDescription.Location = New System.Drawing.Point(2, 355)
        Me.lblMenuDescription.Name = "lblMenuDescription"
        Me.lblMenuDescription.Size = New System.Drawing.Size(275, 47)
        Me.lblMenuDescription.TabIndex = 11
        Me.lblMenuDescription.Text = "Menu Description: " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.lblMenuDescription.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'txtPrice
        '
        Me.txtPrice.BackColor = System.Drawing.Color.White
        Me.txtPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPrice.Location = New System.Drawing.Point(273, 431)
        Me.txtPrice.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtPrice.MaxLength = 6
        Me.txtPrice.Name = "txtPrice"
        Me.txtPrice.Size = New System.Drawing.Size(368, 39)
        Me.txtPrice.TabIndex = 12
        '
        'lblMenuPrice
        '
        Me.lblMenuPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMenuPrice.Location = New System.Drawing.Point(2, 434)
        Me.lblMenuPrice.Name = "lblMenuPrice"
        Me.lblMenuPrice.Size = New System.Drawing.Size(265, 42)
        Me.lblMenuPrice.TabIndex = 13
        Me.lblMenuPrice.Text = "Menu Price (RM):"
        Me.lblMenuPrice.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'pictureBox1
        '
        Me.pictureBox1.Image = Global.Assignment.My.Resources.Resources.Island_Cafe_Logo
        Me.pictureBox1.Location = New System.Drawing.Point(528, -1)
        Me.pictureBox1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.pictureBox1.Name = "pictureBox1"
        Me.pictureBox1.Size = New System.Drawing.Size(165, 180)
        Me.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pictureBox1.TabIndex = 8
        Me.pictureBox1.TabStop = False
        '
        'picImage
        '
        Me.picImage.Location = New System.Drawing.Point(786, 325)
        Me.picImage.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.picImage.Name = "picImage"
        Me.picImage.Size = New System.Drawing.Size(349, 266)
        Me.picImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picImage.TabIndex = 0
        Me.picImage.TabStop = False
        '
        'lblSelected
        '
        Me.lblSelected.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSelected.Location = New System.Drawing.Point(311, 274)
        Me.lblSelected.Name = "lblSelected"
        Me.lblSelected.Size = New System.Drawing.Size(275, 55)
        Me.lblSelected.TabIndex = 14
        Me.lblSelected.Text = "Selected Item : "
        Me.lblSelected.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblItem
        '
        Me.lblItem.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblItem.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblItem.Location = New System.Drawing.Point(581, 265)
        Me.lblItem.Name = "lblItem"
        Me.lblItem.Size = New System.Drawing.Size(176, 52)
        Me.lblItem.TabIndex = 15
        Me.lblItem.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnAddNewItem
        '
        Me.btnAddNewItem.BackColor = System.Drawing.Color.MediumTurquoise
        Me.btnAddNewItem.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddNewItem.Location = New System.Drawing.Point(505, 777)
        Me.btnAddNewItem.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnAddNewItem.Name = "btnAddNewItem"
        Me.btnAddNewItem.Size = New System.Drawing.Size(236, 66)
        Me.btnAddNewItem.TabIndex = 16
        Me.btnAddNewItem.Text = "&Add New Item"
        Me.btnAddNewItem.UseVisualStyleBackColor = False
        '
        'errValidation
        '
        Me.errValidation.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink
        Me.errValidation.ContainerControl = Me
        '
        'lblCategory
        '
        Me.lblCategory.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCategory.Location = New System.Drawing.Point(12, 508)
        Me.lblCategory.Name = "lblCategory"
        Me.lblCategory.Size = New System.Drawing.Size(261, 47)
        Me.lblCategory.TabIndex = 17
        Me.lblCategory.Text = "Category: "
        Me.lblCategory.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'cboCategory
        '
        Me.cboCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCategory.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboCategory.FormattingEnabled = True
        Me.cboCategory.Items.AddRange(New Object() {"Food", "Beverages", "Desserts"})
        Me.cboCategory.Location = New System.Drawing.Point(272, 508)
        Me.cboCategory.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.cboCategory.Name = "cboCategory"
        Me.cboCategory.Size = New System.Drawing.Size(261, 40)
        Me.cboCategory.TabIndex = 18
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 585)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(265, 40)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "Sub-Category: "
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'cboSubCategory
        '
        Me.cboSubCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSubCategory.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboSubCategory.FormattingEnabled = True
        Me.cboSubCategory.Location = New System.Drawing.Point(273, 582)
        Me.cboSubCategory.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.cboSubCategory.Name = "cboSubCategory"
        Me.cboSubCategory.Size = New System.Drawing.Size(260, 40)
        Me.cboSubCategory.TabIndex = 20
        '
        'btnClear
        '
        Me.btnClear.BackColor = System.Drawing.Color.MediumTurquoise
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(201, 777)
        Me.btnClear.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(236, 66)
        Me.btnClear.TabIndex = 21
        Me.btnClear.Text = "&Clear"
        Me.btnClear.UseVisualStyleBackColor = False
        '
        'btnCancel
        '
        Me.btnCancel.BackColor = System.Drawing.Color.MediumTurquoise
        Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnCancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.Location = New System.Drawing.Point(806, 777)
        Me.btnCancel.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(236, 66)
        Me.btnCancel.TabIndex = 22
        Me.btnCancel.Text = "C&ancel"
        Me.btnCancel.UseVisualStyleBackColor = False
        '
        'lblStatus
        '
        Me.lblStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatus.Location = New System.Drawing.Point(12, 659)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(265, 40)
        Me.lblStatus.TabIndex = 23
        Me.lblStatus.Text = "Status: "
        Me.lblStatus.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'cboStatus
        '
        Me.cboStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cboStatus.FormattingEnabled = True
        Me.cboStatus.Items.AddRange(New Object() {"Selling", "Sold Out"})
        Me.cboStatus.Location = New System.Drawing.Point(272, 659)
        Me.cboStatus.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.cboStatus.Name = "cboStatus"
        Me.cboStatus.Size = New System.Drawing.Size(260, 40)
        Me.cboStatus.TabIndex = 24
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(815, 274)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(282, 44)
        Me.Label2.TabIndex = 25
        Me.Label2.Text = "Item Image: "
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'AsgFrmUpadate
        '
        Me.AcceptButton = Me.btnAddNewItem
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.CancelButton = Me.btnCancel
        Me.ClientSize = New System.Drawing.Size(1225, 879)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.cboStatus)
        Me.Controls.Add(Me.lblStatus)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.cboSubCategory)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cboCategory)
        Me.Controls.Add(Me.lblCategory)
        Me.Controls.Add(Me.btnAddNewItem)
        Me.Controls.Add(Me.lblItem)
        Me.Controls.Add(Me.lblSelected)
        Me.Controls.Add(Me.lblMenuPrice)
        Me.Controls.Add(Me.txtPrice)
        Me.Controls.Add(Me.lblMenuDescription)
        Me.Controls.Add(Me.txtMenuDescription)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.pictureBox1)
        Me.Controls.Add(Me.btnBrowse)
        Me.Controls.Add(Me.lblImageName)
        Me.Controls.Add(Me.picImage)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MaximizeBox = False
        Me.Name = "AsgFrmUpadate"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Update & Add New Item"
        CType(Me.pictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picImage, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.errValidation, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents picImage As PictureBox
    Friend WithEvents lblImageName As Label
    Friend WithEvents btnBrowse As Button
    Friend WithEvents pictureBox1 As PictureBox
    Friend WithEvents lblTitle As Label
    Friend WithEvents txtMenuDescription As TextBox
    Friend WithEvents lblMenuDescription As Label
    Friend WithEvents txtPrice As TextBox
    Friend WithEvents lblMenuPrice As Label
    Friend WithEvents lblSelected As Label
    Friend WithEvents lblItem As Label
    Friend WithEvents btnAddNewItem As Button
    Friend WithEvents errValidation As ErrorProvider
    Friend WithEvents cboCategory As ComboBox
    Friend WithEvents lblCategory As Label
    Friend WithEvents cboSubCategory As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents btnCancel As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents cboStatus As ComboBox
    Friend WithEvents lblStatus As Label
    Friend WithEvents Label2 As Label
End Class
